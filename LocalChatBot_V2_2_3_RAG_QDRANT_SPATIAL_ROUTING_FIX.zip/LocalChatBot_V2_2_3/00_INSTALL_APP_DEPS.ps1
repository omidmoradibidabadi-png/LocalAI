$Root=Split-Path -Parent $MyInvocation.MyCommand.Path
Write-Host "LocalGeoAI V6.1.1 uses the unified dependency installer." -ForegroundColor Cyan
& (Join-Path $Root '00_INSTALL_UNIVERSAL_DEPS.ps1')
exit $LASTEXITCODE
