@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp000_INSTALL_APP_DEPS.ps1"
set EC=%ERRORLEVEL%
echo.
pause
exit /b %EC%
