@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp000_INSTALL_UNIVERSAL_DEPS.ps1"
set RC=%ERRORLEVEL%
echo.
if "%RC%"=="0" (echo Runtime installation completed successfully.) else (echo Runtime installation finished with missing capabilities. Check logs\runtime_install.)
pause
exit /b %RC%
