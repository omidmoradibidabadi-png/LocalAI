$ErrorActionPreference='Continue'
$Root=Split-Path -Parent $MyInvocation.MyCommand.Path
$Py=Join-Path $Root 'runtime\python\python.exe'
$Pip=Join-Path $Root 'runtime_packages\pip.pyz'
$Site=Join-Path $Root 'runtime\python\Lib\site-packages'
$Logs=Join-Path $Root 'logs\runtime_install'
$Wheelhouse=Join-Path $Root 'runtime_packages\wheels'
New-Item -ItemType Directory -Force $Site,$Logs,$Wheelhouse | Out-Null
if(!(Test-Path $Py)){ throw 'Portable Python not found in runtime\python.' }

# Enable site-packages in Python embeddable runtime.
$Pth=Get-ChildItem (Join-Path $Root 'runtime\python') -Filter 'python*._pth' | Select-Object -First 1
if($Pth){
  $lines=Get-Content $Pth.FullName
  $lines=$lines | ForEach-Object { if($_ -match '^#\s*import site'){ 'import site' } else { $_ } }
  if(-not($lines -contains 'Lib\site-packages')){ $lines += 'Lib\site-packages' }
  if(-not($lines -contains 'import site')){ $lines += 'import site' }
  Set-Content $Pth.FullName $lines -Encoding ASCII
}
$env:PYTHONPATH=$Site

if(!(Test-Path $Pip)){
  Write-Host 'pip.pyz missing; downloading bootstrap copy...' -ForegroundColor Yellow
  try { Invoke-WebRequest -UseBasicParsing 'https://bootstrap.pypa.io/pip/pip.pyz' -OutFile $Pip }
  catch { throw 'pip.pyz is missing and could not be downloaded.' }
}

$script:Ready=@(); $script:Failed=@()
function Run-Pip([string]$Name,[string[]]$PipArgs){
  $log=Join-Path $Logs (('install_'+($Name -replace '[^A-Za-z0-9_-]','_')+'.log'))
  "COMMAND: $Py $Pip $($PipArgs -join ' ')" | Set-Content $log -Encoding UTF8
  & $Py $Pip @PipArgs 2>&1 | Tee-Object -FilePath $log -Append | Out-Host
  return [int]$LASTEXITCODE
}
function Check-Imports([string[]]$Modules){
  foreach($m in $Modules){
    & $Py -c "import $m" 2>$null
    if($LASTEXITCODE -ne 0){ return $false }
  }
  return $true
}
function Install-Group([string]$Name,[string[]]$Packages,[string[]]$Imports,[switch]$NoBuildIsolation){
  Write-Host "`n=== $Name ===" -ForegroundColor Cyan
  $common=@('install','--disable-pip-version-check','--upgrade','--prefer-binary','--target',$Site)
  if(Test-Path (Join-Path $Wheelhouse '*.whl')){ $common += @('--find-links',$Wheelhouse) }
  if($NoBuildIsolation){ $common += '--no-build-isolation' }
  $code=Run-Pip $Name ($common+$Packages)
  if(($code -eq 0) -and (Check-Imports $Imports)){
    Write-Host "[OK] $Name" -ForegroundColor Green; $script:Ready += $Name
  } else {
    Write-Host "[WARN] $Name unavailable. See logs\runtime_install\install_$($Name -replace '[^A-Za-z0-9_-]','_').log" -ForegroundColor Yellow
    $script:Failed += $Name
  }
}

Write-Host 'LocalGeoAI V6.1.2 portable runtime rebuild' -ForegroundColor Cyan
Write-Host 'Bootstrap packaging tools...' -ForegroundColor Cyan
$null=Run-Pip 'BOOTSTRAP' @('install','--disable-pip-version-check','--upgrade','--target',$Site,'setuptools>=70','wheel>=0.43','packaging>=24')

Install-Group 'PDF' @('PyMuPDF>=1.24,<2') @('fitz')
Install-Group 'Office-DOCX' @('python-docx>=1.1,<2') @('docx')
Install-Group 'Office-XLSX' @('openpyxl>=3.1,<4') @('openpyxl')
Install-Group 'Office-PPTX' @('python-pptx>=1.0,<2') @('pptx')
Install-Group 'OpenDocument' @('odfpy>=1.4,<2') @('odf')
Install-Group 'HTML-XML' @('beautifulsoup4>=4.12,<5','lxml>=5,<7') @('bs4','lxml')
Install-Group 'Images-EXIF' @('Pillow>=10,<12','imageio>=2.35,<3','tifffile>=2024.8') @('PIL','imageio','tifffile')
Install-Group 'OCR-Bridge' @('pytesseract>=0.3.13,<1') @('pytesseract')
Install-Group 'Numeric-Tabular' @('numpy>=1.26,<3','pandas>=2.2,<3','pyarrow>=17,<22','PyYAML>=6,<7') @('numpy','pandas','pyarrow','yaml')
Install-Group 'Archives' @('py7zr>=0.22,<1') @('py7zr')
Install-Group 'GIS-Core' @('shapely>=2,<3','pyproj>=3.6,<4','pyogrio>=0.9,<1','geopandas>=1,<2') @('shapely','pyproj','pyogrio','geopandas')
Install-Group 'Raster-GDAL' @('rasterio>=1.3,<2') @('rasterio')
Install-Group 'Scientific' @('h5py>=3.11,<4','xarray>=2024.7','netCDF4>=1.7,<2') @('h5py','xarray','netCDF4')
# Pure-Python transitive dependency may require setuptools backend; disable isolated build.
Install-Group 'Email-MSG' @('extract-msg>=0.54,<1') @('extract_msg') -NoBuildIsolation

Write-Host "`n=== Runtime validation ===" -ForegroundColor Cyan
& $Py (Join-Path $Root 'tools\validate_runtime.py')
$validation=$LASTEXITCODE
Write-Host "`nREADY: $($Ready -join ', ')" -ForegroundColor Green
if($Failed.Count){ Write-Host "MISSING: $($Failed -join ', ')" -ForegroundColor Yellow }
Write-Host "Detailed logs: $Logs" -ForegroundColor Cyan
if($validation -eq 0){ Write-Host 'CORE RUNTIME VALIDATION: PASS' -ForegroundColor Green; exit 0 }
else { Write-Host 'CORE RUNTIME VALIDATION: INCOMPLETE' -ForegroundColor Yellow; exit 2 }
