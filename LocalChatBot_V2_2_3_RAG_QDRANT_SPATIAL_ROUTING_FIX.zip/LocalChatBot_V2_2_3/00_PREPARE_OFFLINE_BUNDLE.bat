@echo off
chcp 65001 >nul
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
echo === LocalChatBot V1.0.5 Offline Bundle Preparation ===
if not exist "web\vendor" mkdir "web\vendor"
if not exist "..\LocalChatBot_PersistentData\maps\world" mkdir "..\LocalChatBot_PersistentData\maps\world"
if exist "..\osm_world_z0_z6.pmtiles" if not exist "..\LocalChatBot_PersistentData\maps\world\osm_world_z0_z6.pmtiles" copy /Y "..\osm_world_z0_z6.pmtiles" "..\LocalChatBot_PersistentData\maps\world\osm_world_z0_z6.pmtiles"
if not exist "web\vendor\maplibre-gl.js" powershell -NoProfile -Command "Invoke-WebRequest -UseBasicParsing 'https://unpkg.com/maplibre-gl@5.7.1/dist/maplibre-gl.js' -OutFile 'web/vendor/maplibre-gl.js'"
if not exist "web\vendor\maplibre-gl.css" powershell -NoProfile -Command "Invoke-WebRequest -UseBasicParsing 'https://unpkg.com/maplibre-gl@5.7.1/dist/maplibre-gl.css' -OutFile 'web/vendor/maplibre-gl.css'"
if not exist "web\vendor\pmtiles.js" powershell -NoProfile -Command "Invoke-WebRequest -UseBasicParsing 'https://unpkg.com/pmtiles@4.3.0/dist/pmtiles.js' -OutFile 'web/vendor/pmtiles.js'"
echo.
echo Map files prepared. Models/runtimes are intentionally NOT downloaded by this script.
echo Required local payloads: runtime\python, runtime\llama, runtime\qdrant, runtime\elasticsearch, runtime\ocr, models\llm, models\embedding.
echo Copy those from your validated LocalChatBot installation into this V1.0.5 folder before moving to the offline PC.
pause
