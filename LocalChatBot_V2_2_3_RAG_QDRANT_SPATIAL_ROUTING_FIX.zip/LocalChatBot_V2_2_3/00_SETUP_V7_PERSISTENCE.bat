@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set "PY=runtime\python\python.exe"
if not exist "%PY%" set "PY=python"
"%PY%" tools\v7_persistence_setup.py
pause
