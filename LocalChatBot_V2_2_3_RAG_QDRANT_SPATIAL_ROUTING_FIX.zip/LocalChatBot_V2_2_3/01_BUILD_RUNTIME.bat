@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp001_BUILD_RUNTIME.ps1"
set EC=%ERRORLEVEL%
echo.
pause
exit /b %EC%
