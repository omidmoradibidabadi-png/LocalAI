﻿param(
    [switch]$Force
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Packages = Join-Path $Root "runtime_packages"
$Runtime = Join-Path $Root "runtime"
$PythonDir = Join-Path $Runtime "python"
$LlamaDir = Join-Path $Runtime "llama"
$QdrantDir = Join-Path $Runtime "qdrant"
$ManifestPath = Join-Path $Root "runtime_manifest.json"

function Say($Text, $Color="Gray") {
    Write-Host $Text -ForegroundColor $Color
}
function Fail($Text) {
    Say "`n[ERROR] $Text" "Red"
    Say "No existing model or data files were deleted." "Yellow"
    exit 1
}
function Find-ZipByContent($Pattern) {
    $zips = Get-ChildItem -Path $Packages -Filter *.zip -File -ErrorAction SilentlyContinue
    foreach ($z in $zips) {
        try {
            Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
            $a = [System.IO.Compression.ZipFile]::OpenRead($z.FullName)
            try {
                foreach ($e in $a.Entries) {
                    if ($e.FullName -match $Pattern) { return $z }
                }
            } finally { $a.Dispose() }
        } catch {}
    }
    return $null
}

Say "============================================================" "Cyan"
Say " LocalGeoAI V3 - Portable Runtime Builder" "Cyan"
Say "============================================================" "Cyan"
Say "Project: $Root"

if (!(Test-Path -LiteralPath $Packages)) { Fail "runtime_packages folder not found." }

# Detect packages by CONTENT, not versioned filename.
$PythonZip = Find-ZipByContent '(^|/)python\.exe$'
$LlamaZip  = Find-ZipByContent '(^|/)llama-server\.exe$'

# CUDA package normally contains CUDA DLLs but not llama-server.
$CudaZip = $null
$zips = Get-ChildItem -Path $Packages -Filter *.zip -File -ErrorAction SilentlyContinue
foreach ($z in $zips) {
    if ($LlamaZip -and $z.FullName -eq $LlamaZip.FullName) { continue }
    try {
        Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
        $a = [System.IO.Compression.ZipFile]::OpenRead($z.FullName)
        try {
            $hasCuda = $false
            foreach ($e in $a.Entries) {
                if ($e.FullName -match '(cudart|cublas|ggml-cuda).*\.dll$') { $hasCuda = $true; break }
            }
            if ($hasCuda) { $CudaZip = $z; break }
        } finally { $a.Dispose() }
    } catch {}
}

if (!$PythonZip) { Fail "Python Embedded ZIP was not detected inside runtime_packages." }
if (!$LlamaZip)  { Fail "llama.cpp ZIP containing llama-server.exe was not detected." }

Say "[OK] Python package: $($PythonZip.Name)" "Green"
Say "[OK] llama.cpp package: $($LlamaZip.Name)" "Green"
if ($CudaZip) { Say "[OK] CUDA runtime package: $($CudaZip.Name)" "Green" }
else { Say "[WARN] Separate CUDA DLL ZIP not detected. The llama package may already contain required DLLs." "Yellow" }

# Do not destroy an existing runtime unless explicitly rebuilding.
if ($Force) {
    Say "Force rebuild requested. Runtime folders will be refreshed." "Yellow"
    if (Test-Path -LiteralPath $PythonDir) { Remove-Item $PythonDir -Recurse -Force }
    if (Test-Path -LiteralPath $LlamaDir)  { Remove-Item $LlamaDir -Recurse -Force }
}
New-Item -ItemType Directory -Force -Path $PythonDir,$LlamaDir,$QdrantDir | Out-Null

function Expand-Flatten($ZipPath, $Destination, $TempName) {
    $temp = Join-Path $env:TEMP $TempName
    if (Test-Path -LiteralPath $temp) { Remove-Item $temp -Recurse -Force }
    New-Item -ItemType Directory -Force -Path $temp | Out-Null
    Expand-Archive -LiteralPath $ZipPath -DestinationPath $temp -Force

    # Copy recursively and flatten a single top-level packaging directory naturally.
    Get-ChildItem $temp -Recurse -File | ForEach-Object {
        $target = Join-Path $Destination $_.Name
        Copy-Item $_.FullName $target -Force
    }
    Remove-Item $temp -Recurse -Force
}

Say "`nBuilding embedded Python runtime..."
Expand-Flatten $PythonZip.FullName $PythonDir "LocalGeoAI_python_unpack"
if (!(Test-Path (Join-Path $PythonDir "python.exe"))) { Fail "python.exe missing after extraction." }
Say "[OK] Embedded Python ready." "Green"

Say "Building llama.cpp CUDA runtime..."
Expand-Flatten $LlamaZip.FullName $LlamaDir "LocalGeoAI_llama_unpack"
if ($CudaZip) { Expand-Flatten $CudaZip.FullName $LlamaDir "LocalGeoAI_cuda_unpack" }
if (!(Test-Path (Join-Path $LlamaDir "llama-server.exe"))) { Fail "llama-server.exe missing after extraction." }
Say "[OK] llama-server.exe ready." "Green"

# Existing assets
$qdrant = Join-Path $QdrantDir "qdrant.exe"
$llm = Join-Path $Root "models\llm\gemma-4-E4B-it-Q4_K_M.gguf"
$embDir = Join-Path $Root "models\embedding"
$embModels = @(Get-ChildItem -LiteralPath $embDir -Filter *.gguf -File -ErrorAction SilentlyContinue)
$emb = if($embModels.Count -eq 1){$embModels[0].FullName}else{$null}

if (!(Test-Path -LiteralPath $qdrant)) { Fail "qdrant.exe is missing: runtime\qdrant\qdrant.exe" }
if (!(Test-Path -LiteralPath $llm)) { Fail "Generation model is missing: models\llm\gemma-4-E4B-it-Q4_K_M.gguf" }
if ($embModels.Count -ne 1) { Fail "Expected exactly one GGUF embedding model in models\embedding; found $($embModels.Count)." }

# GPU diagnostic is informative; absence does not corrupt build.
$gpu = $null
try {
    $gpu = (& nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv,noheader 2>$null | Select-Object -First 1)
} catch {}

$manifest = [ordered]@{
    schema_version = 1
    built_at_utc = (Get-Date).ToUniversalTime().ToString("o")
    architecture = "x64"
    portable = $true
    python = [ordered]@{
        ready = $true
        executable = "runtime/python/python.exe"
        package = $PythonZip.Name
    }
    llama = [ordered]@{
        ready = $true
        executable = "runtime/llama/llama-server.exe"
        package = $LlamaZip.Name
        cuda_package = if ($CudaZip) {$CudaZip.Name} else {$null}
    }
    qdrant = [ordered]@{
        ready = $true
        executable = "runtime/qdrant/qdrant.exe"
        port = 6333
    }
    models = [ordered]@{
        generation = "models/llm/gemma-4-E4B-it-Q4_K_M.gguf"
        embedding = "models/embedding"
    }
    ports = [ordered]@{
        backend = 8080
        generation = 8081
        embedding = 8082
        qdrant = 6333
    }
    gpu_detected = [bool]$gpu
    gpu_info = $gpu
}
$manifest | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $ManifestPath -Encoding UTF8

Say "`n============================================================" "Green"
Say " PORTABLE RUNTIME BUILD COMPLETED" "Green"
Say "============================================================" "Green"
Say "Manifest: runtime_manifest.json"
if ($gpu) { Say "GPU: $gpu" "Green" } else { Say "GPU: nvidia-smi not detected; runtime was still built." "Yellow" }
Say "`nNext: run 02_TEST_AI_RUNTIME.bat" "Cyan"
