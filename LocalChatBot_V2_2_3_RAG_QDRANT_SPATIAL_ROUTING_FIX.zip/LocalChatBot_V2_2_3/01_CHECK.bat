@echo off
setlocal
cd /d "%~dp0"
set "PY=runtime\python\python.exe"
if exist "%PY%" goto run
where py >nul 2>nul && (set "PY=py -3.11" & goto run)
where python >nul 2>nul && (set "PY=python" & goto run)
echo [FAIL] Python runtime not found.
pause
exit /b 1
:run
%PY% tools\preflight.py
set RC=%ERRORLEVEL%
echo.
pause
exit /b %RC%
