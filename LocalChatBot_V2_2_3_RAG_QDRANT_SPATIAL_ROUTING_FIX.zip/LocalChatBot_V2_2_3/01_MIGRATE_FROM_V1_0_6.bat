@echo off
setlocal
cd /d "%~dp0"
set "OLD=..\LocalChatBot_V1_0_6"
echo LocalChatBot V1.0.7 offline migration
if not exist "%OLD%" (
  echo [INFO] V1.0.6 sibling folder not found. Nothing copied.
  echo PersistentData is shared automatically.
  pause
  exit /b 0
)
if exist "%OLD%\web\vendor" robocopy "%OLD%\web\vendor" "%CD%\web\vendor" /E /NFL /NDL /NJH /NJS /NP >nul
if exist "%OLD%\runtime" robocopy "%OLD%\runtime" "%CD%\runtime" /E /NFL /NDL /NJH /NJS /NP >nul
if exist "%OLD%\models" robocopy "%OLD%\models" "%CD%\models" /E /NFL /NDL /NJH /NJS /NP >nul
echo [OK] Existing offline runtime, models and map libraries copied where available.
echo [OK] PMTiles remains in shared LocalChatBot_PersistentData.
pause
