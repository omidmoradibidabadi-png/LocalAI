@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if "%~1"=="" (
 echo Drag the previous LocalGeoAI V6 folder onto this BAT file.
 echo Example: 01_MIGRATE_V6_DATA_TO_V7.bat "E:\LocalGeoAI_V3_Core\6.4.16-..."
 pause
 exit /b 2
)
set "PY=runtime\python\python.exe"
if not exist "%PY%" set "PY=python"
"%PY%" tools\v7_migrate_previous_data.py "%~1"
pause
