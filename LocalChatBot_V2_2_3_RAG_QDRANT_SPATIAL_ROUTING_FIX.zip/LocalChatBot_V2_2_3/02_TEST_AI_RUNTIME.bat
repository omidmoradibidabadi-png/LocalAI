@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp002_TEST_AI_RUNTIME.ps1"
set EC=%ERRORLEVEL%
echo.
pause
exit /b %EC%
