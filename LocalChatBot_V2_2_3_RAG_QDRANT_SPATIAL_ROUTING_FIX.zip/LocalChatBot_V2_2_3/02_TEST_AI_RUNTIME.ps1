﻿$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Llama = Join-Path $Root "runtime\llama\llama-server.exe"
$Qdrant = Join-Path $Root "runtime\qdrant\qdrant.exe"
$LLM = Join-Path $Root "models\llm\gemma-4-E4B-it-Q4_K_M.gguf"
$EmbDir = Join-Path $Root "models\embedding"
$EmbModels = @(Get-ChildItem -LiteralPath $EmbDir -Filter *.gguf -File -ErrorAction SilentlyContinue)
if($EmbModels.Count -ne 1){ throw "Expected exactly one GGUF embedding model in $EmbDir; found $($EmbModels.Count)." }
$EMB = $EmbModels[0].FullName
$LogDir = Join-Path $Root "logs"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null

function Say($t,$c="Gray"){Write-Host $t -ForegroundColor $c}
function Wait-Http($Url,$Seconds=90){
    $deadline=(Get-Date).AddSeconds($Seconds)
    while((Get-Date) -lt $deadline){
        try {
            $r=Invoke-WebRequest -UseBasicParsing -Uri $Url -TimeoutSec 3
            if($r.StatusCode -ge 200 -and $r.StatusCode -lt 500){return $true}
        } catch {}
        Start-Sleep -Seconds 1
    }
    return $false
}
function Stop-IfRunning($p){ if($p -and !$p.HasExited){Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue} }

Say "============================================================" "Cyan"
Say " LocalGeoAI V3 - AI Runtime End-to-End Test" "Cyan"
Say "============================================================" "Cyan"

foreach($f in @($Llama,$Qdrant,$LLM,$EMB)){
    if(!(Test-Path $f)){throw "Missing required file: $f"}
}

$qProc=$null; $gProc=$null; $eProc=$null
try {
    # Qdrant
    try {
        Invoke-WebRequest -UseBasicParsing -Uri "http://127.0.0.1:6333/readyz" -TimeoutSec 2 | Out-Null
        Say "[OK] Qdrant already running." "Green"
    } catch {
        Say "Starting Qdrant..."
        $qProc=Start-Process -FilePath $Qdrant -WorkingDirectory (Split-Path $Qdrant) -PassThru -WindowStyle Minimized `
          -RedirectStandardOutput (Join-Path $LogDir "qdrant.out.log") -RedirectStandardError (Join-Path $LogDir "qdrant.err.log")
        if(!(Wait-Http "http://127.0.0.1:6333/readyz" 30)){throw "Qdrant did not become ready. See logs."}
        Say "[OK] Qdrant ready on 6333." "Green"
    }

    # Generation server
    Say "Starting Gemma generation server on 8081..."
    $gArgs=@("-m",$LLM,"--host","127.0.0.1","--port","8081","-ngl","999","-c","4096")
    $gProc=Start-Process -FilePath $Llama -ArgumentList $gArgs -WorkingDirectory (Split-Path $Llama) -PassThru -WindowStyle Minimized `
      -RedirectStandardOutput (Join-Path $LogDir "gemma.out.log") -RedirectStandardError (Join-Path $LogDir "gemma.err.log")
    if(!(Wait-Http "http://127.0.0.1:8081/health" 120)){throw "Gemma server failed. Check logs\gemma.err.log"}
    Say "[OK] Gemma server ready." "Green"

    # Generation request using OpenAI-compatible endpoint.
    $body=@{
        model="local-gemma"
        messages=@(@{role="user";content="Reply with only this word: READY"})
        max_tokens=16
        temperature=0
    } | ConvertTo-Json -Depth 6
    $gen=Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:8081/v1/chat/completions" -ContentType "application/json" -Body $body -TimeoutSec 120
    $answer=$gen.choices[0].message.content
    Say "[OK] Generation response: $answer" "Green"

    # Stop generation before loading embedding to make VRAM use deterministic.
    Stop-IfRunning $gProc
    $gProc=$null
    Start-Sleep -Seconds 2

    # Embedding server
    Say "Starting embedding server on 8082..."
    $eArgs=@("-m",$EMB,"--embedding","--host","127.0.0.1","--port","8082","-ngl","999")
    $eProc=Start-Process -FilePath $Llama -ArgumentList $eArgs -WorkingDirectory (Split-Path $Llama) -PassThru -WindowStyle Minimized `
      -RedirectStandardOutput (Join-Path $LogDir "embedding.out.log") -RedirectStandardError (Join-Path $LogDir "embedding.err.log")
    if(!(Wait-Http "http://127.0.0.1:8082/health" 120)){throw "Embedding server failed. Check logs\embedding.err.log"}
    Say "[OK] Embedding server ready." "Green"

    $ebody=@{input=@("فرودگاه مهرآباد");model="local-embedding"} | ConvertTo-Json -Depth 5
    $er=Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:8082/v1/embeddings" -ContentType "application/json" -Body $ebody -TimeoutSec 120
    $vec=$er.data[0].embedding
    if(!$vec -or $vec.Count -lt 8){throw "Embedding response did not contain a valid vector."}
    Say "[OK] Embedding dimension detected: $($vec.Count)" "Green"

    # Qdrant round trip with detected dimension
    $collection="localgeoai_runtime_test"
    try { Invoke-RestMethod -Method Delete -Uri "http://127.0.0.1:6333/collections/$collection" -TimeoutSec 10 | Out-Null } catch {}
    $cbody=@{vectors=@{size=$vec.Count;distance="Cosine"}} | ConvertTo-Json -Depth 5
    Invoke-RestMethod -Method Put -Uri "http://127.0.0.1:6333/collections/$collection" -ContentType "application/json" -Body $cbody | Out-Null
    $pbody=@{points=@(@{id=1;vector=$vec;payload=@{text="فرودگاه مهرآباد";runtime_test=$true}})} | ConvertTo-Json -Depth 8
    Invoke-RestMethod -Method Put -Uri "http://127.0.0.1:6333/collections/$collection/points?wait=true" -ContentType "application/json" -Body $pbody | Out-Null
    Say "[OK] Qdrant vector write succeeded." "Green"

    Say "`n============================================================" "Green"
    Say " AI RUNTIME TEST PASSED" "Green"
    Say "============================================================" "Green"
    Say "Gemma + EmbeddingGemma + Qdrant are operational." "Green"
    Say "Logs are available in the logs folder."
}
catch {
    Say "`n[FAILED] $($_.Exception.Message)" "Red"
    Say "Send me the CMD screenshot plus the relevant *.err.log file from logs." "Yellow"
    exit 1
}
finally {
    Stop-IfRunning $gProc
    Stop-IfRunning $eProc
    # Keep Qdrant running if it existed before; stop only the instance started by this test.
    Stop-IfRunning $qProc
}
