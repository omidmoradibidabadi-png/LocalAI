@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set "PYTHONPATH=%~dp0;%PYTHONPATH%"
set "PY=runtime\python\python.exe"
if not exist "%PY%" (
  echo [FAIL] Portable Python not found: %PY%
  pause
  exit /b 1
)
"%PY%" tools\v1_persistence_setup.py
"%PY%" tools\v211_offline_assets.py
"%PY%" tools\preflight.py
if errorlevel 1 (
  echo.
  echo Preflight failed. See the missing REQUIRED files above.
  pause
  exit /b 1
)
echo.
echo Starting LocalChatBot V2.2.2 backend + Qdrant + Gemma + EmbeddingGemma + Web UI...
"%PY%" "app\localgeoai\api\web_server.py"
echo.
pause
