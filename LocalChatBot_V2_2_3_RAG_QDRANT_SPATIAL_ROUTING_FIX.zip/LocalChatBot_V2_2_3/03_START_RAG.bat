@echo off
cd /d "%~dp0"
set "PY=runtime\python\python.exe"
if not exist "%PY%" (
  echo Embedded Python runtime not found. Run 01_BUILD_RUNTIME.bat first.
  pause
  exit /b 1
)
"%PY%" "app\localgeoai\main.py" shell
echo.
pause
