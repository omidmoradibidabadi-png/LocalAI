@echo off
cd /d "%~dp0"
if "%~1"=="" (
  echo Drag a PDF, DOCX, TXT or MD file onto this BAT file.
  pause
  exit /b 1
)
"runtime\python\python.exe" "app\localgeoai\main.py" ingest "%~1"
echo.
pause
