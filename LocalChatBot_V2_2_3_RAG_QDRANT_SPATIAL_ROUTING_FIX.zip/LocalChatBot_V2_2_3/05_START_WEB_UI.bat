@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PYTHONPATH=%~dp0;%PYTHONPATH%"
set "PY=runtime\python\python.exe"
if not exist "%PY%" (
  echo Embedded Python runtime not found. Run 01_BUILD_RUNTIME.bat first.
  pause
  exit /b 1
)
echo Starting LocalGeoAI persistent backend and Persian Web UI...
"%PY%" "app\localgeoai\api\web_server.py"
echo.
pause
