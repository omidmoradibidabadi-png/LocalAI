@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PYTHONPATH=%~dp0;%PYTHONPATH%"
echo === LocalGeoAI Web UI diagnostic ===
echo ROOT: %CD%
echo.
if not exist "runtime\python\python.exe" (
  echo [ERROR] runtime\python\python.exe not found.
  pause
  exit /b 1
)
if not exist "app\localgeoai\api\web_server.py" (
  echo [ERROR] web_server.py not found.
  pause
  exit /b 1
)
"runtime\python\python.exe" -c "import sys, pathlib; print('Python:',sys.version); print('Root:',pathlib.Path.cwd())"
echo.
"runtime\python\python.exe" "app\localgeoai\api\web_server.py"
set EC=%ERRORLEVEL%
echo.
echo Exit code: %EC%
pause
exit /b %EC%
