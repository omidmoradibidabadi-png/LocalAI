@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp006_INSTALL_OPTIONAL_GIS.ps1"
pause
