﻿$ErrorActionPreference="Stop"
$Root=Split-Path -Parent $MyInvocation.MyCommand.Path
$Py=Join-Path $Root "runtime\python\python.exe"
$Pip=Join-Path $Root "runtime_packages\pip.pyz"
if(!(Test-Path $Py)){throw "Build runtime first."}
if(!(Test-Path $Pip)){Invoke-WebRequest -UseBasicParsing "https://bootstrap.pypa.io/pip/pip.pyz" -OutFile $Pip}
$site=Join-Path $Root "runtime\python\Lib\site-packages"
& $Py $Pip install --disable-pip-version-check --target $site "geopandas>=1.0,<2" "pyogrio>=0.10,<1"
if($LASTEXITCODE -ne 0){throw "GIS dependency installation failed."}
Write-Host "[OK] Optional GeoPandas/pyogrio installed." -ForegroundColor Green
