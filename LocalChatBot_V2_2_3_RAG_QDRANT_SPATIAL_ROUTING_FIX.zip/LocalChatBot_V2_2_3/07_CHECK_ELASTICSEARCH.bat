@echo off
powershell -NoProfile -Command "try {$r=Invoke-RestMethod http://127.0.0.1:9200 -TimeoutSec 3; Write-Host 'Elasticsearch READY'; $r.version.number} catch {Write-Host 'Elasticsearch NOT RUNNING'; exit 1}"
pause
