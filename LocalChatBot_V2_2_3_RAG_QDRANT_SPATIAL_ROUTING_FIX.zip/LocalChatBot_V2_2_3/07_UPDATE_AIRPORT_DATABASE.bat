﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "URL=https://davidmegginson.github.io/ourairports-data/airports.csv"
set "OUT=%~dp0data\spatial\builtin\airports_world_ourairports.csv"
if not exist "%~dp0data\spatial\builtin" mkdir "%~dp0data\spatial\builtin"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri '%URL%' -OutFile '%OUT%'"
echo Done. Start UI and use this CSV as kind=airport, or use the in-app updater.
pause
