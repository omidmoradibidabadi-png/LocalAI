@echo off
cd /d "%~dp0"
if exist runtime\python\python.exe (runtime\python\python.exe tests\test_v6.py) else (python tests\test_v6.py)
pause
