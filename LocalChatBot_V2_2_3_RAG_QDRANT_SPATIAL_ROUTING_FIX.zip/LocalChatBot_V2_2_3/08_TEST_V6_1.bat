@echo off
cd /d "%~dp0"
runtime\python\python.exe tests\test_v6_1.py
pause
