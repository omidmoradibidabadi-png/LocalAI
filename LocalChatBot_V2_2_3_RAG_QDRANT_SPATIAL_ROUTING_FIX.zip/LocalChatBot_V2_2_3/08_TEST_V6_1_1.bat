@echo off
setlocal
cd /d "%~dp0"
echo === V6.1.1 source/regression tests ===
runtime\python\python.exe tests\test_v6_1.py
if errorlevel 1 goto :fail
echo.
echo === Portable runtime capabilities ===
runtime\python\python.exe tools\validate_runtime.py
if errorlevel 1 goto :warn
echo.
echo V6.1.1 TESTS: PASS
pause
exit /b 0
:warn
echo.
echo Source tests PASS, but one or more core runtime parsers are missing.
pause
exit /b 1
:fail
echo.
echo V6.1.1 TESTS: FAIL
pause
exit /b 1
