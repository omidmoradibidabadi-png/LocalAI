@echo off
cd /d "%~dp0"
if not exist "runtime\python\python.exe" echo Portable Python missing.& pause & exit /b 2
"runtime\python\python.exe" "tools\validate_runtime.py"
echo.
"runtime\python\python.exe" -m compileall -q app tools tests
if errorlevel 1 (echo SOURCE COMPILE: FAIL) else (echo SOURCE COMPILE: PASS)
pause
