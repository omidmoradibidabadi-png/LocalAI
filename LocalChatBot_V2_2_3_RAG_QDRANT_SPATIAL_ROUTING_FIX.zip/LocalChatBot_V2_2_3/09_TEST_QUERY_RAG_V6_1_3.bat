@echo off
setlocal
cd /d "%~dp0"
set "PY=runtime\python\python.exe"
if not exist "%PY%" set "PY=python"
"%PY%" tools\test_query_pipeline_v613.py
pause
