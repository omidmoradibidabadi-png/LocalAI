@echo off
setlocal
cd /d "%~dp0"
if exist "runtime\python\python.exe" (
  "runtime\python\python.exe" tools\test_local_aviation_v614.py
) else (
  python tools\test_local_aviation_v614.py
)
pause
