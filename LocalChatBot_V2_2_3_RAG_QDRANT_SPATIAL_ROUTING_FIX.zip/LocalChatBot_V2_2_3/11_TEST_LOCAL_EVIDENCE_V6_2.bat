@echo off
cd /d "%~dp0"
set PY=runtime\python\python.exe
if not exist "%PY%" set PY=python
"%PY%" tools\test_local_evidence_v620.py
pause
