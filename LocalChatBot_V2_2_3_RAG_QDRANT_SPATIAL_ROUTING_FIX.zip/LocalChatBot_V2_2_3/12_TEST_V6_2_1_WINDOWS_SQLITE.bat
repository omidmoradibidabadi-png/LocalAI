@echo off
setlocal
cd /d "%~dp0"
set PYTHONPATH=%CD%
if exist "runtime\python\python.exe" (
  "runtime\python\python.exe" tools\test_windows_sqlite_lifecycle_v621.py
) else (
  python tools\test_windows_sqlite_lifecycle_v621.py
)
if errorlevel 1 (
  echo V6.2.1 Windows SQLite lifecycle: FAILED
  pause
  exit /b 1
)
echo.
echo Now running the Local Evidence regression...
if exist "runtime\python\python.exe" (
  "runtime\python\python.exe" tools\test_local_evidence_v620.py
) else (
  python tools\test_local_evidence_v620.py
)
if errorlevel 1 (
  echo V6.2.1 Local Evidence regression: FAILED
  pause
  exit /b 1
)
echo V6.2.1 ALL TESTS: PASS
pause
