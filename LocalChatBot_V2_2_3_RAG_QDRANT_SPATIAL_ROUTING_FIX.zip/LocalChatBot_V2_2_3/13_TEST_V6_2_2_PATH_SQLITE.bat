@echo off
setlocal
set "ROOT=%~dp0"
cd /d "%ROOT%"
set "PYTHONPATH=%ROOT%"
set "PYEXE=%ROOT%runtime\python\python.exe"
if not exist "%PYEXE%" set "PYEXE=python"

"%PYEXE%" "%ROOT%tools\test_launcher_path_v622.py"
if errorlevel 1 goto :fail
"%PYEXE%" "%ROOT%tools\test_windows_sqlite_lifecycle_v621.py"
if errorlevel 1 goto :fail
"%PYEXE%" "%ROOT%tools\test_local_evidence_v620.py"
if errorlevel 1 goto :fail

echo.
echo V6.2.2 ALL TESTS: PASS
pause
exit /b 0
:fail
echo.
echo V6.2.2 TESTS: FAILED
pause
exit /b 1
