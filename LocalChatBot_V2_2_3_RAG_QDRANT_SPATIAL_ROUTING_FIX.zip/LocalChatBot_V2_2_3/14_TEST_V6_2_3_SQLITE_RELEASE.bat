@echo off
setlocal
cd /d "%~dp0"
set "PYTHONPATH=%~dp0;%PYTHONPATH%"
set "PY=%~dp0runtime\python\python.exe"
if not exist "%PY%" set "PY=python"
"%PY%" "%~dp0tools\test_windows_sqlite_lifecycle_v623.py"
if errorlevel 1 goto :fail
"%PY%" "%~dp0tools\test_local_evidence_v620.py"
if errorlevel 1 goto :fail
echo V6.2.3 ALL TESTS: PASS
pause
exit /b 0
:fail
echo V6.2.3 TESTS: FAILED
pause
exit /b 1
