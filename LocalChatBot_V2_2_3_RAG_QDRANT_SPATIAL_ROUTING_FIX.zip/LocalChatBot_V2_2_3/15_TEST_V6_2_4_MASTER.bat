@echo off
setlocal
cd /d "%~dp0"
set "PYTHONPATH=%~dp0;%PYTHONPATH%"
set "PY=%~dp0runtime\python\python.exe"
if not exist "%PY%" set "PY=python"
"%PY%" "%~dp0tools\test_v624_master_lifecycle.py"
if errorlevel 1 goto :fail
"%PY%" -m compileall -q "%~dp0app" "%~dp0tools"
if errorlevel 1 goto :fail
echo V6.2.4 ALL TESTS: PASS
pause
exit /b 0
:fail
echo V6.2.4 TESTS: FAILED
pause
exit /b 1
