@echo off
setlocal
cd /d "%~dp0"
set "PY=%~dp0runtime\python\python.exe"
if not exist "%PY%" set "PY=python"
set "PYTHONPATH=%~dp0;%PYTHONPATH%"
"%PY%" "%~dp0tools\test_v630_multimodal.py"
if errorlevel 1 (echo V6.3 TESTS: FAILED&pause&exit /b 1)
echo V6.3 ALL TESTS: PASS
pause
