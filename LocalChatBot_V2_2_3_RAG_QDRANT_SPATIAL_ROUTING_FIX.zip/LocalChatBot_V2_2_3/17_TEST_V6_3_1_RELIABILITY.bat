@echo off
setlocal
cd /d "%~dp0"
set "PYTHONPATH=%~dp0"
set "PY=%~dp0runtime\python\python.exe"
if not exist "%PY%" set "PY=python"
"%PY%" tools\test_v631_reliability.py
if errorlevel 1 (echo V6.3.1 TESTS: FAILED& pause& exit /b 1)
echo V6.3.1 ALL TESTS: PASS
pause
