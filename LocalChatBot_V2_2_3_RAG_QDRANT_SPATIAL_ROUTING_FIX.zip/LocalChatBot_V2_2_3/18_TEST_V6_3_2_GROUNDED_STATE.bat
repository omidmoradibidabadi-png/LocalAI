@echo off
setlocal
cd /d "%~dp0"
set "PY=%~dp0runtime\python\python.exe"
if not exist "%PY%" set "PY=python"
set "PYTHONPATH=%~dp0;%PYTHONPATH%"
"%PY%" "%~dp0tools\test_v632_grounded_state.py"
if errorlevel 1 (echo V6.3.2 TESTS: FAILED&pause&exit /b 1)
echo V6.3.2 ALL TESTS: PASS
pause
