@echo off
setlocal
cd /d "%~dp0"
echo === V6.3.3 direct Gemma generation diagnostic ===
if exist "runtime\python\python.exe" (
  "runtime\python\python.exe" tools\test_llm_generation_v633.py
) else (
  python tools\test_llm_generation_v633.py
)
set RC=%ERRORLEVEL%
echo.
if %RC%==0 (echo V6.3.3 GENERATION TEST: PASS) else (echo V6.3.3 GENERATION TEST: FAILED)
echo Diagnostic log: logs\llm_generation_diagnostics.jsonl
pause
exit /b %RC%
