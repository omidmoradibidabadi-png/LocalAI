@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set "PY=runtime\python\python.exe"
if not exist "%PY%" (echo [FAIL] Portable Python not found.& pause & exit /b 1)
echo === V6.3.4 reasoning-aware Gemma generation test ===
"%PY%" tools\test_llm_generation_v634.py
if errorlevel 1 (
 echo.
 echo V6.3.4 GENERATION TEST: FAILED
 echo Diagnostic log: logs\llm_generation_diagnostics.jsonl
 pause
 exit /b 1
)
echo.
echo V6.3.4 GENERATION TEST: PASS
pause
