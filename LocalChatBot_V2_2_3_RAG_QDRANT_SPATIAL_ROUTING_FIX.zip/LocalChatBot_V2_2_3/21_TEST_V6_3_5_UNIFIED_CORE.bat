@echo off
setlocal
cd /d "%~dp0"
set "PY=runtime\python\python.exe"
if not exist "%PY%" set "PY=python"
echo === V6.3.5 Unified Data ^& Intelligence Core ===
%PY% -m compileall -q app tools\test_v635_unified_core.py
if errorlevel 1 goto :fail
%PY% tools\test_v635_unified_core.py
if errorlevel 1 goto :fail
echo.
echo V6.3.5 CORE TEST: PASS
pause
exit /b 0
:fail
echo.
echo V6.3.5 CORE TEST: FAILED
pause
exit /b 1
