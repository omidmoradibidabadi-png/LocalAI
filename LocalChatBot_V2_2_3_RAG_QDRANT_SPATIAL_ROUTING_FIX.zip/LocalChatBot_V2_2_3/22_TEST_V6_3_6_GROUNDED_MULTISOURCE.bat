@echo off
cd /d "%~dp0"
echo === V6.3.6 Grounded Multi-Source + Spatial ===
if exist runtime\python\python.exe (runtime\python\python.exe tools\test_v636_grounded_multisource.py) else (python tools\test_v636_grounded_multisource.py)
if errorlevel 1 (echo V6.3.6 TEST: FAILED) else (echo V6.3.6 TEST: PASS)
pause
