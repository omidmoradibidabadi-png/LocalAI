@echo off
setlocal
cd /d "%~dp0"
set PY=runtime\python\python.exe
if not exist "%PY%" set PY=python
"%PY%" tools\test_v637_reliability.py
if errorlevel 1 (echo.&echo V6.3.7 TEST: FAILED) else (echo.&echo V6.3.7 TEST: PASS)
pause
