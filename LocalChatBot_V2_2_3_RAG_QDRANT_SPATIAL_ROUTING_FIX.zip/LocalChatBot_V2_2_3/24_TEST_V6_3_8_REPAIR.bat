@echo off
setlocal
cd /d "%~dp0"
echo === V6.3.8 Evidence Citation Spatial Repair ===
if exist runtime\python\python.exe (set PY=runtime\python\python.exe) else (set PY=python)
"%PY%" -m compileall -q app tools\test_v638_repair.py
if errorlevel 1 goto fail
"%PY%" tools\test_v638_repair.py
if errorlevel 1 goto fail
echo.
echo V6.3.8 CORE TEST: PASS
pause
exit /b 0
:fail
echo.
echo V6.3.8 CORE TEST: FAILED
pause
exit /b 1
