@echo off
runtime\python\python.exe tools\test_v640.py
pause
