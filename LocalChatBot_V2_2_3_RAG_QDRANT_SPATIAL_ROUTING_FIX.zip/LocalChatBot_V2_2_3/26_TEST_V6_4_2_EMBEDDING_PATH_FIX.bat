@echo off
chcp 65001 >nul
cd /d "%~dp0"
runtime\python\python.exe tools\test_v642_embedding_path_fix.py
pause
