@echo off
setlocal
cd /d "%~dp0"
echo LocalGeoAI V6.4.3 LLM Query Planner - static tests
runtime\python\python.exe tools\test_v643_llm_planner.py
pause
