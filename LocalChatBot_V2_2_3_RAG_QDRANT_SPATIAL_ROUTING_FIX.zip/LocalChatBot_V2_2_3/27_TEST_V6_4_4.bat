@echo off
setlocal
cd /d "%~dp0"
if exist "runtime\python\python.exe" (
  "runtime\python\python.exe" tools\test_v644.py
) else (
  python tools\test_v644.py
)
pause
