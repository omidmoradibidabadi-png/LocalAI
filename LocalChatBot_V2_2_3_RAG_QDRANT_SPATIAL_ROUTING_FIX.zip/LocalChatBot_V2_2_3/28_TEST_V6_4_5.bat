@echo off
setlocal
cd /d "%~dp0"
runtime\python\python.exe tools\test_v645.py
pause
