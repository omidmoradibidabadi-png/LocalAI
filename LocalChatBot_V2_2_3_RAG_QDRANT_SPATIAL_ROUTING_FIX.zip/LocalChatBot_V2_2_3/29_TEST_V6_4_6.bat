@echo off
setlocal
cd /d "%~dp0"
echo === V6.4.6 static regression ===
runtime\python\python.exe -m py_compile app\localgeoai\ingestion\ocr_engine.py app\localgeoai\ingestion\universal_parser.py app\localgeoai\enterprise\omni.py app\localgeoai\model_manager.py app\localgeoai\api\web_server.py
if errorlevel 1 exit /b 1
runtime\python\python.exe -c "from app.localgeoai.ingestion.ocr_engine import status; print('OCR:',status())"
echo Test in UI: airports of Iran map, one known PDF RAG question, then OCR image/PDF in Auto mode.
endlocal
