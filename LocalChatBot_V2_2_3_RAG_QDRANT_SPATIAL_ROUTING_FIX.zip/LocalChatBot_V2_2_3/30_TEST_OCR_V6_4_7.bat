@echo off
setlocal
cd /d "%~dp0"
echo === LocalGeoAI V6.4.7 OCR Preflight ===
if exist "runtime\ocr\tesseract.exe" (echo [OK] OCR engine) else (echo [FAIL] runtime\ocr\tesseract.exe missing)
for %%L in (fas eng ara heb chi_sim chi_tra) do (
  if exist "runtime\ocr\tessdata\%%L.traineddata" (echo [OK] %%L) else (echo [FAIL] %%L)
)
if exist "runtime\python\python.exe" (
  "runtime\python\python.exe" -c "from app.localgeoai.ingestion.ocr_engine import status; import json; print(json.dumps(status(),ensure_ascii=False,indent=2))"
) else (
  python -c "from app.localgeoai.ingestion.ocr_engine import status; import json; print(json.dumps(status(),ensure_ascii=False,indent=2))"
)
pause
