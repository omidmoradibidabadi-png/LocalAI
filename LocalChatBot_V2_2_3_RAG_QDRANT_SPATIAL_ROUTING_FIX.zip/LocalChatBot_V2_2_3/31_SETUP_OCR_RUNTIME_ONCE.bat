@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo === LocalGeoAI V6.4.8 OCR Runtime Setup ===
if exist "runtime\ocr\tesseract.exe" goto verify
set "URL=https://digi.bib.uni-mannheim.de/tesseract/tesseract-ocr-w64-setup-5.5.0.20241111.exe"
set "SETUP=%TEMP%\localgeoai-tesseract-setup.exe"
echo Downloading Windows Tesseract runtime for development...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing '%URL%' -OutFile '%SETUP%'"
if errorlevel 1 goto fail
if not exist "%SETUP%" goto fail
if not exist "runtime\ocr" mkdir "runtime\ocr"
echo Installing privately into runtime\ocr ...
"%SETUP%" /S /D=%CD%\runtime\ocr
if errorlevel 1 goto fail
:verify
if not exist "runtime\ocr\tesseract.exe" goto fail
for %%L in (fas eng ara heb chi_sim chi_tra osd) do (
 if not exist "runtime\ocr\tessdata\%%L.traineddata" echo [WARN] %%L.traineddata missing
)
echo [OK] OCR runtime present.
"runtime\ocr\tesseract.exe" --version
"runtime\ocr\tesseract.exe" --list-langs
pause
exit /b 0
:fail
echo [FAIL] OCR runtime setup failed. Existing LocalGeoAI files were not changed.
pause
exit /b 1
