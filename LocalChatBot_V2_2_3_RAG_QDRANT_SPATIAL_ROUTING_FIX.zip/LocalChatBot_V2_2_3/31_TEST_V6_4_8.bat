@echo off
setlocal
cd /d "%~dp0"
set "PYTHONPATH=%~dp0"
echo === V6.4.8 Regression / OCR / Runtime Test ===
if exist "runtime\ocr\tesseract.exe" (echo [OK] tesseract.exe) else (echo [FAIL] tesseract.exe - run 32_IMPORT_INSTALLED_TESSERACT.bat)
for %%L in (fas eng ara heb chi_sim chi_tra osd) do if exist "runtime\ocr\tessdata\%%L.traineddata" (echo [OK] %%L) else (echo [FAIL] %%L)
if exist "runtime\python\python.exe" (
 "runtime\python\python.exe" -m py_compile app\localgeoai\main.py app\localgeoai\model_manager.py app\localgeoai\ingestion\ocr_engine.py
 "runtime\python\python.exe" -c "from app.localgeoai.ingestion.ocr_engine import status; import json; print(json.dumps(status(),ensure_ascii=False,indent=2))"
) else (
 python -m py_compile app\localgeoai\main.py app\localgeoai\model_manager.py app\localgeoai\ingestion\ocr_engine.py
 python -c "from app.localgeoai.ingestion.ocr_engine import status; import json; print(json.dumps(status(),ensure_ascii=False,indent=2))"
)
pause
