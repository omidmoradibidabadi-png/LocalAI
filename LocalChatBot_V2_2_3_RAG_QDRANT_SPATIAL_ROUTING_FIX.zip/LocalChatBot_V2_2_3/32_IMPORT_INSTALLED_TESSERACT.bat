@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "SRC=C:\Program Files\Tesseract-OCR"
set "DST=%~dp0runtime\ocr"

echo === LocalGeoAI - Import Installed Tesseract ===
if not exist "%SRC%\tesseract.exe" (
  echo [FAIL] Tesseract was not found at:
  echo        %SRC%\tesseract.exe
  echo.
  echo If you installed it elsewhere, edit SRC in this BAT file.
  pause
  exit /b 1
)

if not exist "%DST%" mkdir "%DST%"
if not exist "%DST%\tessdata" mkdir "%DST%\tessdata"

echo [1/3] Copying tesseract.exe...
copy /Y "%SRC%\tesseract.exe" "%DST%\tesseract.exe" >nul || goto :fail

echo [2/3] Copying runtime DLLs...
for %%F in ("%SRC%\*.dll") do copy /Y "%%~fF" "%DST%\%%~nxF" >nul

rem Keep LocalGeoAI's multilingual traineddata. Copy ancillary config files if available.
if exist "%SRC%\tessdata\configs" xcopy /E /I /Y "%SRC%\tessdata\configs" "%DST%\tessdata\configs" >nul
if exist "%SRC%\tessdata\tessconfigs" xcopy /E /I /Y "%SRC%\tessdata\tessconfigs" "%DST%\tessdata\tessconfigs" >nul
if exist "%SRC%\tessdata\pdf.ttf" copy /Y "%SRC%\tessdata\pdf.ttf" "%DST%\tessdata\pdf.ttf" >nul

set "TESSDATA_PREFIX=%DST%\tessdata"
echo [3/3] Verifying portable OCR runtime...
"%DST%\tesseract.exe" --version
if errorlevel 1 goto :fail
"%DST%\tesseract.exe" --list-langs
if errorlevel 1 goto :fail

echo.
echo [OK] Portable OCR runtime imported to:
echo      %DST%
echo You can now run 31_TEST_V6_4_8.bat.
pause
exit /b 0

:fail
echo.
echo [FAIL] Import or verification failed.
pause
exit /b 1
