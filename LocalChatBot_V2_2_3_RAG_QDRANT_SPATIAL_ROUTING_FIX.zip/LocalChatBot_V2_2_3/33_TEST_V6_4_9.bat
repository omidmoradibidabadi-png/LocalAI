@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "ROOT=%~dp0"
echo === LocalGeoAI V6.4.9 OCR / LLM Test - FIXED ===
echo [OK] Project root: %ROOT%

if exist "%ROOT%runtime\ocr\tesseract.exe" (
  echo [OK] Portable tesseract.exe
) else (
  echo [FAIL] Portable tesseract.exe missing
)

set "PYEXE=%ROOT%runtime\python\python.exe"
if not exist "%PYEXE%" set "PYEXE=python"

echo.
echo === Python / OCR module ===
"%PYEXE%" -c "import os,sys; sys.path.insert(0, os.getcwd()); import app; print('[OK] Python import: app'); from app.localgeoai.ingestion.ocr_engine import status; import json; print(json.dumps(status(True), ensure_ascii=False, indent=2))"
if errorlevel 1 echo [FAIL] Python/OCR module test failed

echo.
echo === Portable Tesseract languages ===
if exist "%ROOT%runtime\ocr\tesseract.exe" (
  "%ROOT%runtime\ocr\tesseract.exe" --tessdata-dir "%ROOT%runtime\ocr\tessdata" --list-langs
) else (
  echo [FAIL] Cannot test OCR languages because tesseract.exe is missing
)

echo.
echo === Generation health :8081 ===
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-RestMethod -Uri 'http://127.0.0.1:8081/health' -TimeoutSec 5; Write-Host '[OK] /health'; ConvertTo-Json -InputObject $r -Depth 6 -Compress } catch { Write-Host ('[FAIL] /health: ' + $_.Exception.Message); exit 2 }"

echo.
echo === Generation model :8081 ===
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-RestMethod -Uri 'http://127.0.0.1:8081/v1/models' -TimeoutSec 5; Write-Host '[OK] /v1/models'; ConvertTo-Json -InputObject $r -Depth 8 -Compress } catch { Write-Host ('[FAIL] /v1/models: ' + $_.Exception.Message); exit 3 }"

echo.
echo === End of test ===
pause
endlocal
