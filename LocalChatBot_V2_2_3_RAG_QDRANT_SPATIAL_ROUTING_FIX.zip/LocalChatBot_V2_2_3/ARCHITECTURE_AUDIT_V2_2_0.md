# LocalChatBot V2.2.0 architecture audit

Audit performed before V2.2.0 edits against V2.1.3.

## Findings
- Primary web planner was LLM-based, but legacy keyword routing remained in `intent_router.py`, `_kind_hint/_comprehensive`, `spatial/nl_router.py`, and query-word post-filters in `web_server.py`.
- `web_server.py` still forced `domain=general` into local RAG, making ordinary conversation fail closed.
- Planner output did not carry semantic/lexical reformulations into `UnifiedEngine` retrieval.
- llama.cpp generation startup used `-ngl`, but hardware policy `gpu_priority` could blindly request 999 layers; runtime status did not verify actual offload from llama logs.
- `runtime_hardware.py` explicitly returned `embedding_gpu_layers=0`, forcing EmbeddingGemma to CPU even on CUDA systems.
- LLM calls were duplicated across planner, web aliases, diagnostics, spatial planner, and main helper.
- File/folder ingestion endpoints were synchronous and could leave the browser waiting indefinitely.
- Canonical status was still coarser than the desired per-subsystem state model.

## V2.2.0 changes
- Added centralized `orchestrator/llm_client.py` with bounded context, HTTP error-body capture and JSON mode.
- Replaced the primary query planner with semantic structured planning and retrieval reformulations.
- Added bounded conversation state and a true non-RAG conversation route.
- Planner semantic queries now feed targeted retrieval.
- Removed the airport/heliport query-word post-filter from the primary spatial execution branch.
- Added adaptive embedding GPU layers instead of unconditional CPU embedding.
- Added llama.cpp log parsing for real generation/embedding offload status.
- Added asynchronous path ingestion job endpoint and UI polling.

## Remaining legacy code
Legacy keyword modules remain in the tree for compatibility/fallback with old paths. They are not intended to be authoritative in the V2.2.0 primary `/api/ask` planner path. Future cleanup can remove them after Windows regression testing.
