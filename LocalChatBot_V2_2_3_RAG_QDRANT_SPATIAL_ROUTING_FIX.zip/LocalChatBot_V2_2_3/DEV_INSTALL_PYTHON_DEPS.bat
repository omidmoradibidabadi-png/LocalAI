@echo off
setlocal
cd /d "%~dp0"
py -3.11 -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install fastapi uvicorn pydantic PyMuPDF qdrant-client
REM llama-cpp-python CUDA runtime will be pinned after the RTX 5090 full probe.
echo.
echo Base dependencies installed. llama-cpp-python CUDA build is intentionally handled separately.
pause
