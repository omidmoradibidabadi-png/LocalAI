# LocalChatBot V1.0.0

Branched from LocalGeoAI V7.0.1. Satellite imagery / remote-sensing analysis modules are removed. General local document/email/image OCR, hybrid retrieval, Qdrant, Elasticsearch, SQLite, GIS/spatial catalog and map remain. Persistent data defaults to `../LocalChatBot_PersistentData`.

## Map UX
The map panel is simplified for everyday use: clear data import, place/radius search, result count, home/fit/clear controls, and a larger map canvas. Online OSM basemap is used when internet is available; spatial results and local GIS analysis remain local-data-only.
