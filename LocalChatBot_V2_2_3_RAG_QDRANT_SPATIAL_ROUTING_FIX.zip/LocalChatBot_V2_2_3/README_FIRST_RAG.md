# LocalGeoAI V3 – First Real RAG Application

این نسخه اولین هسته کاربردی RAG است و از Runtime موفق مرحله قبل استفاده می‌کند.

## فایل‌های بزرگ را دوباره کپی نکنید
اگر از پوشه قبلی به این نسخه جدید آمده‌اید، مدل‌ها، qdrant.exe و سه ZIP runtime را در مسیرهای متناظر این پوشه قرار دهید و سپس 01_BUILD_RUNTIME.bat را اجرا کنید.

## ترتیب اجرا
1. `01_BUILD_RUNTIME.bat`
2. `00_INSTALL_APP_DEPS.bat` — فقط یک بار برای PyMuPDF در محیط توسعه
3. `03_START_RAG.bat`

داخل Shell:
- افزودن سند: `/add "E:\path\manual.pdf"`
- خروج: `/quit`
- هر متن دیگر یک سؤال است.

روش ساده‌تر برای ورود سند:
یک PDF/DOCX/TXT/MD را روی `04_INGEST_FILE.bat` Drag & Drop کنید.

## نکات معماری
- Generation و Embedding از طریق HTTP و llama-server اجرا می‌شوند.
- Qdrant از طریق REST استفاده می‌شود؛ Python SDK لازم نیست.
- DOCX با کتابخانه استاندارد Python خوانده می‌شود.
- PDF فعلاً با PyMuPDF خوانده می‌شود.
- PDF اسکن‌شده در این مرحله متن قابل استخراج ندارد؛ OCR در ماژول بعدی اضافه می‌شود.
- شناسه chunkها deterministic است؛ ingest دوباره همان فایل، duplicate تصادفی تولید نمی‌کند.
- source، page، chunk_index و SHA-256 در payload Qdrant حفظ می‌شوند.
- مسیرهای مدل و سرویس‌ها از config.json خوانده می‌شوند.
