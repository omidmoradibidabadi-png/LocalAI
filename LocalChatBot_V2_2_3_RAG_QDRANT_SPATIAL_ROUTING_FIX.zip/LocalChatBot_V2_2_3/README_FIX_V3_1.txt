LocalGeoAI V3 Spatial V3.1 UI FIXED

اصلاح مستقیم خطای نسخه V3:
- توابع JavaScript انتخاب فایل/پوشه که در build قبلی وارد HTML نشده بودند، اکنون کامل هستند.
- انتخاب فایل Native ویندوز کار می‌کند.
- انتخاب پوشه Native ویندوز کار می‌کند.
- Browser Upload واقعاً فایل را POST و ingest می‌کند.
- spIngest / nearby / Leaflet map functions بازگردانی و یکپارچه شدند.
- multipart upload سمت Backend با FieldStorage پایدارتر شد.

تست:
1) برنامه را Start کنید.
2) Map > انتخاب فایل > airports.geojson > Open.
3) مسیر باید داخل کادر ظاهر شود.
4) kind=airport
5) افزودن لایه مکانی.
6) باید count + Fields/Names/Codes/Sample نمایش داده شود.
