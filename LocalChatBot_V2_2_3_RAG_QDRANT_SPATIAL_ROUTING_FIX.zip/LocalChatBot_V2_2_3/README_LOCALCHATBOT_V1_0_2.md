# LocalChatBot V1.0.2

UI + Model Registry + Status Synchronization release.

- Redesigned three-column RTL interface.
- Removed the incorrect spatial-model selector. GIS remains a local vector-data engine for SHP/KMZ and related files.
- Added functional LLM model discovery/status UI using `/api/models/llm`.
- Added live engine status synchronization using `/api/health`.
- Enter sends; Shift+Enter inserts a new line.
- Replaceable logo remains at `web/assets/logo.svg`.
- Persistent data architecture, OCR/RAG/retrieval and local-only answer policy are preserved.
- Map code now fails safely when Leaflet cannot load offline; local GIS indexing/querying still works.
