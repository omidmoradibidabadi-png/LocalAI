# LocalChatBot V1.0.3

UI/UX and Windows picker reliability release.

- Unified smaller, cleaner typography across the interface.
- LLM dropdown now starts model hot-swap immediately; activation button removed.
- GIS `auto` control removed from UI; auto-detection remains in backend.
- Fixed `spatial_file` Windows native picker crash and added GIS file filters.
- Main data drop zone is clickable and supports drag & drop files.
- Spatial radius UI now shows `kilometer` beside the numeric field.
- Radius action renamed to Persian `جست‌وجو در شعاع تعیین‌شده`.
- Existing local-only RAG, OCR, retrieval/reranker and persistent data architecture preserved.
