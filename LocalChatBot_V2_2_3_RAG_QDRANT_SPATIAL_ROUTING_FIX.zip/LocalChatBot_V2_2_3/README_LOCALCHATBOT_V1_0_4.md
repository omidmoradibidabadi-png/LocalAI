# LocalChatBot V1.0.4

Hotfix focused on two UI/runtime issues:

- Chat pane now has its own always-available vertical scrollbar and independent mouse-wheel scrolling while the composer remains fixed.
- All Windows native file/folder pickers are opened with a temporary topmost owner window so dialogs stay in front of the browser.

No RAG, OCR, retrieval/reranker, GIS indexing, or persistent-data behavior was intentionally changed.
