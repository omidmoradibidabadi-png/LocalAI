# LocalChatBot V1.0.6 — Portable Offline Startup Hotfix

Changes:
- Preflight now inserts the project root into sys.path before importing app.* modules.
- Elasticsearch is now started and managed by RuntimeManager.
- Portable Elasticsearch is launched through its bundled JDK (ES_JAVA_HOME).
- Elasticsearch uses persistent data/log directories under LocalChatBot_PersistentData.
- Elasticsearch is forced to local-only single-node mode on 127.0.0.1:9200 with security disabled for this isolated local application.
- Startup waits up to 120 seconds for Elasticsearch and writes startup diagnostics to logs/elasticsearch.*.log.
- Existing Qdrant, generation and embedding startup remains managed locally.

No internet access is required by this startup path when all runtimes/models/offline map assets are present.
