# LocalChatBot V1.0.7 — Offline Basemap Hotfix

- Adds `/api/maps/status`.
- Serves `LocalChatBot_PersistentData/maps/world/osm_world_z0_z6.pmtiles` with HTTP byte ranges.
- Uses PMTiles as the only basemap source; no online tile fallback.
- Removes text/symbol layers from the minimal style so glyph/font downloads are not required offline.
- Shows the exact expected PMTiles path when the file is missing.
- Keeps local GIS result overlays.

Required local browser libraries: `web/vendor/maplibre-gl.js`, `web/vendor/maplibre-gl.css`, `web/vendor/pmtiles.js`.
The PMTiles archive itself remains in PersistentData and is not duplicated inside each app version.
