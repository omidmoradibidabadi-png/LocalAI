# LocalChatBot V2.0.1

Major analysis release.

## 1) Complete spatial result presentation
Spatial filters return the complete result set to the map and result table. Chat text stays readable with a 30-item preview and explicitly reports preview/total counts. The result table supports incremental +100 and Show All.

## 2) Corpus Analysis (email)
Analytical collection requests such as "analyze all emails" no longer use Top-K retrieval as the corpus. The email catalog is enumerated exhaustively, processed in batches, converted to structured intermediate findings, hierarchically reduced, and synthesized into a final local-evidence-only report. Responses include coverage metadata (processed/total/batches/failures).

Normal targeted email questions continue to use retrieval mode.

Offline runtime, persistent data, Qdrant, Elasticsearch, local GGUF models, OCR, GIS, and PMTiles basemap behavior are inherited from V1.0.7.
