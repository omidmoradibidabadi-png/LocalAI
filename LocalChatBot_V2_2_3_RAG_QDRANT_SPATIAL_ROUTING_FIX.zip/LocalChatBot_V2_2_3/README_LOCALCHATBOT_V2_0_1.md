# LocalChatBot V2.0.1

Hotfix for exhaustive corpus analysis.

- Exhaustive email analysis reconciles the email catalog from the Canonical Store before analysis, so it uses the same locally indexed EML/MSG population rather than an independent folder-only view.
- Corpus analysis runs as a background job; the web UI remains responsive.
- Real progress is reported from backend processing: processed/total, percentage, batch/current batches, failed batches, elapsed time, estimated remaining time, and current stage.
- Final coverage remains attached to the answer.
- Existing V2.0.0 spatial full-result table/map behavior and offline PMTiles basemap are retained.
