# LocalChatBot V2.0.2 — Canonical Corpus Accuracy Hotfix

- Canonical Store is the single source of truth for email corpus analysis.
- Exhaustive and filtered-corpus analysis parse every canonical EML/MSG source directly.
- New planner mode: `filtered` for questions such as “which emails discuss X and what do they say?”.
- Filtered mode scans the full canonical email corpus batch-by-batch; Top-K/Reranker cannot exclude corpus members.
- Progress/ETA applies to exhaustive and filtered scans.
- Integrity ledger reports canonical/readable/failed counts.
- Incremental unchanged email ingestion reconstructs a missing derived EmailCatalog row after portable upgrades.
