# LocalChatBot V2.1.0 — Universal Corpus + Unified GIS + Persian/OCR upgrade

Built from V2.0.2 according to the attached Next Version context.

Key changes:
- UniversalCorpusAnalyzer enumerates Canonical Store sources for exhaustive corpus analysis instead of Top-K RAG membership.
- Query planner exposes retrieval / filtered_corpus / exhaustive / structured / spatial / mixed / conversational modes.
- Persian search normalization (Arabic/Persian character variants, digits, ZWNJ/Unicode/whitespace) plus lexical + semantic fallback.
- DOCX embedded raster images can be OCRed in AUTO/FORCE mode; scanned PDF/image OCR remains supported.
- Main Bank Data ingestion already auto-routes GIS formats through OmniIndex; separate GIS upload/search UI was removed.
- Map remains as an output visualization surface and offline PMTiles Z0-Z6 support is preserved.
- Spatial result text is no longer arbitrarily limited to the first 30 rows.
- Real generic corpus progress uses the existing analysis job/status mechanism.
- Conversational planner mode can answer greetings/help without pretending local evidence is required.

Important: fully exercising Gemma/Qdrant/Elasticsearch/Tesseract/PMTiles requires the Windows local runtime and local persistent data. Static Python/JavaScript/package validation is included in this build.
