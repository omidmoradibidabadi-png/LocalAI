# LocalChatBot V2.1.2

Corrective release based on V2.1.2.

- Universal Corpus Analysis now scans complete extracted text in bounded segments and performs hierarchical Map/Reduce. Top-K RAG is not used for exhaustive requests.
- Exhaustive analysis fails explicitly if any LLM segment fails; it no longer publishes a misleading successful 0/0 report.
- GIS ingestion through the normal Data Bank path supports SHP, KML, KMZ, GeoJSON and GPKG through the existing OmniIndex -> SpatialCatalog route.
- KMZ is extracted locally before OGR reading. Shapefile validates required SHX/DBF sidecars. KML without CRS metadata is treated as WGS84.
- Offline-map files no longer prevent the entire chatbot from starting. Missing PMTiles/MapLibre assets are reported as WARN and only degrade the basemap.
- Existing focused RAG/OCR path was intentionally left unchanged.

Offline basemap location:
LocalChatBot_PersistentData/maps/world/osm_world_z0_z6.pmtiles

For browser-uploaded Shapefiles, prefer selecting the containing folder so SHP/SHX/DBF/PRJ remain together. Native local-file selection can index an SHP when its sidecars are already in the same source folder.
