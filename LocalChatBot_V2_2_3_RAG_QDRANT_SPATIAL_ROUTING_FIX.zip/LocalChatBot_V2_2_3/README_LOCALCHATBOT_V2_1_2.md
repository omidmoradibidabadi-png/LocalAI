# LocalChatBot V2.1.2

Hotfix for unified spatial ingestion.

- Reconciles spatial derived index even when Canonical Store marks SHP/KML/KMZ/GPKG/GeoJSON unchanged.
- Reconciles coordinate CSV files into SpatialCatalog on re-index.
- Reports existing/recovered GIS feature counts instead of silently skipping spatial indexing.
- Preserves normal incremental behavior for unchanged non-spatial data.

This fixes the upgrade case where a source was already present in Canonical Store but the persistent spatial catalog was empty or had been recreated.
