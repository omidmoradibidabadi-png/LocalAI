# LocalChatBot V2.1.3 — Spatial ingestion completion fix

Fixes the end-to-end Bank Data ingestion path for coordinate CSV and preserves direct SHP/KML/KMZ/GeoJSON/GPKG spatial routing.

Key fix: coordinate CSV no longer waits for full-file serial RAG/EmbeddingGemma indexing after its structured/spatial indexes are complete. Spatial attributes remain queryable through StructuredCatalog and SpatialCatalog. Result includes timing diagnostics and `rag_skipped=coordinate_csv_spatial_fast_path`.
