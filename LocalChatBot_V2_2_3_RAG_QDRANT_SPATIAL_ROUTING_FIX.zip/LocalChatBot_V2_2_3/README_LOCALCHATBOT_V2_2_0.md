# LocalChatBot V2.2.0 — Semantic Agent / GPU Architecture

This is a major architecture correction based on the V2.2.0 project context.

Key changes: semantic LLM planner, bounded multi-turn context, normal conversational answers without RAG, semantic query reformulation passed into retrieval, centralized llama client, adaptive CUDA configuration for generation and embeddings, actual offload-log verification, asynchronous ingestion jobs, and preservation of exhaustive corpus/GIS/structured engines.

On Windows, verify `logs/generation.err.log` and `logs/embedding.err.log`. The health endpoint now exposes parsed runtime offload status. A CUDA DLL existing on disk is not treated as proof of GPU offload.
