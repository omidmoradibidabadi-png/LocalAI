# LocalChatBot V2.2.1 — Ingestion Job Progress Fix

This hotfix repairs the V2.2.0 async ingestion progress pipeline.

- elapsed time is calculated live on every status poll; it no longer depends on worker callbacks.
- folder ingestion enumerates eligible files first and reports real total/current file/progress.
- ingestion jobs maintain last_progress_at and idle_seconds.
- after 300 seconds without progress a watchdog warning is exposed instead of silently showing a frozen 0% UI.
- single-file jobs report their current file and stage.
- the semantic-agent/GPU architecture from V2.2.0 is preserved.
