# LocalChatBot V2.2.2 — Chat → Spatial Map Bridge

Fixes the case where a grounded RAG answer identifies a location but no geometry reaches the map.

Flow: semantic planner (`needs_map`) → grounded answer → LLM map-entity extraction → local SpatialCatalog resolution → GeoJSON attached to `/api/ask` → existing frontend `renderGeoJSON()` opens the map and zooms to local features.

Important: the LLM never supplies coordinates. Coordinates are accepted only from SpatialCatalog rows. No hard-coded airport/place-name table is used.

If the answer names a place that is not indexed in SpatialCatalog, the response sets `requires_map=true` and reports that the entity could not be resolved locally instead of inventing a location.
