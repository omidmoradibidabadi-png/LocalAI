# LocalChatBot V2.2.3

Regression repair release focused on four P0 failures observed in V2.2.2.

## Changes
- Canonical Store `ready/unchanged` no longer implies RAG readiness. Text-bearing sources verify their actual Qdrant point count and rebuild missing embeddings.
- RAG ingestion now reports real chunk embedding progress and Qdrant upsert/verification counts.
- A source is not considered vector-ready until Qdrant verifies the expected inserted points.
- First-time spatial ingestion now uses automatic feature-kind inference instead of forcing every SHP/KML/KMZ/GeoJSON/GPKG feature to generic `feature`.
- Spatial query planning receives the actual local `kind` inventory and separates feature concept (for example airport) from geographic constraint (for example country).
- Mixed questions no longer get hijacked by the email engine merely because the planner returned `mixed`.
- The Bank Data path is no longer silently reused as the scope of every later chat question. This fixes stale `folder_corpus` leakage.
- Internal spatial execution/debug identifiers are no longer displayed as the user-facing spatial note.
- Version bumped to V2.2.3.

## Validation performed
- Python `compileall` passed for the complete `app` tree.
- Static regression assertions passed for Qdrant verification, embedding progress, RAG reconciliation, semantic spatial kind inventory, email routing, and stale scope removal.

## Runtime validation still required on Windows
Real Gemma/EmbeddingGemma/Qdrant/Elasticsearch/GDAL execution depends on the user's portable Windows runtime and models. Test at least:
1. Re-index an unchanged Persian document and confirm `Embedding x/y` and `Qdrant x` advance.
2. Ask a normal corpus question without selecting a scope and confirm it uses global hybrid retrieval.
3. Ask `فرودگاه‌های ایران را روی نقشه نشان بده` and confirm airport kind + country constraint returns mapped features when those attributes exist locally.
