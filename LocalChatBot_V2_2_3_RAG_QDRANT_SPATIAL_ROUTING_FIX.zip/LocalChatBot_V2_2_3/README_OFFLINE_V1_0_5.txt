LocalChatBot V1.0.5 - Offline deployment

This release removes runtime dependence on online OSM tiles. The world basemap is read from:
  ..\LocalChatBot_PersistentData\maps\world\osm_world_z0_z6.pmtiles

Before moving the folder to a disconnected PC, run 00_PREPARE_OFFLINE_BUNDLE.bat once on an internet-connected Windows PC. It vendors MapLibre GL JS + PMTiles JS and copies the already-downloaded world PMTiles file when it is located beside the version folders.

For a completely self-contained AI runtime, these local payloads must exist in the release folder:
  runtime\python\python.exe
  runtime\llama\llama-server.exe (+ CUDA/runtime DLLs)
  runtime\qdrant\qdrant.exe
  runtime\elasticsearch\bin\elasticsearch.bat (+ bundled JDK if used by your ES distribution)
  runtime\ocr\tesseract.exe and tessdata
  models\llm\*.gguf
  models\embedding\exactly one *.gguf

The ZIP generated here cannot contain your multi-GB private/local model and engine payloads because they were not uploaded into this build environment. Copy them from your validated installation, then run 03_START_LOCALCHATBOT.bat with networking disabled to verify the final bundle.
