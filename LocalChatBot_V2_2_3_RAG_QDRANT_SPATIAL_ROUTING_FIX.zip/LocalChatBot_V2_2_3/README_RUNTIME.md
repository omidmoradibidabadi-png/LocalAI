# LocalGeoAI V3 — Gemma GGUF Runtime

This build wires the V3 core to the user's existing local assets. No model or Qdrant download is performed.

## Put the existing files here

- `models/llm/gemma-4-E4B-it-Q4_K_M.gguf`
- `models/embedding/<your-single-embedding-model>.gguf`
- `runtime/qdrant/qdrant.exe`

Alternatively, edit the three paths in `config.json` and point them to their current absolute Windows locations. You do **not** have to copy large model files into the project.

## Runtime behavior

1. Check model paths.
2. Reuse Qdrant if port 6333 is already healthy.
3. Otherwise start the supplied `qdrant.exe` with application-owned storage under `data/qdrant_storage`.
4. Load the embedding GGUF through llama.cpp and detect its vector dimension dynamically.
5. Create/validate a Qdrant collection with that exact dimension.
6. Keep the generation model lazy-loaded until the first answer request.
7. Serve the shared API for the future Web and EXE clients.

## Important

A collection is tied to its embedding vector dimension/model. If the embedding model is changed later, use a new collection name or explicitly re-index the data. The application refuses an incompatible existing collection rather than silently corrupting retrieval.

## Python dependency

The GGUF providers require a CUDA-enabled `llama-cpp-python` build on the target RTX 5090 machine. The final installer will carry the validated runtime/wheel instead of asking the end user to compile it.
