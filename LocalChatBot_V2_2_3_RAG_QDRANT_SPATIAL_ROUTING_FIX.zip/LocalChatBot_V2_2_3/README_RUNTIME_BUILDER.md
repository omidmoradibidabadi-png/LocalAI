# LocalGeoAI V3 – Portable Runtime Builder

این مرحله Python نصب‌شده روی ویندوز را استفاده نمی‌کند.

## قبل از اجرا
سه ZIP دانلودشده را بدون Extract داخل `runtime_packages` قرار دهید.

فایل‌های موجود خودتان نیز باید اینجا باشند:

- `models/llm/gemma-4-E4B-it-Q4_K_M.gguf`
- `models/embedding/<your-single-embedding-model>.gguf`
- `runtime/qdrant/qdrant.exe`

## اجرا
1. روی `01_BUILD_RUNTIME.bat` دوبار کلیک کنید.
2. اگر `PORTABLE RUNTIME BUILD COMPLETED` نمایش داده شد، `02_TEST_AI_RUNTIME.bat` را اجرا کنید.
3. تست دوم به‌ترتیب Qdrant، Gemma و EmbeddingGemma را واقعاً اجرا می‌کند و یک vector آزمایشی داخل Qdrant می‌نویسد.

Runtime Builder نام نسخه ZIPها را hard-code نکرده و محتوای بسته‌ها را بررسی می‌کند.

اگر تست دوم خطا داد، اسکرین‌شات CMD و فایل مرتبط از پوشه `logs` را ارسال کنید.
