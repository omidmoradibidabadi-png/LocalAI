# LocalGeoAI V3.2 — Airport Intelligence

- Resolver: Persian/English/IATA/ICAO aliases
- Offline verified seed: Mehrabad, Mashhad, Isfahan, Tabriz, Shiraz, Bandar Abbas
- Direct OurAirports global database updater in UI
- OurAirports CSV schema support: latitude_deg/longitude_deg
- Radius analysis with bbox prefilter + exact Haversine distance
- Resolver debug button and result table

Test: enter Mehrabad / مهرآباد / THR / OIII, click بررسی نام مرکز, set 700 km and airport, then تحلیل شعاعی. For complete coverage, install the global airport database once from the UI. Subsequent analysis is local.
