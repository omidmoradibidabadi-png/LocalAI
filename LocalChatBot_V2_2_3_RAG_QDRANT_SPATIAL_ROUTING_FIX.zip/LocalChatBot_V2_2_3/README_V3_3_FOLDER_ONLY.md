# LocalGeoAI V3.3 — Folder Only

این نسخه هیچ Download/Update داخلی برای بانک فرودگاه ندارد.
ورود داده مکانی فقط از File/Folder Picker انجام می‌شود.

مسیر پیشنهادی:
data/spatial/world_aviation_geojson/

اگر داده OurAirports را به صورت CSV دارید:
1. airports.csv و runways.csv را در data/source_csv قرار دهید.
2. tools/BUILD_WORLD_AVIATION_GEOJSON.bat را اجرا کنید.
3. دو فایل world_airports.geojson و world_runways.geojson ساخته می‌شود.
4. در UI گزینه انتخاب پوشه را بزنید و پوشه world_aviation_geojson را انتخاب کنید.

military_hint در فایل تولیدی فقط از نام/keywords استنباط می‌شود و طبقه‌بندی رسمی نظامی نیست.
