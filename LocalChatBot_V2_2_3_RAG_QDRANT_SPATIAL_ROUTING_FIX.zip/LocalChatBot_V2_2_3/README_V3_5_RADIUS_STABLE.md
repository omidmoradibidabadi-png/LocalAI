LocalGeoAI V3.5 — Radius Stable

علت قطعی خطای V3.4:
renderSpatialRows() به عنصر HTML با id=spatialResults می‌نوشت، ولی این عنصر در صفحه وجود نداشت.
در نتیجه Backend می‌توانست تحلیل را انجام دهد، اما UI هنگام نمایش پاسخ با
Cannot set properties of null (setting 'innerHTML')
متوقف می‌شد.

اصلاحات:
- spatialResults به DOM اضافه شد.
- renderSpatialRows null-safe شد.
- پاسخ‌های features/results هر دو پشتیبانی می‌شوند.
- airportStatus قدیمی و وابسته به Downloader حذف شد.
- تمام ارجاعات $('...') در JavaScript به صورت خودکار با IDهای واقعی HTML audit شدند.
- Downloader فرودگاه همچنان حذف است.
