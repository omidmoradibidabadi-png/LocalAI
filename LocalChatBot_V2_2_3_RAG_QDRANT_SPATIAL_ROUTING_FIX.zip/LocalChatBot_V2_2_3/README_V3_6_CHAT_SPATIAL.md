V3.6 Chat Spatial
Chat -> deterministic Persian/English radius parser -> resolver -> spatial radius engine -> textual answer + Leaflet map.
Examples:
فرودگاه‌های تا شعاع 50 کیلومتری مهرآباد را روی نقشه نشان بده
فرودگاه ها در شعاع 500 کیلومتر از Mehrabad کدامند؟
airports within 100 km from THR
Non-spatial questions continue to the existing RAG pipeline.
