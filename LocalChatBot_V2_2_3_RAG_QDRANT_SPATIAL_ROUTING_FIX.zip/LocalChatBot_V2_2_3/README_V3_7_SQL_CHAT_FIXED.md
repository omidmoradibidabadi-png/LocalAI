# LocalGeoAI V3.7

رفع خطای `too many SQL variables` هنگام Import مجدد دیتاست‌های بزرگ:
نسخه قبلی برای حذف رکوردهای قدیمی، برای هر Feature یک placeholder می‌ساخت.
برای airports.csv با حدود 86 هزار رکورد از سقف متغیرهای SQLite عبور می‌کرد.
V3.7 حذف را با subquery انجام می‌دهد و فقط یک پارامتر SQL مصرف می‌کند.

همچنین:
- kind=auto برای داده‌های OurAirports به airport/runway/feature تبدیل می‌شود.
- فراخوانی Spatial Engine از Chat اصلاح شد: nearby(lat, lon, radius).
- ابزار RESET_SPATIAL_CATALOG.bat برای پاک‌سازی اختیاری Catalog اضافه شد.
