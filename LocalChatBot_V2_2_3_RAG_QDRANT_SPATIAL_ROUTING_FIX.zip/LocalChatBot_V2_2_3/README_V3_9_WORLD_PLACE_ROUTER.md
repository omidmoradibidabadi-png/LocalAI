LocalGeoAI V3.9
- رفع پیام کاذب مرکز مهرآباد با پاک‌سازی دقیق suffix سؤال.
- اسرائیل/اسرائيل -> IL و مجموعه بزرگ‌تری از نام‌های فارسی کشورها.
- استخراج عمومی نام کشور از سؤال؛ Feature retrieval بر پایه iso_country دیتاست محلی.
- رفع tuple object does not support item assignment با defensive dict copies.
