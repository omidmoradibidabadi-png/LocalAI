# LocalGeoAI V4.1

اصلاحات اصلی:
- انتخاب پوشه فنی با Windows Folder Picker مستقل.
- انتخاب کل پوشه از خود مرورگر با webkitdirectory و آپلود/ایندکس همه فایل‌های پشتیبانی‌شده.
- CSV/JSON/XLSX علاوه بر RAG وارد Structured Technical Catalog می‌شوند.
- پرسش‌های عددی مثل «هواپیماهای با برد زیر 3000 کیلومتر» به‌صورت deterministic روی ردیف‌های واقعی فیلتر می‌شوند.
- «برد» دیگر به‌تنهایی علامت GIS نیست؛ سؤال فنی اشتباهاً وارد Mixed/Spatial نمی‌شود.
- بودجه Context برای Gemma با context=4096 محدود و HTTP 400 ناشی از context overflow با retry محافظه‌کارانه مدیریت می‌شود.
- GeoJSON/Spatial catalog مستقل از بانک فنی باقی می‌ماند و سؤال‌های شعاعی/کشوری قبلی حفظ شده‌اند.
