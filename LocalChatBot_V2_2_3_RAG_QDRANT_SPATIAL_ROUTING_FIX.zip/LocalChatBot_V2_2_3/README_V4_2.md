# LocalGeoAI V4.2 — Fast Local Analyzer

1. رفع باگ مهم Radius Parser: web_server هم‌زمان parser جدید و parser قدیمی را import می‌کرد و import دوم، parser اصلاح‌شده را overwrite می‌کرد. حذف شد.
2. پوشه مکانی:
   - انتخاب پوشه ویندوز اکنون بعد از انتخاب، خودکار همه GeoJSON/JSON/CSV/SHP/GPKG/KML را ingest می‌کند.
   - انتخاب کل پوشه از مرورگر نیز اضافه شد.
3. Fast Structured Engine قبل از LLM اجرا می‌شود:
   - فیلترهای عددی روی ستون‌های واقعی.
   - جست‌وجوی مدل/شناسه/نام و نمایش رکورد واقعی.
   - وابسته به چند سؤال نمونه از پیش‌تعریف‌شده نیست.
4. فقط سؤال‌هایی که Structured Engine نتواند پاسخ دهد وارد RAG+Gemma می‌شوند.
5. RAG fallback سبک‌تر شد: top-k=4، context budget=4800 chars، max output=420؛ برای کاهش زمان پاسخ و جلوگیری از HTTP 400.
