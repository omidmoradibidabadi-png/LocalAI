V4.4 fixes
1) File/folder picker uses Windows PowerShell + WinForms, not Tkinter. Embedded Python normally has no Tkinter.
2) EML is supported directly by the document parser.
3) GeoJSON Point/Polygon/MultiPolygon/LineString/MultiLineString can be ingested. Non-point features receive a representative point for map/catalog analysis.
4) CSV in the spatial panel still requires latitude/longitude. A countries.csv with only country attributes is tabular, not spatial; use the general data bank. For country boundaries use countries.geojson.
5) MSG/PST are recognized but full parsing still requires their optional parser runtime.
