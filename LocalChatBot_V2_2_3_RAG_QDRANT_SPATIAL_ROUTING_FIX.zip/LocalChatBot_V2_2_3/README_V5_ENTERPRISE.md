# LocalGeoAI V5 Enterprise Hybrid
V4.4 retained. Added Enterprise foundation for million-scale collections:
Canonical Store + SHA-256/incremental manifest; Elasticsearch full-text/metadata client; existing Qdrant semantic retrieval; RRF hybrid fusion; planner routes Exact/Email to ES, Semantic to Qdrant, Mixed to both, Numeric to SQLite, GIS to Spatial.
Elasticsearch and Qdrant are independent ingestion destinations.
Elasticsearch binaries are not redistributed in this ZIP. Default endpoint: 127.0.0.1:9200.
Next scale stage: bulk worker pool, complete PST/MSG pipeline, and million-file benchmark.
