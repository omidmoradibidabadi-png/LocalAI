# LocalGeoAI V6.0.1 Hotfix

Fixes Windows WinError 32 during V6 tests by explicitly closing short-lived SQLite connections in ImageCatalog and RasterCatalog. The V6 test also explicitly closes ImageCatalog before TemporaryDirectory cleanup.

Validation performed in build environment:
- Python compileall: PASS
- tests/test_v6.py: PASS
- EML/parser/router/RRF/VisualModelLab/ImageCatalog tests: PASS

Note: Windows-specific file-lock behavior must still be verified on the target Windows machine.
