# LocalGeoAI V6.1.1 Runtime Installer Hotfix

Fixes INSTALL-001 seen on Windows portable Python when `extract-msg` pulled `red-black-tree-mod` source and the isolated build environment could not import `setuptools.build_meta`.

Changes:
- Bootstraps setuptools/wheel/packaging into the portable runtime first.
- Installs parser families independently, so MSG failure cannot cancel PDF/Office/GIS/Raster installation.
- Adds import-level runtime validation and GDAL driver reporting.
- Keeps MSG optional if its dependency chain cannot be built on a particular machine.
- Unifies `00_INSTALL_APP_DEPS` with `00_INSTALL_UNIVERSAL_DEPS`.

Run `00_INSTALL_UNIVERSAL_DEPS.bat`, then `08_TEST_V6_1_1.bat`.
