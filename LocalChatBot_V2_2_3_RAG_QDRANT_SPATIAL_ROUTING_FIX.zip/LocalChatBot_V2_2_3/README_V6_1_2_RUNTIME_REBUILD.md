# LocalGeoAI V6.1.2 Portable Runtime Rebuild

This release fixes the V6.1.1 dependency installer after real Windows testing.

Key changes:
- fixes PowerShell pip exit-code/output handling;
- enables `Lib\\site-packages` and `import site` for embeddable Python;
- installs each parser family independently;
- writes one detailed log per family to `logs\\runtime_install`;
- uses `--no-build-isolation` for extract-msg to avoid the setuptools.build_meta failure seen with red-black-tree-mod;
- validates by actually importing modules, not only `find_spec`;
- writes machine-readable `logs\\runtime_validation.json`;
- keeps external codecs/drivers (Tesseract executable, ECW/MrSID and some HEIC/RAW codecs) optional.

Run `00_INSTALL_UNIVERSAL_DEPS.bat`, then `08_TEST_V6_1_2.bat`.
