# LocalGeoAI V6.1.3 Query/RAG Pipeline Hotfix

Runtime compatibility: V6.1.2. Do NOT reinstall dependencies.

Fixes:
- document questions are RAG-first; structured lookup no longer steals generic numeric questions;
- missing local evidence does not silently fall back to general model knowledge;
- empty LLM responses and timeouts become explicit typed errors;
- UI never leaves a blank assistant bubble;
- UI/app version updated to 6.1.3;
- source panel receives document evidence when RAG answers.

Run `09_TEST_QUERY_RAG_V6_1_3.bat`, then `03_START_LOCALGEOAI.bat`.
