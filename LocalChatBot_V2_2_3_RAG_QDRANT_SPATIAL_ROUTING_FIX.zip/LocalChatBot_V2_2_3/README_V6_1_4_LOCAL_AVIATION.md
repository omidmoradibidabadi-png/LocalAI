# LocalGeoAI V6.1.4 — Local Aviation Intelligence

This release changes aviation questions from built-in-data-first to local-evidence-first.

For a named airport, the query path resolves the airport from the user's Spatial Catalog, then fuses:
- locally indexed airport/runway/feature/aircraft layers;
- aircraft records linked by airport name, ICAO/IATA/ident or nearby coordinates;
- geotagged local images around the airport;
- cataloged raster/satellite files whose WGS84 footprint covers the airport.

The API returns a GeoJSON map containing the local airport, locally defined aircraft/features, image points and raster footprints. The UI renders this map automatically when `requires_map=true`.

Important: a raster covering an airport is evidence that the image covers that location, not evidence that an aircraft was automatically detected. Automatic aircraft counting/classification requires a benign/civil-aviation visual detector or an imported local detection layer. Detection results can be indexed as `aircraft` spatial features and will then appear in the same query/map path.

Spatial ingestion now defaults to `auto`. Common aircraft labels in `type/category/class/object_type/feature_type` are classified as `aircraft`. Existing explicit `airport`, `runway`, `aircraft`, or `feature` kinds remain supported.

No runtime reinstall is required when upgrading from the validated V6.1.2/V6.1.3 runtime.
