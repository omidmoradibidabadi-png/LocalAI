# LocalGeoAI V6.1 UNIVERSAL DATA ENGINE

V6.1 replaces per-extension upload logic with a type-aware Omni ingestion path. A file can be cataloged even when a specialist parser is unavailable; failures in Elasticsearch, embedding/Qdrant, OCR, or an optional parser are reported independently as READY/PARTIAL/ERROR.

## Main families
Documents/Office, EML/MSG, CSV/JSON/JSONL/Excel/ODS/Parquet/Arrow, images/EXIF/OCR, GIS vectors, GDAL rasters/satellite/scientific rasters, and recursive ZIP/7Z/TAR containers. Audio/video/database extensions are recognized and cataloged; full decoding/connectors remain optional.

## Important limits
No software can guarantee every proprietary format. ECW, MrSID, HEIC/AVIF/RAW, FileGDB and some HDF/NetCDF variants depend on the codecs/drivers actually present in the Windows runtime. PST/OST are recognized but not parsed in-process in this build. Unsupported formats never intentionally crash the whole application.

## First setup
Copy the existing runtime/model folders from V6.0.2, including Elasticsearch, then run `00_INSTALL_UNIVERSAL_DEPS.bat` once while internet is available. Afterwards run `08_TEST_V6_1.bat`, then `03_START_LOCALGEOAI.bat`.
