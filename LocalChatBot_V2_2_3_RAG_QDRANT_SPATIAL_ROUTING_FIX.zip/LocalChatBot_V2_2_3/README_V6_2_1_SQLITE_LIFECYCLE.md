# LocalGeoAI V6.2.1 — Windows SQLite Lifecycle Hotfix

This release fixes the Windows regression-test cleanup failure (`WinError 32`) caused by a SQLite connection created by the test itself and not explicitly closed before `TemporaryDirectory` cleanup.

Changes:
- test uses a context-managed SQLite inspection connection;
- explicit `close()` added to persistent SpatialCatalog and StructuredCatalog connections;
- web server shutdown explicitly closes Spatial/Structured/Image/Raster catalogs before stopping runtime;
- dedicated Windows SQLite lifecycle regression test added;
- no Runtime/model reinstall is required.

Run `12_TEST_V6_2_1_WINDOWS_SQLITE.bat` first. It runs both the Windows lifecycle test and the V6.2 Local Evidence regression.
