# LocalGeoAI V6.2.2

Windows launcher/import-path + SQLite lifecycle hotfix.

- Test scripts bootstrap the project root in `sys.path` themselves, so embedded Python isolation and arbitrary CMD working directories do not break `import app`.
- Batch launcher resolves all paths from `%~dp0`.
- Keeps V6.2.1 SQLite lifecycle/schema migration fixes.
- No runtime reinstall is required.

Run `13_TEST_V6_2_2_PATH_SQLITE.bat`.
