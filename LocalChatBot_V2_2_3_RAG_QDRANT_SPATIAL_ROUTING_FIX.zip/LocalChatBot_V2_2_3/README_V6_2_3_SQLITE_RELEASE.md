# LocalGeoAI V6.2.3 — Windows SQLite File-Release Hotfix

This release fixes the remaining regression-test lock on `raster_catalog.sqlite`.

Root cause: Python's `sqlite3.Connection` context manager commits/rolls back transactions but does **not** close the connection. The previous Windows test used `with sqlite3.connect(...) as c:` and therefore kept the DB handle alive until object destruction, causing WinError 32 during `TemporaryDirectory` cleanup.

V6.2.3 explicitly closes the validation connection and performs a strong file-release probe by renaming/restoring the SQLite DB before temporary-directory cleanup. Project-root bootstrap and V6.2 Local Evidence changes are retained.

Run `14_TEST_V6_2_3_SQLITE_RELEASE.bat`. Runtime/models do not need reinstalling.
