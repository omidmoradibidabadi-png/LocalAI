# LocalGeoAI V6.2.4

This hotfix audits SQLite lifecycle in the regression suite and production CanonicalStore.

Changes:
- Removed leaking sqlite3 context-manager patterns from legacy regression tests.
- CanonicalStore now opens/closes every SQLite connection explicitly.
- Added one audited master regression test.
- Master test verifies Windows-style file release by renaming/restoring raster, image and canonical SQLite databases before TemporaryDirectory cleanup.
- Keeps local-evidence airport/map regression.
- No runtime reinstall is required.

Run: `15_TEST_V6_2_4_MASTER.bat`
