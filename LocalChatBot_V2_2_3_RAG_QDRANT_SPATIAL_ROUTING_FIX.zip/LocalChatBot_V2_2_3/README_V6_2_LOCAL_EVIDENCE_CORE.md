# LocalGeoAI V6.2.0 — Local Evidence Core

V6.2 makes user-owned local data authoritative for document, structured, spatial and raster answers.

Key fixes:
- No built-in airport seed is auto-loaded.
- Airport/place coordinates are returned only after a match in the user's Spatial Catalog.
- Gemma may propose spelling/transliteration aliases, but never supplies coordinates/factual map values.
- Fixes old raster catalog schema (`no such column: driver`) with automatic SQLite migration.
- Generic local map questions such as "X کجاست؟", "مختصات X" and "X را روی نقشه نشان بده" resolve against local spatial layers.
- Document answers use Qdrant + Elasticsearch local evidence. Elasticsearch remains usable when a document embedding failed.
- If Gemma fails after retrieval, retrieved local evidence is still shown instead of a blank answer.
- Satellite change engine automatically aligns overlapping rasters, optionally normalizes radiometry, writes a change-mask GeoTIFF, writes polygon GeoJSON and returns WGS84 polygons to the map.
- Existing V6.1.2 portable runtime is reused; do not reinstall it.

Safety/accuracy rule: a raster footprint is not treated as an aircraft detection. Aircraft shown on the map must come from a user-provided spatial layer/detection/annotation.
