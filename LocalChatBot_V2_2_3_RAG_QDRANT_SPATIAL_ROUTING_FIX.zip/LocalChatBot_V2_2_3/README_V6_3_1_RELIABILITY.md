# LocalGeoAI V6.3.1 — Retrieval & Answer Reliability

- Dedicated SQLite Email Catalog independent of Elasticsearch/Qdrant.
- Email ingestion writes headers/body/attachments to Email Catalog.
- Rebuild Email Catalog button scans existing EML/MSG in data/inbox.
- Strict email-only route for email collection questions.
- Selected EML/MSG becomes chat scope, so follow-up topic questions remain email-only.
- Selected document path becomes an exact Elasticsearch scope for document Q&A.
- Gemma answer generation retries with progressively smaller context/output budgets.
- Evidence is reranked/deduplicated/compacted before generation.
- If Gemma still fails, deterministic evidence synthesis produces a readable cited answer instead of dumping raw chunks.
- Source types remain explicit (`email-local`, `document-local`, etc.).

Reuse the existing `runtime` and `models`; do not reinstall dependencies. Run `17_TEST_V6_3_1_RELIABILITY.bat`.
