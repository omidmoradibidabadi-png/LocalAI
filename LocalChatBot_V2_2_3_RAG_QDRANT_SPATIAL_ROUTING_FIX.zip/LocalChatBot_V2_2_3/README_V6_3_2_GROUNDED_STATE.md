LocalGeoAI V6.3.2 — Grounded Generation + Scope State

Fixes:
- collection email questions ignore selected-file scope
- selected EML/MSG is reconciled into Email Catalog on demand
- Email Catalog rebuild scans inbox/documents/extracted archives
- PPTX/PDF structural sections are indexed independently in Elasticsearch
- selected-file evidence exposes Slide/Page labels
- Gemma generation has compact retries and diagnostics
- evidence fallback is question-aware and clause-based
- UI clears stale source/map state at the start of every question

No runtime reinstall is required when upgrading from a healthy V6.1.2+ portable runtime.
Re-index an existing PPTX once to obtain slide-aware Elasticsearch records.
