# LocalGeoAI V6.3.3 — LLM Generation Diagnostic & Repair

This release targets the verified failure mode where retrieval succeeds but Gemma returns no final answer.

## Changes
- Direct generation self-test independent of Qdrant/Elasticsearch.
- Durable JSONL diagnostics for every generation attempt.
- Captures latency, prompt size, output size, finish reason, usage, HTTP errors and llama.cpp error body.
- Three controlled retries with progressively smaller context.
- Retry compaction preserves both prompt head and evidence tail rather than blindly truncating the tail.
- Grounded document generation uses the same diagnostic client as the standalone test.

## First test
Do not reinstall dependencies. Copy the already-working `runtime` and `models` folders, start LocalGeoAI normally, then run:

`19_TEST_V6_3_3_LLM_GENERATION.bat`

If it fails, send `logs/llm_generation_diagnostics.jsonl` plus `logs/generation.err.log`. This isolates the generation problem before RAG is involved.
