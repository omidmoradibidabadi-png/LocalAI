# LocalGeoAI V6.3.4 — Reasoning-Aware Generation Repair

V6.3.3 proved the server generated 180–220 completion tokens while `message.content` stayed empty and `finish_reason=length`.

V6.3.4 explicitly disables reasoning for user-facing answers at both llama-server startup and request level. It also records message shape (keys/lengths/presence of reasoning fields) without storing reasoning text. Blind retries are reduced to two compatibility-aware attempts.

Copy the already-working `runtime` and `models` folders from V6.3.3. Do not reinstall dependencies. Stop old llama-server processes before starting V6.3.4 so the new startup flags take effect. Then run `20_TEST_V6_3_4_REASONING_AWARE.bat`.
