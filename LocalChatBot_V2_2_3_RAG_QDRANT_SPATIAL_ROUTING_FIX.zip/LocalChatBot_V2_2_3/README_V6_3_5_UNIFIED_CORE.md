# LocalGeoAI V6.3.5 — Unified Data & Intelligence Core

This release keeps the V6.3.4 reasoning-aware Gemma generation path and repairs the data/evidence layer around it.

## Main changes
- One native Windows file/folder entry point for documents, email, structured, GIS, image and raster data.
- Removed browser duplicate pickers, separate GIS ingestion pickers, and the user-facing email-catalog rebuild button.
- Native picker is owned by a temporary foreground/topmost Windows form so it opens in front of the browser.
- Universal folder ingestion uses OmniIndex and isolates per-file errors.
- EML/MSG are ingested by the same universal folder/file workflow; collection email questions are email-only.
- Strict selected-file scope: if the selected file has no evidence, global evidence is not substituted.
- Canonical source cards can receive an opaque source_id and open the original local file from the UI.
- Data-driven spatial planner: no country-name -> ISO hard-coded table. Gemma may select only fields/values that exist in the local spatial catalog; execution is deterministic and validated.
- Adaptive CUDA profile using nvidia-smi. Small VRAM prioritizes Gemma and can keep embeddings on CPU; large VRAM increases offload. Snapshot: logs/hardware_profile.json.
- UI shows detected GPU/VRAM and planned LLM/embedding GPU layers.

## Test order
1. Copy the working `runtime` and `models` from V6.3.4.
2. Ensure older llama-server processes are stopped, then run `03_START_LOCALGEOAI.bat`.
3. Run `21_TEST_V6_3_5_UNIFIED_CORE.bat`.
4. UI: select a mixed folder containing EML + PDF/DOCX + CSV/GIS and click `افزودن و ایندکس`.
5. Ask `خلاصه‌ای از محتوای ایمیل‌ها ارائه بده` and verify only original EML/MSG sources appear.
6. Select one document and ask a question; verify no other file appears in Sources.
7. Index the airport spatial file and ask `فرودگاه‌های ایران` (or another country present in the data). The planner must use a real local field/value; no country table is hard-coded.
8. Click `باز کردن منبع اصلی` on a source card.
