# LocalGeoAI V6.3.6 — Grounded Multi-Source & Spatial

This release preserves the V6.3.4+ reasoning-aware Gemma generation path and focuses on evidence scope and UI reliability.

## Core changes
- SINGLE_FILE / FOLDER_CORPUS / GLOBAL_CORPUS are explicit query scopes.
- Folder comprehensive questions collect evidence across original files instead of allowing one CSV/XLSX to dominate.
- Type-aware folder filtering (email, presentation, document, structured) is applied when the question names a corpus type.
- Folder scope never silently falls through to global evidence.
- Spatial planner is data-driven from the indexed local schema/value inventory; spatial answers are returned only after deterministic local execution.
- Spatial filter results carry execution_status + result_set_id, and map/text/results are built from the same result set.
- Source provenance uses original paths and source cards can open original local files.
- Inline [n] citations are clickable and focus the corresponding source card.
- UI sidebar removed. Right tabs are RTL: بانک داده | نقشه | منابع.
- Dedicated spatial file/folder pickers restored.
- Existing Windows foreground native picker and adaptive CUDA profile are retained.

## Runtime
Do not reinstall dependencies if the V6.3.5 runtime is healthy. Copy `runtime` and `models` from the working installation.
