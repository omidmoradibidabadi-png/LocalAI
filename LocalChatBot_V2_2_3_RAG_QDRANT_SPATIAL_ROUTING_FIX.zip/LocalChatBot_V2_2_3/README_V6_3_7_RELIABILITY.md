# LocalGeoAI V6.3.7 — Reliable Corpus + Spatial Routing

This release repairs three runtime issues observed on V6.3.6:

- EmbeddingGemma requests now use the scalar OpenAI `input` form verified directly against llama-server, with compatibility fallbacks.
- Folder collection summaries recognize email/document summary intent and enumerate scoped sources rather than requiring lexical similarity to the phrase “summarize”.
- Spatial planning executes before document-folder fallback, so an old folder scope cannot steal queries such as “فرودگاه های ایران” after a spatial dataset has been loaded.

Existing V6.3.6 grounded scope, provenance, UI tabs, clickable-source plumbing, and spatial result-set behavior are retained.
