# LocalGeoAI V6.3.8 — Evidence/Citation/Spatial Repair

Focus: adaptive EmbeddingGemma requests with reproducible failure diagnostics; truthful FULL/PARTIAL/FAILED vector status; universal inline citation integrity; source panel bound to the same evidence namespace; full local spatial categorical inventory; stale map/result invalidation; intent-first spatial routing retained from V6.3.7.

Run `24_TEST_V6_3_8_REPAIR.bat` before live testing.
