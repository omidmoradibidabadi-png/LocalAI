# LocalGeoAI V6.3.9 — Scope + Model + Raster Core

- Folder corpus retrieval now builds an exact filesystem manifest and queries Elasticsearch by exact descendant file paths, with a scope-validated Qdrant semantic fallback.
- File-type hints fail closed: an email question cannot silently fall back to CSV/PPTX evidence when no email exists in the selected corpus.
- Retrieval diagnostics report manifest/eligible/candidate/evidence counts.
- Spatial planner is two-stage and data-driven: it chooses only real local fields, then maps the user's natural-language value to an exact value that actually exists in that field. No country answer table is embedded in the planner.
- LLM GGUF files in `models/llm` are auto-discovered and selectable in Bank Data. Switching restarts only the generation server. Embedding remains fixed by `config.json` and has no UI selector.
- T1/T2 “from bank” now recovers from an empty Raster Catalog by opening a folder picker, recursively cataloging supported rasters, then offering the catalog for selection.
- Existing evidence/citation namespace is retained: inline `[n]`, source panel `[n]`, and open-original-source all use the same source objects. Email summarization now explicitly requests and validates inline source numbers.

## Test
Run `25_TEST_V6_3_9_SCOPE_MODEL_RASTER.bat`, then start normally with `03_START_LOCALGEOAI.bat`.

For LLM switching, place one or more `.gguf` files in `models/llm`. If port 8081 is occupied by an older external llama-server, stop that old process once and restart LocalGeoAI; the application will then own safe model switching.
