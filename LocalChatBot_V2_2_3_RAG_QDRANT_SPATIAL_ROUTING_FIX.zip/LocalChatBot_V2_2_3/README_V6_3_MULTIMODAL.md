# LocalGeoAI V6.3.0 — Multimodal Local Intelligence

This release makes local evidence the default for email collection analysis, coordinate-bearing CSV spatial facts, raster questions, change detection, and user-defined visual classes.

## Main additions
- Email Collection Intelligence: scoped only to indexed EML/MSG documents, hierarchical summaries, local source list.
- Coordinate CSV dual indexing: structured + spatial `auto`, so airport/location CSVs become map evidence without a second manual import.
- Raster T1/T2 Windows picker buttons and selection from the existing Raster Catalog.
- Raster-aware chat: finds local rasters covering a resolved local place and returns their footprints as map evidence.
- Visual Model Lab UI: create civilian/benign classes, add positive/negative references, train a local prototype model, scan local rasters and map candidate detections.
- Strict evidence rule: raster coverage is not object detection; visual candidates are explicitly marked for human validation.
- Existing V6.2 change engine retained: alignment/reprojection, normalization, change mask and polygon output.

## Runtime
Reuse the validated V6.1.2+ runtime and existing models. Do not rerun the universal dependency installer unless the runtime was removed.

## Test
Run `16_TEST_V6_3_MULTIMODAL.bat`.
