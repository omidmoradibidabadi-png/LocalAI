# LocalGeoAI V6.4.0

- Document-level citation deduplication: pages/chunks of one file share one citation.
- No-evidence answers do not receive synthetic citations.
- Persian country aliases for grounded spatial filtering (Qatar/Egypt/Turkey etc.).
- Semantic airport vs heliport filtering.
- Independent Satellite/Vision model selector from `models/satellite`. Embedding remains fixed.
- Raster T1/T2 bank workflow retained and bank auto-populates from a chosen folder when empty.
- Change results record the selected satellite model identity.
- Existing V6.3.9 scope isolation and full vector indexing preserved.
