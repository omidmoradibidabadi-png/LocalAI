# LocalGeoAI V6.4.10

Focused regression fix after V6.4.9.

- Selected-file evidence no longer depends on lexical Elasticsearch matching. Exact canonical path is used first.
- Added exact Qdrant source_path retrieval for selected images/documents.
- Added Elasticsearch exact-path listing.
- Query planner retries /v1/chat/completions without optional reasoning parameters for llama.cpp compatibility, preventing a planner-side 502/Bad Gateway caused by unsupported request fields.
- OCR engine, Local-only policy and GIS routing are otherwise unchanged.
