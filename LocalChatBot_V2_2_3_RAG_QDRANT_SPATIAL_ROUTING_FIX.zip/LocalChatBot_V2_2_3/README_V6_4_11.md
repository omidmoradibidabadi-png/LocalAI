# LocalGeoAI V6.4.11 — Batch Image Folder Fix

Focused regression-safe update for image folders.

- Keeps the V6.4.10 single-image OCR/index/retrieval path unchanged.
- Folder ingestion reports image/OCR/RAG/ES totals.
- Folder retrieval enumerates exact Qdrant source paths for every indexed file instead of depending on one nearest semantic hit.
- Multi-image evidence remains constrained to the selected folder and Local-only policy.
- Existing OCR engine is unchanged.
