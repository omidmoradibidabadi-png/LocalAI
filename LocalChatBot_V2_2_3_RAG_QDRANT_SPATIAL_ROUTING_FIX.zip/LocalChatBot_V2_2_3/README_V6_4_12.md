# LocalGeoAI V6.4.12

Folder image batch recovery fix.

- Single-file image ingest path is unchanged.
- After folder OCR completes, images with successful OCR but zero RAG chunks are retried sequentially up to 3 times.
- Elasticsearch image indexing is retried independently.
- Exact source_path is preserved for multi-image folder retrieval and citations.
- Existing OCR engine, spatial engine, local-only policy and single-file retrieval logic are unchanged.
