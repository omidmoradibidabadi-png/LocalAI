# LocalGeoAI V6.4.13 — Folder Multi-Source Rerank

Focused regression-safe update from V6.4.12.

- Folder corpus candidates are collapsed to one evidence record per source image/document before relevance evaluation.
- Folder relevance now evaluates up to 64 distinct local sources and returns an ordered multi-source ranking.
- Exact entity/result matches are explicitly preferred over merely topical OCR text.
- Folder answer context preserves the LLM relevance order instead of re-sorting by raw vector score.
- Up to 12 directly relevant local sources can participate in one grounded answer and citations.
- Single-file OCR/index/retrieval path is unchanged.
- Local-only/fail-closed behavior is retained.
