# LocalGeoAI V6.4.14 — Hybrid Folder Retrieval

Focus: fix folder candidate generation without changing the verified single-image OCR path.

- Source-complete Qdrant exact-path recall for every indexed file in selected folder.
- Additive scoped semantic retrieval.
- Elasticsearch lexical/entity candidate branch.
- Stable candidate union before LLM reranking; no Top-1 collapse.
- Folder retrieval diagnostics report missing Qdrant source filenames.
- Fixed folder ES retry bug that could reuse OCR sections from a previous image.
- Single-file OCR engine and selected-file flow are unchanged.
