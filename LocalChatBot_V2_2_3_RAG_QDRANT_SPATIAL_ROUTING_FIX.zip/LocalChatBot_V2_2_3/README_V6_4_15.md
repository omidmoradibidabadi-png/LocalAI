# LocalGeoAI V6.4.15 — Retrieval Trace

Diagnostic release for folder-corpus retrieval.

Adds a Retrieval Trace panel showing manifest/index coverage, Qdrant exact-path recall, semantic hits, Elasticsearch candidates, candidate union, LLM reranker input/output, missing Qdrant files, and final evidence.

No OCR engine changes. Single-file OCR/retrieval path is unchanged.
