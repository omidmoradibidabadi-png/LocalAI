# LocalGeoAI V6.4.16 — Reranker Reliability Fix

- Fixes the folder reranker failure exposed by V6.4.15 Retrieval Trace.
- Reranker now receives source name, engine, score and actual document-level evidence text.
- Structured per-source relevance/direct-support judgements are requested from the local LLM.
- Folder reranking is recall-safe: a pathological top-1 result cannot erase all other locally retrieved candidates.
- Retrieval Trace is retained and now includes raw reranker output, judgements, direct-support IDs and safety-added IDs.
- Retrieval, OCR and single-file OCR pipeline were not changed.
- Local-only grounding remains enforced.
