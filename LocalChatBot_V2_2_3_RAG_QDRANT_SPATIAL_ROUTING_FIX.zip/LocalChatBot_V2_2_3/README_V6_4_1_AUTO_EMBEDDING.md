# LocalGeoAI V6.4.1 — Auto Embedding Model Hotfix

- Embedding filename is no longer hard-coded.
- Put exactly one compatible GGUF embedding model in `models/embedding/`.
- Preflight, runtime startup, runtime test, API status and runtime builder all resolve that file automatically.
- Zero models => clear failure. More than one => clear failure; no arbitrary selection.
- LLM model selection remains independent.
