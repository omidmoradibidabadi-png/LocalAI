# LocalGeoAI V6.4.2

Fixes embedding-model discovery when launched from any Windows working directory. Preflight now scans `models/embedding/*.gguf` directly without importing the `app` package. The web server also inserts the project root into `sys.path` before importing project modules. Keep exactly one embedding GGUF in `models/embedding`.
