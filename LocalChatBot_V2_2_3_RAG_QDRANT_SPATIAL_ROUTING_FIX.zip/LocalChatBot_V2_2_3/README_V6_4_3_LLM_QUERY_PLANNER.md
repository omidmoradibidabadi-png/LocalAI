# LocalGeoAI V6.4.3 — LLM Query Planner

## Architectural change
The active local LLM is now the authoritative query-understanding and domain-planning layer for every `/api/ask` request. Keyword lists are no longer used to decide whether a question is document, spatial, raster, email, structured, mixed, or general.

## Spatial behavior
Spatial execution remains grounded in the real local Spatial Catalog. The LLM may interpret any country/place/language, but the execution value must resolve to an actual field/value in the user's indexed data. The previous Persian country alias table was removed.

Examples that must generalize without code changes:
- `تهدیدات فضایی چیست؟` -> knowledge, not GIS
- `فرودگاه‌های قرقیزستان را روی نقشه نشان بده` -> spatial
- `airports in Kazakhstan` -> spatial
- `در اسناد درباره فرودگاه‌های قطر چه اطلاعاتی داریم؟` -> knowledge

## Important separation
The LLM decides *what operation is intended*. Engines execute against local evidence. The LLM is not allowed to invent local records or coordinates.
