# LocalGeoAI V6.4.4 — Local Only / Verified Hot-Swap / Adaptive CUDA

- Final answers are local-data-only. `general` planning never authorizes parametric model knowledge.
- LLM semantic relevance gate rejects unrelated retrieved documents and fails closed.
- LLM GGUF switching restarts only generation server, verifies `/v1/models`, then persists config.
- Model list marks `active` from the actually served model, not merely the combobox/config value.
- Adaptive CUDA policy uses model size + live VRAM budget; embedding remains CPU on small/medium GPUs to reserve VRAM for LLM.
- Existing spatial execution/map path is preserved.

Run `27_TEST_V6_4_4.bat` before Windows runtime validation.
