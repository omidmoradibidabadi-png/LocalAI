# LocalGeoAI V6.4.5

Hotfixes:
- fixes LLM hot-swap NameError (`write_snapshot`)
- GPU-priority generation profile
- caps llama.cpp CPU worker threads to reduce 100% CPU saturation
- smaller batch/ubatch for 4 GB VRAM development GPU
- embedding remains CPU-side to preserve generation VRAM

Note: a 12B Q4 model is larger than GTX 1650 4GB VRAM, so full GPU residency is physically impossible; partial offload is expected.
