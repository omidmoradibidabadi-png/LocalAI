# LocalGeoAI V6.4.6 — OCR + Verified LLM Runtime

This build is based directly on V6.4.5 and deliberately leaves the working local-evidence, LLM query-planner, hybrid retrieval, citation, email and spatial answer paths unchanged.

## Added
- Index-time OCR mode: Off / Auto / Force.
- Local OCR bridge for images and scanned PDF pages using Tesseract + pytesseract.
- Persian/English language detection from the local Tesseract runtime.
- OCR text is indexed into Elasticsearch and Qdrant with original file/page provenance.
- LLM UI no longer displays the fixed Embedding line.
- LLM state is VERIFIED only when `/v1/models` reports the selected GGUF; UI also shows managed PID, CUDA detection and requested GPU layers.

## Local OCR runtime
Place `tesseract.exe` under `runtime\ocr\` and traineddata under `runtime\ocr\tessdata\` (at least `fas.traineddata` and `eng.traineddata`). The code also accepts a locally installed Tesseract found on PATH. No cloud OCR is used.

## Regression principle
The existing UnifiedEngine, LLM Query Planner, local-only answer policy, retrieval ranking and SpatialCatalog logic were not rewritten in this release.
