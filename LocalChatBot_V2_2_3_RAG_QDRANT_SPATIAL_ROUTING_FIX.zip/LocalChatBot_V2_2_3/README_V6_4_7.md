# LocalGeoAI V6.4.7 — Multilingual OCR pipeline fix

This build preserves the V6.4.6 local-evidence/RAG/query-planner/spatial behavior and changes the OCR path only.

## OCR behavior
- UI remains: Off / Auto / Force. There is no language selector.
- Backend automatically uses all installed project OCR languages: Persian (fas), English (eng), Arabic (ara), Hebrew (heb), Simplified Chinese (chi_sim), Traditional Chinese (chi_tra).
- The six traineddata files plus osd are included in runtime/ocr/tessdata.
- OCR is centralized; ImageCatalog no longer runs a second default-language pytesseract pass.
- Image indexing reports OCR success/failure and extracted character count.
- OCR failures remain `partial`; local-only answering remains unchanged, so the LLM cannot invent an answer when OCR evidence is absent.

## Windows OCR engine
The language models are bundled. A Windows `tesseract.exe` and its DLLs must exist under `runtime/ocr/` for OCR execution. V6.4.7 detects this explicitly and reports a clear error instead of silently indexing an image without OCR text.
