# LocalGeoAI V6.4.8

Focused hotfix. Existing RAG/local-only/query-planner/spatial behavior is intentionally preserved.

## Fixes
- Safe adoption/replacement of an existing llama-server on the generation port during LLM hot-swap.
- PID is resolved from the generation port and command line is verified as llama-server before termination. No kill-by-name is used, so the embedding llama-server is not intentionally touched.
- OCR language UI remains absent. OCR uses installed project languages automatically.
- OCR runtime bootstrap for the development machine: `31_SETUP_OCR_RUNTIME_ONCE.bat` installs a private Windows Tesseract runtime under `runtime\ocr`. Final offline deployments should ship that populated folder, so no network is required on the target laptop.
- OCR models bundled: fas, eng, ara, heb, chi_sim, chi_tra, osd.

## Important
The current build environment cannot execute Windows binaries, so Windows process adoption and Tesseract execution must be runtime-tested on the user's Windows machine. Python compile/static checks are performed before packaging.
