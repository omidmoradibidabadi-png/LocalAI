# LocalGeoAI V6.4.9 — Adaptive OCR + Generation Diagnostics

Focused hotfix over V6.4.8.

- OCR no longer loads all six language models for every image.
- Backend performs script detection and automatically chooses a compact language group; UI still has only Off / Auto / Force.
- Large images are downscaled for OCR only (original file is untouched).
- OCR execution timeout is 180 seconds and diagnostics include script, languages, elapsed time, and character count.
- OCR status is cached so `--list-langs` is not repeatedly executed during one ingest.
- On Windows, if `runtime/ocr/tesseract.exe` is absent, the backend can import an installed Tesseract from `%LOCALAPPDATA%\Tesseract-OCR`, Program Files, or PATH into the project runtime automatically. Existing project tessdata is preserved.
- Added `33_TEST_V6_4_9.bat` with correct project working directory/PYTHONPATH plus generation health/model checks.
- App/config version synchronized to 6.4.9.

No changes were made to the Local-only answer policy, spatial query core, hybrid router, or local map QA.
