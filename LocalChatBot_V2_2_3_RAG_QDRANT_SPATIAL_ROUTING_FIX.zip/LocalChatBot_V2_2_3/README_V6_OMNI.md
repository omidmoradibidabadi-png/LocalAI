# LocalGeoAI V6.0 OMNI

V6 integrates the enterprise search path into the live API and adds extensible email, image, OCR, raster, change-detection and civilian visual-model workspaces.

## Implemented core
- Live Elasticsearch health and exact/email retrieval path.
- General-chat fallback independent of RAG, fixing ordinary-question 404/failure behavior.
- EML MIME parsing with HTML fallback, threading headers and attachment extraction.
- MSG parsing through optional `extract-msg`; capability status reports whether it is actually installed.
- Universal Omni ingestion with canonical SHA identity and recursive attachment ingestion.
- EXIF/GPS image catalog + optional OCR and GeoJSON map output.
- Raster metadata catalog and aligned pixel change-detection engine (rasterio/numpy optional).
- Visual Model Lab registry/reference-set workflow for civilian aviation and benign remote-sensing.
- V6 UI shows live Elasticsearch/OCR/Raster status.

## Important
Few-shot reference collection and Model Registry are implemented as an extensible workspace. Actual detector training/inference requires a separately installed vision backend/model and sufficient labelled data. The program does not pretend that ten images alone produce a validated detector. Raster pixel change detection requires co-registered images.

PST remains recognized as a future connector rather than falsely advertised as parse-ready.
