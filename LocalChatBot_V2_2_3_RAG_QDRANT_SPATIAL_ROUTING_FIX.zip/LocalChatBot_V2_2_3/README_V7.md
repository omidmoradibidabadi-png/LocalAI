# LocalGeoAI V7.0 — Persistent Intelligence Core

V7 separates application code/runtime from durable intelligence data.

Default durable store: `../LocalGeoAI_PersistentData` (sibling of the V7 application folder).
It contains Qdrant, canonical manifest/extracted text, structured/spatial/image/raster/email catalogs and, when a portable Elasticsearch runtime is present, its `path.data`.

## Upgrade behavior
- Application folders may be replaced/upgraded without deleting the durable store.
- Canonical SHA-256 manifest skips unchanged files (`status=unchanged`) instead of repeating OCR/embedding.
- Changed/new files are processed incrementally.
- Embedding-model/schema breaking changes should use a future explicit migration/reindex operation rather than silently rebuilding everything.

## First V7 run
Run `00_SETUP_V7_PERSISTENCE.bat` once (the normal launcher also runs the setup safely).

## Reuse V6.4.16 data
Drag the old V6.4.16 application folder onto `01_MIGRATE_V6_DATA_TO_V7.bat` once. It copies existing durable data without overwriting files already present in the V7 store.

V6.4.16 retrieval/reranker/OCR behavior is retained as the V7 baseline; V7's architectural change is persistence and incremental indexing.
