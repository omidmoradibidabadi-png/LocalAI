# LocalGeoAI V7.0.1 — Startup / Import Hotfix

Fixes `ModuleNotFoundError: No module named app` when `web_server.py` is launched directly by the portable Python runtime.

- Project root is inserted into `sys.path` before the first `app.*` import.
- Startup BAT files also export project root through `PYTHONPATH` as a second safeguard.
- Preflight banner updated to V7.0.1.
- Persistent data architecture is unchanged.
- OCR, retrieval, reranker, Qdrant data and Elasticsearch data are unchanged.
