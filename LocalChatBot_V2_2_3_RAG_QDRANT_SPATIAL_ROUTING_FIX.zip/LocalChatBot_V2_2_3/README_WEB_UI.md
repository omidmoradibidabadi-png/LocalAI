# LocalGeoAI V3 — Persistent Backend + Persian Web UI

این مرحله مدل‌ها را برای هر سؤال دوباره Load نمی‌کند. `05_START_WEB_UI.bat` سرویس‌های Qdrant، Gemma و EmbeddingGemma را یک‌بار بالا می‌آورد و Backend تا زمان بسته‌شدن برنامه فعال می‌ماند.

## اجرا
اگر Runtime و dependencyها را در همین پوشه آماده کرده‌اید:
`05_START_WEB_UI.bat`

مرورگر به‌طور خودکار روی `http://127.0.0.1:8080` باز می‌شود.

## قابلیت‌های این نسخه
- رابط فارسی RTL
- Chat واقعی متصل به RAG
- افزودن سند با مسیر فایل
- نمایش منبع، صفحه و score
- تشخیص intent: document / spatial / mixed
- پنل نقشه از همین نسخه در UI وجود دارد
- API contract برای Spatial/GeoJSON آماده است
- سرویس‌های AI persistent هستند

## نکته مهم GIS
در این نسخه، پنل نقشه و routing سؤال‌های مکان‌محور در محصول واقعی وجود دارند، اما هنوز نتیجه مکانی ساختگی تولید نمی‌شود. مرحله بعد Providerهای داده محلی (GeoJSON/Shapefile/GeoPackage)، GeoPandas/PostGIS و OSM را به SpatialEngine وصل می‌کند.

اصل تحلیلی حفظ می‌شود: «در محدوده بودن» به‌تنهایی اثبات «مبدأ واقعی» نیست.
