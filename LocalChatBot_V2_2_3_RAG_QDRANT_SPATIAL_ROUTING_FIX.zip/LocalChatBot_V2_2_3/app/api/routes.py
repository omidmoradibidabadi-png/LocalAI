from pathlib import Path
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

class AskRequest(BaseModel): question: str; limit: int=8
class IngestRequest(BaseModel): path: str

def build_router(kernel):
    r=APIRouter()
    @r.get("/health")
    async def health(): return {"status":"ok","version":kernel.settings.version}
    @r.post("/ingest")
    async def ingest(req: IngestRequest):
        p=Path(req.path)
        if not p.exists() or not p.is_file(): raise HTTPException(404,"File not found")
        try: return await kernel.ingestion.ingest(p)
        except Exception as e: raise HTTPException(400,str(e))
    @r.post("/ask")
    async def ask(req: AskRequest):
        a=await kernel.rag.ask(req.question,req.limit)
        return {"answer":a.text,"sources":[{"source":h.source,"page":h.page,"score":h.score,"text":h.text[:500]} for h in a.sources]}
    return r
