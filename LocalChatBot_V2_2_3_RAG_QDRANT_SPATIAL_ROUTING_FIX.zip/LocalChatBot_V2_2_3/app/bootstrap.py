import logging
from app.kernel import ApplicationKernel

class ApplicationBootstrapper:
    def __init__(self, settings):
        self.settings=settings; self.kernel=None; self.logger=logging.getLogger("localgeoai.bootstrap")
    async def initialize(self):
        self.kernel=await ApplicationKernel.build(self.settings)
        await self.kernel.health_check(); await self.kernel.start()
    async def run(self): await self.kernel.serve()
    async def shutdown(self):
        if self.kernel: await self.kernel.stop()
