from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
import json, os

BASE_DIR = Path(__file__).resolve().parents[2]

def _path(value: str | Path) -> Path:
    p = Path(value)
    return p if p.is_absolute() else (BASE_DIR / p).resolve()

@dataclass(frozen=True)
class Settings:
    app_name: str = "LocalGeoAI"
    version: str = "3.0.0-dev"
    host: str = "127.0.0.1"
    port: int = 8080
    log_level: str = "INFO"
    data_dir: Path = BASE_DIR / "data"
    models_dir: Path = BASE_DIR / "models"
    llm: dict[str, Any] = field(default_factory=lambda: {"backend":"auto","path":"models/qwen","context_length":8192,"gpu_layers":-1})
    embedding: dict[str, Any] = field(default_factory=lambda: {"backend":"sentence_transformers","path":"models/embedding","device":"cuda","batch_size":32})
    qdrant: dict[str, Any] = field(default_factory=lambda: {"mode":"server","url":"http://127.0.0.1:6333","collection":"localgeoai_chunks","executable":"runtime/qdrant/qdrant.exe"})
    features: dict[str, bool] = field(default_factory=lambda: {"document_rag":True,"ocr":False,"email_analysis":False,"spatial_analysis":False,"offline_maps":False,"knowledge_graph":False,"advanced_reporting":False})

    @classmethod
    def load(cls) -> "Settings":
        path = Path(os.getenv("LOCALGEOAI_CONFIG", BASE_DIR / "config.json"))
        raw = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
        valid = {k:v for k,v in raw.items() if k in cls.__dataclass_fields__}
        for key in ("data_dir","models_dir"):
            if key in valid: valid[key] = _path(valid[key])
        obj = cls(**valid)
        # Resolve component paths without forcing users to move already-downloaded models.
        for section in (obj.llm, obj.embedding):
            if section.get("path"): section["path"] = str(_path(section["path"]))
        if obj.qdrant.get("executable"): obj.qdrant["executable"] = str(_path(obj.qdrant["executable"]))
        return obj
