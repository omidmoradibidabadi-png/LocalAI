class FeatureManager:
    def __init__(self, flags: dict[str, bool]): self._flags = dict(flags)
    def enabled(self, name: str) -> bool: return bool(self._flags.get(name, False))
    def snapshot(self) -> dict[str, bool]: return dict(self._flags)
