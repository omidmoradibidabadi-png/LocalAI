from dataclasses import dataclass

@dataclass(frozen=True)
class HealthResult:
    name: str; ok: bool; detail: str = ""

class HealthManager:
    def __init__(self): self._checks = []
    def register(self, name, check): self._checks.append((name, check))
    async def run(self):
        out=[]
        for name, check in self._checks:
            try:
                result = await check()
                out.append(HealthResult(name, bool(result), "OK" if result else "FAILED"))
            except Exception as exc: out.append(HealthResult(name, False, str(exc)))
        return out
