import logging
from pathlib import Path

def configure_logging(settings) -> None:
    Path("logs").mkdir(exist_ok=True)
    logging.basicConfig(level=getattr(logging, settings.log_level.upper(), logging.INFO),
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        handlers=[logging.FileHandler("logs/localgeoai.log", encoding="utf-8"), logging.StreamHandler()])
