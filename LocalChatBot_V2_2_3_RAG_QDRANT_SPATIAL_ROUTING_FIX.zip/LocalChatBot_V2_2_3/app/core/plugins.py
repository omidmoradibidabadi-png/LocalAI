from importlib import import_module
from pathlib import Path
import pkgutil

class PluginManager:
    def __init__(self, package: str = "app.plugins"): self.package, self.plugins = package, {}
    def discover(self):
        pkg = import_module(self.package)
        for item in pkgutil.iter_modules(pkg.__path__):
            if item.name.startswith("_"): continue
            module = import_module(f"{self.package}.{item.name}")
            plugin = getattr(module, "PLUGIN", None)
            if plugin is not None: self.plugins[item.name] = plugin
        return dict(self.plugins)
