from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

@dataclass(slots=True)
class Chunk:
    id: str
    document_id: str
    text: str
    source: str
    page: int | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

@dataclass(slots=True)
class SearchHit:
    chunk_id: str
    text: str
    source: str
    score: float
    page: int | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

@dataclass(slots=True)
class Answer:
    text: str
    sources: list[SearchHit]
