from __future__ import annotations

import asyncio
from pathlib import Path


class GGUFEmbeddingProvider:
    """Embedding provider for embedding-capable GGUF models via llama.cpp."""

    def __init__(self, config: dict):
        self.config = config
        self._model = None
        self._dimension: int | None = None
        self._lock = asyncio.Lock()

    def _load(self):
        if self._model is not None:
            return self._model
        path = Path(self.config["path"])
        if not path.is_file() or path.suffix.lower() != ".gguf":
            raise FileNotFoundError(f"Embedding GGUF model not found: {path}")
        from llama_cpp import Llama
        self._model = Llama(
            model_path=str(path),
            embedding=True,
            n_ctx=int(self.config.get("context_length", 2048)),
            n_gpu_layers=int(self.config.get("gpu_layers", -1)),
            n_batch=int(self.config.get("batch_size", 256)),
            verbose=False,
        )
        return self._model

    @staticmethod
    def _extract_vectors(response: dict) -> list[list[float]]:
        data = response.get("data", [])
        vectors = [item["embedding"] for item in sorted(data, key=lambda x: x.get("index", 0))]
        if not vectors:
            raise RuntimeError("Embedding runtime returned no vectors")
        return vectors

    async def embed(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []
        async with self._lock:
            def work():
                model = self._load()
                response = model.create_embedding(texts, normalize=True)
                vectors = self._extract_vectors(response)
                self._dimension = len(vectors[0])
                return vectors
            return await asyncio.to_thread(work)

    async def dimension(self) -> int:
        if self._dimension is None:
            await self.embed(["dimension probe"])
        assert self._dimension is not None
        return self._dimension

    async def health_check(self) -> bool:
        return Path(self.config["path"]).is_file()
