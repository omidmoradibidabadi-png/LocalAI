from __future__ import annotations
import asyncio

class LocalEmbeddingProvider:
    def __init__(self, config: dict): self.config=config; self._model=None
    def _load(self):
        if self._model is None:
            from sentence_transformers import SentenceTransformer
            self._model=SentenceTransformer(self.config["path"], device=self.config.get("device","cuda"), trust_remote_code=True)
        return self._model
    async def embed(self, texts: list[str]) -> list[list[float]]:
        def work():
            vectors=self._load().encode(texts, batch_size=int(self.config.get("batch_size",32)), normalize_embeddings=True, show_progress_bar=False)
            return vectors.tolist()
        return await asyncio.to_thread(work)
