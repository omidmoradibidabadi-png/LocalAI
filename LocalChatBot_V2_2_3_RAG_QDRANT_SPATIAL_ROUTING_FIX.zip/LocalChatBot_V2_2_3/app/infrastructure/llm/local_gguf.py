from __future__ import annotations

import asyncio
from pathlib import Path


class LocalGGUFChatProvider:
    """Generic GGUF chat provider. Model-family-specific logic stays outside the application core."""

    def __init__(self, config: dict):
        self.config = config
        self._model = None
        self._lock = asyncio.Lock()

    def _load(self):
        if self._model is not None:
            return self._model
        path = Path(self.config["path"])
        if not path.is_file() or path.suffix.lower() != ".gguf":
            raise FileNotFoundError(f"Generation GGUF model not found: {path}")
        from llama_cpp import Llama
        self._model = Llama(
            model_path=str(path),
            n_ctx=int(self.config.get("context_length", 8192)),
            n_gpu_layers=int(self.config.get("gpu_layers", -1)),
            n_batch=int(self.config.get("batch_size", 512)),
            flash_attn=bool(self.config.get("flash_attention", True)),
            verbose=False,
        )
        return self._model

    async def generate(self, prompt: str, **kwargs) -> str:
        async with self._lock:
            def work() -> str:
                model = self._load()
                messages = [
                    {"role": "system", "content": kwargs.get("system_prompt", "Answer using the supplied evidence. Do not invent unsupported facts.")},
                    {"role": "user", "content": prompt},
                ]
                response = model.create_chat_completion(
                    messages=messages,
                    temperature=float(kwargs.get("temperature", 0.1)),
                    max_tokens=int(kwargs.get("max_tokens", 1024)),
                )
                return response["choices"][0]["message"]["content"].strip()
            return await asyncio.to_thread(work)

    async def health_check(self) -> bool:
        return Path(self.config["path"]).is_file()
