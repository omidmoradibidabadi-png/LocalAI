from __future__ import annotations
from pathlib import Path
import asyncio

class LocalQwenProvider:
    def __init__(self, config: dict): self.config=config; self._backend=None; self._model=None; self._tokenizer=None
    def _load(self):
        if self._model is not None: return
        path=Path(self.config["path"]); backend=self.config.get("backend","auto")
        gguf = path.is_file() and path.suffix.lower()==".gguf"
        if backend=="llama_cpp" or (backend=="auto" and gguf):
            from llama_cpp import Llama
            self._backend="llama_cpp"; self._model=Llama(model_path=str(path), n_ctx=int(self.config.get("context_length",8192)), n_gpu_layers=int(self.config.get("gpu_layers",-1)), verbose=False)
        else:
            from transformers import AutoModelForCausalLM, AutoTokenizer
            import torch
            self._backend="transformers"
            self._tokenizer=AutoTokenizer.from_pretrained(str(path), trust_remote_code=True)
            self._model=AutoModelForCausalLM.from_pretrained(str(path), torch_dtype="auto", device_map="auto", trust_remote_code=True).eval()
    async def generate(self, prompt: str, **kwargs) -> str:
        def work():
            self._load()
            if self._backend=="llama_cpp":
                r=self._model.create_chat_completion(messages=[{"role":"user","content":prompt}], temperature=float(kwargs.get("temperature",0.1)), max_tokens=int(kwargs.get("max_tokens",1024)))
                return r["choices"][0]["message"]["content"].strip()
            import torch
            messages=[{"role":"user","content":prompt}]
            text=self._tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
            inputs=self._tokenizer([text], return_tensors="pt").to(self._model.device)
            with torch.inference_mode():
                ids=self._model.generate(**inputs, max_new_tokens=int(kwargs.get("max_tokens",1024)), do_sample=False)
            generated=ids[0][inputs.input_ids.shape[1]:]
            return self._tokenizer.decode(generated, skip_special_tokens=True).strip()
        return await asyncio.to_thread(work)
