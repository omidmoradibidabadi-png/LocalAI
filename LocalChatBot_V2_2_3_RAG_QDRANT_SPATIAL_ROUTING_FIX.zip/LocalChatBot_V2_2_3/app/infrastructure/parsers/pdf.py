from __future__ import annotations
from pathlib import Path
import hashlib
from app.domain.models import Chunk

class PdfParser:
    extensions = {".pdf"}
    def parse(self, path: Path) -> list[Chunk]:
        try:
            import fitz
        except ImportError as exc:
            raise RuntimeError("PyMuPDF is required for PDF ingestion") from exc
        doc_id = hashlib.sha256(path.read_bytes()).hexdigest()
        out: list[Chunk] = []
        with fitz.open(path) as pdf:
            for page_no, page in enumerate(pdf, start=1):
                text = page.get_text("text").strip()
                if not text: continue
                for idx, part in enumerate(self._split(text)):
                    cid = hashlib.sha256(f"{doc_id}:{page_no}:{idx}:{part}".encode()).hexdigest()
                    out.append(Chunk(cid, doc_id, part, str(path), page_no, {"filename":path.name}))
        return out

    @staticmethod
    def _split(text: str, size: int=1400, overlap: int=180) -> list[str]:
        text = " ".join(text.split())
        if len(text) <= size: return [text]
        parts=[]; start=0
        while start < len(text):
            end=min(len(text), start+size)
            if end < len(text):
                cut=max(text.rfind(". ", start, end), text.rfind("\n", start, end))
                if cut > start + size//2: end=cut+1
            parts.append(text[start:end].strip())
            if end >= len(text): break
            start=max(start+1, end-overlap)
        return [p for p in parts if p]
