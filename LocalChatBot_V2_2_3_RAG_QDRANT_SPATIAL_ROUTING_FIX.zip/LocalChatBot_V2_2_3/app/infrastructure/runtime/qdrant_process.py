from __future__ import annotations

import asyncio
import logging
import os
import subprocess
import time
from pathlib import Path
from urllib.request import urlopen


class QdrantProcessManager:
    """Starts the bundled/local qdrant.exe only when a Qdrant server is not already reachable."""

    def __init__(self, config: dict):
        self.config = config
        self.logger = logging.getLogger("localgeoai.qdrant.process")
        self.process: subprocess.Popen | None = None
        self.started_by_us = False

    def _ready_sync(self) -> bool:
        url = self.config.get("url", "http://127.0.0.1:6333").rstrip("/") + "/readyz"
        try:
            with urlopen(url, timeout=1.5) as response:
                return 200 <= response.status < 300
        except Exception:
            return False

    async def is_ready(self) -> bool:
        return await asyncio.to_thread(self._ready_sync)

    async def start(self) -> None:
        if self.config.get("mode", "server") != "server":
            return
        if await self.is_ready():
            self.logger.info("Qdrant already running")
            return

        exe = Path(self.config["executable"])
        if not exe.exists():
            raise FileNotFoundError(f"qdrant.exe not found: {exe}")

        storage = Path(self.config.get("storage_path", "data/qdrant_storage"))
        storage.mkdir(parents=True, exist_ok=True)
        env = os.environ.copy()
        env["QDRANT__STORAGE__STORAGE_PATH"] = str(storage.resolve())
        env.setdefault("QDRANT__SERVICE__HTTP_PORT", str(self.config.get("http_port", 6333)))
        env.setdefault("QDRANT__SERVICE__GRPC_PORT", str(self.config.get("grpc_port", 6334)))

        flags = 0
        if os.name == "nt":
            flags = subprocess.CREATE_NO_WINDOW
        self.process = subprocess.Popen(
            [str(exe)], cwd=str(exe.parent), env=env,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            creationflags=flags,
        )
        self.started_by_us = True

        deadline = time.monotonic() + float(self.config.get("startup_timeout", 30))
        while time.monotonic() < deadline:
            if self.process.poll() is not None:
                raise RuntimeError(f"Qdrant exited with code {self.process.returncode}")
            if await self.is_ready():
                self.logger.info("Qdrant ready")
                return
            await asyncio.sleep(0.35)
        raise TimeoutError("Qdrant did not become ready in time")

    async def stop(self) -> None:
        if not self.started_by_us or self.process is None or self.process.poll() is not None:
            return
        self.process.terminate()
        try:
            await asyncio.wait_for(asyncio.to_thread(self.process.wait), timeout=8)
        except asyncio.TimeoutError:
            self.process.kill()
        self.logger.info("Qdrant stopped")
