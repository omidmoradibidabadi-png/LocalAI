from __future__ import annotations

import asyncio
from qdrant_client import QdrantClient, models
from app.domain.models import Chunk, SearchHit


class QdrantVectorStore:
    def __init__(self, config: dict):
        self.config = config
        self.collection = config.get("collection", "localgeoai_chunks")
        self.client = QdrantClient(url=config.get("url", "http://127.0.0.1:6333"), timeout=float(config.get("timeout", 10)))

    def _ensure_collection_sync(self, dimension: int):
        names = {c.name for c in self.client.get_collections().collections}
        if self.collection not in names:
            self.client.create_collection(
                self.collection,
                vectors_config=models.VectorParams(size=dimension, distance=models.Distance.COSINE),
            )
            return
        info = self.client.get_collection(self.collection)
        vectors = info.config.params.vectors
        existing = getattr(vectors, "size", None)
        if existing is not None and int(existing) != int(dimension):
            raise RuntimeError(
                f"Qdrant collection '{self.collection}' has vector size {existing}, "
                f"but the selected embedding model produces {dimension}. "
                "Use a new collection name or re-index the collection."
            )

    async def ensure_collection(self, dimension: int):
        await asyncio.to_thread(self._ensure_collection_sync, dimension)

    async def health_check(self) -> bool:
        try:
            await asyncio.to_thread(self.client.get_collections)
            return True
        except Exception:
            return False

    async def upsert_chunks(self, chunks: list[Chunk], vectors: list[list[float]]):
        if not chunks:
            return
        await self.ensure_collection(len(vectors[0]))
        points = []
        for c, v in zip(chunks, vectors):
            payload = {"document_id": c.document_id, "text": c.text, "source": c.source, "page": c.page, "metadata": c.metadata}
            points.append(models.PointStruct(id=c.id, vector=v, payload=payload))
        await asyncio.to_thread(self.client.upsert, self.collection, points=points, wait=True)

    async def search(self, vector: list[float], limit: int = 8) -> list[SearchHit]:
        def work():
            return self.client.query_points(collection_name=self.collection, query=vector, limit=limit, with_payload=True).points
        result = await asyncio.to_thread(work)
        return [
            SearchHit(str(x.id), x.payload.get("text", ""), x.payload.get("source", ""), float(x.score), x.payload.get("page"), x.payload.get("metadata", {}))
            for x in result
        ]
