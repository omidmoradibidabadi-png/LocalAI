from __future__ import annotations

import asyncio
import logging
from pathlib import Path

from app.core.features import FeatureManager
from app.core.health import HealthManager
from app.core.plugins import PluginManager
from app.infrastructure.embedding.gguf_embedding import GGUFEmbeddingProvider
from app.infrastructure.llm.local_gguf import LocalGGUFChatProvider
from app.infrastructure.runtime.qdrant_process import QdrantProcessManager
from app.infrastructure.vector.qdrant_store import QdrantVectorStore
from app.services.ingestion.service import IngestionService
from app.services.rag.service import RagService


class ApplicationKernel:
    def __init__(self, settings):
        self.settings = settings
        self.logger = logging.getLogger("localgeoai.kernel")
        self.features = FeatureManager(settings.features)
        self.health = HealthManager()
        self.plugins = PluginManager()
        self._stop = asyncio.Event()

    @classmethod
    async def build(cls, settings):
        self = cls(settings)
        self.plugins.discover()
        self.qdrant_process = QdrantProcessManager(settings.qdrant)
        self.llm = LocalGGUFChatProvider(settings.llm)
        self.embedding = GGUFEmbeddingProvider(settings.embedding)
        self.vector = QdrantVectorStore(settings.qdrant)
        self.ingestion = IngestionService(self.embedding, self.vector)
        self.rag = RagService(self.llm, self.embedding, self.vector)

        self.health.register("kernel", self._kernel_check)
        self.health.register("data_dir", self._data_check)
        self.health.register("generation_model", self._llm_path_check)
        self.health.register("embedding_model", self._embedding_path_check)
        self.health.register("qdrant_executable", self._qdrant_exe_check)
        return self

    async def _kernel_check(self): return True
    async def _data_check(self):
        self.settings.data_dir.mkdir(parents=True, exist_ok=True)
        return self.settings.data_dir.exists()
    async def _llm_path_check(self): return Path(self.settings.llm["path"]).is_file()
    async def _embedding_path_check(self): return Path(self.settings.embedding["path"]).is_file()
    async def _qdrant_exe_check(self):
        return await self.qdrant_process.is_ready() or Path(self.settings.qdrant["executable"]).is_file()

    async def health_check(self):
        results = await self.health.run()
        for r in results:
            self.logger.info("Health %-20s %s %s", r.name, "OK" if r.ok else "FAIL", r.detail)
        failed = [r for r in results if not r.ok]
        if failed:
            self.logger.warning("Pre-start checks failed: %s", ", ".join(x.name for x in failed))

    async def start(self):
        self.logger.info("%s %s starting", self.settings.app_name, self.settings.version)
        await self.qdrant_process.start()
        if not await self.vector.health_check():
            raise RuntimeError("Qdrant health check failed after startup")
        dimension = await self.embedding.dimension()
        await self.vector.ensure_collection(dimension)
        self.logger.info("Embedding ready: dimension=%s", dimension)
        if not await self.llm.health_check():
            raise RuntimeError("Generation model is unavailable")
        self.logger.info("AI runtime ready")

    async def serve(self):
        import uvicorn
        from fastapi import FastAPI
        from app.api.routes import build_router
        api = FastAPI(title=self.settings.app_name, version=self.settings.version)
        api.include_router(build_router(self), prefix="/api/v1")
        cfg = uvicorn.Config(api, host=self.settings.host, port=self.settings.port, log_level=self.settings.log_level.lower())
        self.server = uvicorn.Server(cfg)
        await self.server.serve()

    async def stop(self):
        if hasattr(self, "server"):
            self.server.should_exit = True
        await self.qdrant_process.stop()
        self._stop.set()
        self.logger.info("Core stopped")
