from __future__ import annotations
import json, mimetypes, os, sys, threading, traceback, webbrowser, tempfile, shutil, cgi, subprocess, urllib.request, re, time, uuid
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse

# V7.0.1: make direct-script startup independent of cwd/PYTHONPATH.
# Insert the project root BEFORE importing anything from the app package.
HERE = Path(__file__).resolve()
ROOT = HERE.parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.localgeoai.data_paths import DATA_ROOT
from app.localgeoai.model_paths import resolve_embedding_model
from app.localgeoai.main import RuntimeManager, RAG
from app.localgeoai.orchestrator.intent_router import IntentRouter
from app.localgeoai.orchestrator.unified_engine import UnifiedEngine
from app.localgeoai.orchestrator.llm_query_planner import plan_query
from app.localgeoai.orchestrator.conversation_state import ConversationState
from app.localgeoai.orchestrator.llm_client import LLMClient
from app.localgeoai.spatial.store import SpatialCatalog
from app.localgeoai.spatial.nl_router import parse_radius_query
from app.localgeoai.spatial.query_planner import plan_spatial_question
from app.localgeoai.runtime_hardware import detect_hardware, runtime_snapshot
from app.localgeoai.spatial.aviation_local import answer_local_aviation
from app.localgeoai.spatial.local_map_qa import answer_local_map
from app.localgeoai.spatial.map_bridge import attach_map
from app.localgeoai.structured.catalog import StructuredCatalog
from app.localgeoai.ingestion.registry import classify, supported, capabilities
from app.localgeoai.ingestion.email_parser import parse_eml
from app.localgeoai.enterprise.omni import OmniIndex
from app.localgeoai.enterprise.hybrid_router import classify as enterprise_route, rrf
from app.localgeoai.main import general_chat
from app.localgeoai.vision.image_catalog import ImageCatalog
from app.localgeoai.enterprise.email_intelligence import EmailIntelligence, is_email_collection_question
from app.localgeoai.enterprise.email_catalog import EmailCatalog
from app.localgeoai.enterprise.universal_corpus import UniversalCorpusAnalyzer
from app.localgeoai.ingestion.email_parser import parse_email
from app.localgeoai.model_manager import ModelManager
from app.localgeoai.ingestion.ocr_engine import status as ocr_status

CONFIG=json.loads((ROOT/"config.json").read_text(encoding="utf-8"))
WEB=ROOT/"web"
INBOX=DATA_ROOT/"inbox"
INBOX.mkdir(parents=True, exist_ok=True)
SPUPLOAD=DATA_ROOT/"spatial/uploads"
SPUPLOAD.mkdir(parents=True, exist_ok=True)
rag=RAG()
router=IntentRouter()
spatial=SpatialCatalog()
unified=UnifiedEngine(rag,spatial,router)
structured=unified.structured
# V6.2: no built-in airport seed is auto-loaded. Local user data is authoritative.
runtime=RuntimeManager()
omni=OmniIndex(ROOT,rag,structured,spatial,CONFIG)
images=ImageCatalog(ROOT)
emailintel=EmailIntelligence(omni.email_catalog, general_chat, manifest=omni.manifest, data_root=DATA_ROOT)
corpusintel=UniversalCorpusAnalyzer(omni.manifest, general_chat, DATA_ROOT)
modelmgr=ModelManager(ROOT,runtime,CONFIG)
OPEN_SOURCES={}
ANALYSIS_JOBS={}
ANALYSIS_LOCK=threading.Lock()
CONVERSATION=ConversationState(max_turns=8)

def _job_update(job_id, **kw):
    with ANALYSIS_LOCK:
        j=ANALYSIS_JOBS.get(job_id)
        if not j:return
        j.update(kw)
        j["last_progress_at"]=time.time()
        total=max(int(j.get("total") or 0),1); processed=int(j.get("processed") or 0)
        j["percent"]=round(100*processed/total,1) if j.get("total") else 0
        elapsed=max(time.time()-j["started_at"],0); j["elapsed_seconds"]=round(elapsed,1)
        j["eta_seconds"]=round(elapsed*(j["total"]-processed)/processed,1) if processed>0 and processed<j["total"] else (0 if processed>=j.get("total",1) else None)

def _start_email_analysis(question, mode="exhaustive", scope_path=None):
    job_id=uuid.uuid4().hex[:16]
    ANALYSIS_JOBS[job_id]={"job_id":job_id,"status":"queued","stage":"آماده‌سازی","processed":0,"total":0,"batch":0,"batches":0,"failed":0,"percent":0,"started_at":time.time(),"eta_seconds":None}
    def run():
        try:
            _job_update(job_id,status="running",stage="همگام‌سازی بانک ایمیل با Canonical Store")
            sync=omni.reconcile_email_catalog()
            def cb(**kw):_job_update(job_id,status="running",**kw)
            result=emailintel.answer(question,scope_path=scope_path,collection=(mode=="exhaustive"),exhaustive=(mode=="exhaustive"),filtered=(mode=="filtered"),progress_cb=cb)
            result["canonical_sync"]=sync
            _job_update(job_id,status="done",stage="تکمیل شد",result=result,processed=(result.get("coverage") or {}).get("processed",0),total=(result.get("coverage") or {}).get("total",0))
        except Exception as e:
            _job_update(job_id,status="error",stage="خطا",error=str(e))
    threading.Thread(target=run,daemon=True,name="corpus-"+job_id).start()
    return job_id

def _start_universal_analysis(question, scope_path=None):
    job_id=uuid.uuid4().hex[:16]
    ANALYSIS_JOBS[job_id]={"job_id":job_id,"status":"queued","stage":"آماده‌سازی تحلیل جامع","processed":0,"total":0,"batch":0,"batches":0,"failed":0,"percent":0,"started_at":time.time(),"eta_seconds":None,"corpus_label":"فایل"}
    def run():
        try:
            def cb(**kw):_job_update(job_id,status="running",**kw)
            result=corpusintel.answer(question,scope_path=scope_path,progress_cb=cb)
            cov=result.get("coverage") or {}
            _job_update(job_id,status="done",stage="تکمیل شد",result=result,processed=cov.get("processed",0),total=cov.get("total",0),failed=cov.get("failed",0))
        except Exception as e:_job_update(job_id,status="error",stage="خطا",error=str(e))
    threading.Thread(target=run,daemon=True,name="universal-corpus-"+job_id).start()
    return job_id

def _start_ingest_job(path, ocr_mode="off", folder=False):
    job_id=uuid.uuid4().hex[:16]
    ANALYSIS_JOBS[job_id]={"job_id":job_id,"status":"queued","stage":"classifying","processed":0,"total":0 if folder else 1,"failed":0,"percent":0,"started_at":time.time(),"last_progress_at":time.time(),"kind":"ingest","current_file":""}
    def run():
        try:
            _job_update(job_id,status="running",stage="classifying",current_file=str(path))
            if folder:
                def cb(**kw): _job_update(job_id,status="running",**kw)
                result=omni.folder(path,ocr_mode,progress_cb=cb)
                failed=len(result.get("errors",[]))
                total=int(result.get("files",0) or 0)
                processed=total
            else:
                _job_update(job_id,status="running",stage="indexing",current_file=str(path))
                result=omni.ingest(path,ocr_mode=ocr_mode,progress_cb=lambda **kw:_job_update(job_id,status='running',processed=0,total=1,current_file=str(path),**kw))
                failed=1 if result.get("status")=="error" else 0
                total=processed=1
            _job_update(job_id,status="done" if not failed else "partial",stage="completed" if not failed else "partial",result=result,processed=processed,total=total,failed=failed,current_file="")
        except Exception as e:_job_update(job_id,status="error",stage="failed",error=str(e),failed=1)
    threading.Thread(target=run,daemon=True,name="ingest-"+job_id).start(); return job_id

def local_aliases(subject):
    """Use Gemma only to propose spellings/transliterations/codes; coordinates/facts must come from local data."""
    subject=str(subject or '').strip()
    if not subject:return []
    g=CONFIG["services"]["generation"]
    prompt=("Return ONLY a JSON array with up to 8 alternative spellings/transliterations for this place/entity name. "
            "Persian and Latin variants are useful. Do not provide coordinates or factual claims. Entity: "+subject)
    try:
        r=http_json("POST",url(g["host"],g["port"],"/v1/chat/completions"),{"model":"local-gemma","messages":[{"role":"user","content":prompt}],"temperature":0.0,"max_tokens":120},60)
        txt=str(r.get("choices",[{}])[0].get("message",{}).get("content","")).strip()
        m=re.search(r'\[[\s\S]*?\]',txt); arr=json.loads(m.group(0)) if m else []
        return [str(x).strip() for x in arr if str(x).strip()][:8]
    except Exception:return []

def json_bytes(obj):
    return json.dumps(obj,ensure_ascii=False).encode("utf-8")

def _probe(url):
    try:
        with urllib.request.urlopen(url,timeout=1.5) as r:return r.status<500
    except Exception:return False
def health():
    sv=CONFIG["services"]; es=omni.health(); info=es.get("info",{}) if es.get("ok") else {}
    return {"ok":True,"app":CONFIG["app"]["name"],"version":CONFIG["app"]["version"],
      "services":{"backend":"ready","qdrant":"ready" if _probe(f'http://{sv["qdrant"]["host"]}:{sv["qdrant"]["port"]}/readyz') else "offline",
      "generation":"ready" if _probe(f'http://{sv["generation"]["host"]}:{sv["generation"]["port"]}/health') else "offline",
      "embedding":"ready" if _probe(f'http://{sv["embedding"]["host"]}:{sv["embedding"]["port"]}/health') else "offline",
      "elasticsearch":"ready" if es.get("ok") else "offline","elasticsearch_version":info.get("version",{}).get("number","")},
      "capabilities":{**capabilities(),"ocr":ocr_status()},"hardware":{**detect_hardware(),"runtime":runtime_snapshot(ROOT)},"active_llm":Path(CONFIG["models"]["generation"]).name,"embedding_model":resolve_embedding_model(ROOT, CONFIG["models"].get("embedding")).name,"spatial":{"enabled":True,"osm_output":True}}


class H(BaseHTTPRequestHandler):
    server_version="LocalChatBot/1.0"
    def log_message(self, fmt, *args):
        print("[WEB]",fmt%args)

    def send_json(self,obj,status=200):
        if isinstance(obj,dict) and isinstance(obj.get("sources"),list):
            import hashlib
            for src in obj["sources"]:
                if not isinstance(src,dict): continue
                raw=str(src.get("original_path") or src.get("source") or "")
                pp=Path(raw) if raw else None
                if pp and pp.exists() and pp.is_file():
                    sid=hashlib.sha256(str(pp.resolve()).encode("utf-8")).hexdigest()[:24]
                    OPEN_SOURCES[sid]=str(pp.resolve()); src["source_id"]=sid; src["openable"]=True
        b=json_bytes(obj)
        self.send_response(status)
        self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Content-Length",str(len(b)))
        self.end_headers(); self.wfile.write(b)

    def do_GET(self):
        p=urlparse(self.path).path
        if p=="/api/models/llm": return self.send_json({"ok":True,"models":modelmgr.models(),"runtime":modelmgr.status()})
        if p=="/api/ocr/status": return self.send_json({"ok":True,**ocr_status()})
        if p.startswith("/api/picker/"):
            mode=p.rsplit("/",1)[-1]
            if mode not in ("spatial_file","document","folder","document_folder"): return self.send_json({"error":"bad picker mode"},400)
            picker=ROOT/"app/localgeoai/ui/native_picker.py"
            out=ROOT/"data/.picker_result.json"
            try:
                if out.exists(): out.unlink()
                subprocess.run([sys.executable,str(picker),mode],check=True)
                obj=json.loads(out.read_text(encoding="utf-8")) if out.exists() else {"path":""}
                return self.send_json(obj)
            except Exception as e:return self.send_json({"error":str(e)},500)
        if p.startswith("/api/analysis/status/"):
            jid=p.rsplit("/",1)[-1]
            with ANALYSIS_LOCK:
                src=ANALYSIS_JOBS.get(jid)
                if not src: j={}
                else:
                    j=dict(src)
                    now=time.time()
                    j["elapsed_seconds"]=round(max(now-float(j.get("started_at") or now),0),1)
                    last=float(j.get("last_progress_at") or j.get("started_at") or now)
                    j["idle_seconds"]=round(max(now-last,0),1)
                    # Watchdog is informative: never kill a worker that may be inside OCR/embedding/GDAL.
                    if j.get("status") in ("queued","running") and j["idle_seconds"] >= 300:
                        j["watchdog"]="stalled"
                        j["stage_detail"]="No progress heartbeat for 300 seconds; worker may be blocked in the current subsystem."
            if not j:return self.send_json({"error":"analysis job not found"},404)
            return self.send_json(j)
        if p=="/api/maps/status":
            mp=DATA_ROOT/"maps/world/osm_world_z0_z6.pmtiles"
            return self.send_json({"ok":True,"installed":mp.is_file(),"path":str(mp),"size":mp.stat().st_size if mp.is_file() else 0,"minzoom":0,"maxzoom":6,"endpoint":"/api/maps/world.pmtiles"})
        if p=="/api/maps/world.pmtiles":
            mp=DATA_ROOT/"maps/world/osm_world_z0_z6.pmtiles"
            if not mp.is_file(): return self.send_error(404,"Offline PMTiles basemap not installed")
            size=mp.stat().st_size; rg=self.headers.get("Range","")
            start,end=0,size-1
            if rg.startswith("bytes="):
                try:
                    a,b=rg[6:].split("-",1); start=int(a or 0); end=int(b) if b else size-1; end=min(end,size-1)
                except Exception: return self.send_error(416,"Invalid Range")
            if start < 0 or start >= size or end < start: return self.send_error(416,"Range Not Satisfiable")
            length=end-start+1; self.send_response(206 if rg else 200); self.send_header("Content-Type","application/octet-stream"); self.send_header("Accept-Ranges","bytes"); self.send_header("Content-Length",str(length))
            if rg:self.send_header("Content-Range",f"bytes {start}-{end}/{size}")
            self.end_headers()
            with mp.open("rb") as fh:
                fh.seek(start); remaining=length
                while remaining>0:
                    chunk=fh.read(min(1024*1024,remaining))
                    if not chunk: break
                    self.wfile.write(chunk); remaining-=len(chunk)
            return
        if p=="/api/health": return self.send_json(health())
        if p=="/api/email/status": return self.send_json({"ok":True,"catalog_total":omni.email_catalog.count(),"db":str(omni.email_catalog.db),**emailintel.inventory()})
        if p=="/api/spatial/datasets": return self.send_json({"datasets":spatial.datasets(),"stats":spatial.stats()})

        if p=="/api/config":
            return self.send_json({
                "features":CONFIG.get("features",{}),
                "rag":CONFIG.get("rag",{}),
                "spatial":CONFIG.get("spatial",{})
            })
        if p=="/": p="/index.html"
        f=(WEB/p.lstrip("/")).resolve()
        if WEB.resolve() not in f.parents and f!=WEB.resolve():
            return self.send_error(403)
        if not f.exists() or not f.is_file(): return self.send_error(404)
        b=f.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type",mimetypes.guess_type(f.name)[0] or "application/octet-stream")
        self.send_header("Content-Length",str(len(b))); self.end_headers(); self.wfile.write(b)

    def do_POST(self):
        p=urlparse(self.path).path
        try:
            if p in ("/api/upload/document","/api/upload/spatial"):
                env={"REQUEST_METHOD":"POST","CONTENT_TYPE":self.headers.get("Content-Type",""),
                     "CONTENT_LENGTH":self.headers.get("Content-Length","0")}
                form=cgi.FieldStorage(fp=self.rfile,headers=self.headers,environ=env,keep_blank_values=True)
                item=form["file"] if "file" in form else None
                if item is None or not getattr(item,"file",None):
                    return self.send_json({"error":"No file uploaded"},400)
                filename=Path(getattr(item,"filename",None) or form.getfirst("filename","upload.bin")).name
                target_dir=SPUPLOAD if p.endswith("/spatial") else INBOX
                target=target_dir/filename
                with open(target,"wb") as out:
                    shutil.copyfileobj(item.file,out)
                if p.endswith("/spatial"):
                    kind=form.getfirst("kind","feature")
                    result=spatial.ingest(target,None,str(kind))
                    return self.send_json({"ok":True,"stored":str(target),**result})
                ocr_mode=str(form.getfirst("ocr_mode","off") or "off"); result=omni.ingest(target,ocr_mode=ocr_mode)
                code=200 if result.get("status") in ("ready","partial") else 422
                return self.send_json({"ok":code==200,"stored":str(target),"file":filename,**result},code)
            n=int(self.headers.get("Content-Length","0"))
            body=json.loads(self.rfile.read(n).decode("utf-8") or "{}")

            if p=="/api/source/open":
                sid=str(body.get("source_id","") or ""); target=OPEN_SOURCES.get(sid)
                if not target or not Path(target).is_file(): return self.send_json({"error":"source not available"},404)
                try:
                    if os.name=="nt": os.startfile(target)
                    else: subprocess.Popen(["xdg-open",target])
                    return self.send_json({"ok":True})
                except Exception as e:return self.send_json({"error":str(e)},500)

            if p=="/api/ingest-universal-folder":
                folder=Path(str(body.get("path",""))).expanduser().resolve()
                if not folder.is_dir(): return self.send_json({"error":"folder not found"},404)
                result=omni.folder(folder,str(body.get("ocr_mode","off") or "off"))
                return self.send_json({"ok":True,"folder":str(folder),**result,"supported":supported()})
            if p=="/api/ingest-folder":
                folder=Path(str(body.get("path",""))).expanduser().resolve()
                if not folder.is_dir(): return self.send_json({"error":"folder not found"},404)
                result=omni.folder(folder,str(body.get("ocr_mode","off") or "off"))
                stats={}
                for x in result.get("results",[]):
                    k=x.get("kind","unknown");stats[k]=stats.get(k,0)+1
                return self.send_json({"ok":True,"folder":str(folder),**result,"stats":stats})
            if p=="/api/spatial/ingest-folder":
                folder=Path(str(body.get("path",""))).expanduser().resolve()
                if not folder.is_dir(): return self.send_json({"error":"folder not found"},404)
                recursive=bool(body.get("recursive",True))
                patterns=("*.geojson","*.json","*.csv","*.shp","*.gpkg","*.kml","*.kmz")
                files=[]
                for pat in patterns:
                    files.extend(folder.rglob(pat) if recursive else folder.glob(pat))
                results=[]; errors=[]
                for f in sorted(set(files)):
                    try: results.append(spatial.ingest(f,None,body.get("kind","feature")))
                    except Exception as e: errors.append({"file":str(f),"error":str(e)})
                return self.send_json({"ok":True,"files":len(results),"features":sum(x["count"] for x in results),
                    "results":results,"errors":errors})
            if p=="/api/spatial/ingest":
                path=Path(str(body.get("path",""))).expanduser()
                if not path.is_absolute(): path=(ROOT/path).resolve()
                if not path.exists(): return self.send_json({"error":f"file not found: {path}"},404)
                return self.send_json({"ok":True,**spatial.ingest(path,body.get("name_field"),body.get("kind","feature"))})
            if p=="/api/spatial/resolve":
                matches=spatial.resolve(str(body.get("query","")),body.get("kind"))
                return self.send_json({"ok":True,"matches":matches})
            if p=="/api/spatial/nearby":
                radius=float(body.get("radius_km",100))
                if radius<=0 or radius>20000: return self.send_json({"error":"radius_km must be >0 and <=20000"},400)
                center=None
                if body.get("center_name"):
                    found=spatial.resolve(str(body["center_name"]), body.get("kind")) or spatial.resolve(str(body["center_name"]))
                    if not found: return self.send_json({"error":"Center name not found in local spatial catalog."},404)
                    center=found[0]
                else:
                    center={"name":"Center","lat":float(body["lat"]),"lon":float(body["lon"])}
                rows=spatial.nearby(center["lat"],center["lon"],radius,body.get("kind"),int(body.get("limit",100)))
                rows=[x for x in rows if x["id"]!=center.get("id")]
                return self.send_json({"ok":True,"center":center,"radius_km":radius,"count":len(rows),
                    "features":rows,"geojson":spatial.geojson(rows,center,radius),
                    "interpretation":"candidate_set_not_proof_of_origin"})
            if p=="/api/enterprise/ingest":
                path=Path(str(body.get("path",""))).expanduser(); path=path if path.is_absolute() else (ROOT/path).resolve()
                if not path.exists(): return self.send_json({"error":"file not found"},404)
                return self.send_json({"ok":True,**omni.ingest(path)})
            if p=="/api/enterprise/ingest-folder":
                folder=Path(str(body.get("path",""))).expanduser().resolve()
                if not folder.is_dir():return self.send_json({"error":"folder not found"},404)
                return self.send_json({"ok":True,**omni.folder(folder)})
            if p=="/api/images/map": return self.send_json({"ok":True,"geojson":images.geojson()})
            if p=="/api/models/llm/switch":
                return self.send_json(modelmgr.switch(str(body.get("model","") or "")))

            if p=="/api/email/rebuild":
                r=omni.email_catalog.rebuild(parse_email,omni._sha); return self.send_json({"ok":True,**r})
            if p=="/api/ask":
                q=str(body.get("question","")).strip(); scope_path=str(body.get("scope_path","") or '').strip(); scope_mode=str(body.get("scope_mode","") or '').strip()
                if not q: return self.send_json({"error":"question is empty"},400)
                # V6.4.3: ALL intent/domain analysis is performed by the active LLM.
                # No keyword/country/topic table is authoritative for routing.
                try:
                    query_plan=plan_query(q,spatial.query_profile(max_values=80),scope_path or None,CONVERSATION.summary())
                except Exception as e:
                    return self.send_json({"answer":"مدل زبانی نتوانست برنامه اجرای سؤال را تولید کند.","intent":"planner_error","requires_map":False,"sources":[],"error_code":"LLM_QUERY_PLANNER_FAILED","detail":str(e)},502)
                if not query_plan:
                    return self.send_json({"answer":"برنامه ساختاریافته معتبری از مدل زبانی دریافت نشد.","intent":"planner_error","requires_map":False,"sources":[],"error_code":"INVALID_LLM_QUERY_PLAN"},502)
                domain=query_plan.get("domain","knowledge")
                analysis_mode=str(query_plan.get("analysis_mode") or "retrieval").lower()
                # Conversational interaction is allowed, but factual corpus claims still route to local engines.
                if analysis_mode=="conversation":
                    try:
                        msgs=[{'role':'system','content':'You are LocalChatBot, a fully local assistant. Reply naturally in Persian. For general conversation and explanations you may reason normally. Never invent facts about the user local corpus; corpus facts require tools.'}]+CONVERSATION.messages()+[{'role':'user','content':q}]
                        ans,_=LLMClient('conversation').chat(msgs,max_tokens=520,temperature=.25)
                        CONVERSATION.add('user',q,task='conversation'); CONVERSATION.add('assistant',ans)
                    except Exception as e: return self.send_json({"answer":"در حال حاضر موتور زبانی محلی برای گفت‌وگو پاسخ نداد.","intent":"conversation","sources":[],"requires_map":False,"detail":str(e)},502)
                    return self.send_json({"answer":ans,"intent":"conversation","sources":[],"requires_map":False,"query_plan":query_plan})
                # Corpus-wide analysis is universal: PDF/DOCX/TXT/email/OCR/table text are enumerated from Canonical Store.
                if analysis_mode in ("exhaustive_corpus","filtered_corpus"):
                    jid=_start_universal_analysis(q,scope_path=(scope_path or None))
                    return self.send_json({"job_started":True,"job_id":jid,"intent":"universal_corpus_analysis","answer":"تحلیل جامع همه منابع محلی آغاز شد."})
                # V6.3.7: folder scope must NOT pre-empt spatial planning. A previous document/email
                # folder may remain selected while the user asks about an active spatial dataset.
                # Dedicated engines run first; document folder retrieval is the final scoped fallback.
                # Scoped local intelligence routes.
                collection_email=is_email_collection_question(q)
                selected_email=scope_path.lower().endswith(('.eml','.msg'))
                if domain=="email":
                    try:
                        # Collection questions intentionally ignore the selected-file scope.
                        # A selected EML/MSG is reconciled into the local catalog on demand.
                        if selected_email and not collection_email:
                            sp=Path(scope_path)
                            if sp.exists() and not omni.email_catalog.list(1,sp):
                                meta,txt=parse_email(sp,DATA_ROOT/'attachments'/omni._sha(sp)[:16]);omni.email_catalog.upsert(omni._sha(sp),sp,meta,txt)
                        analysis_mode=str((query_plan or {}).get("analysis_mode") or "retrieval").lower()
                        exhaustive=bool(collection_email or analysis_mode=="exhaustive_corpus")
                        filtered=bool(analysis_mode in ("filtered","filtered_corpus"))
                        if exhaustive or filtered:
                            mode="exhaustive" if exhaustive else "filtered"
                            jid=_start_email_analysis(q,mode=mode,scope_path=(None if exhaustive else scope_path or None))
                            return self.send_json({"job_started":True,"job_id":jid,"intent":"email_corpus_analysis" if exhaustive else "email_filtered_corpus_analysis","answer":"تحلیل سراسری ایمیل‌ها آغاز شد."})
                        return self.send_json(emailintel.answer(q,scope_path=scope_path,collection=False,exhaustive=False))
                    except Exception as e:return self.send_json({"answer":"تحلیل ایمیل محلی با خطا مواجه شد.","intent":"email_collection" if collection_email else "email_selected","sources":[],"error_code":"EMAIL_INTELLIGENCE_FAILED","detail":str(e)},500)
                # V6 central planner: dedicated engines first, general chat never depends on RAG.
                if domain=="general":
                    # V6.4.4 LOCAL-DATA-ONLY: the LLM may plan/reason, but it may never publish parametric knowledge.
                    # Even a general-looking question must be answered from the selected/local corpus or fail closed.
                    result=unified.ask(q,scope_path=scope_path or None,scope_mode=scope_mode or None,query_plan=query_plan)
                    result["intent"]="local_only"; result["query_plan"]=query_plan
                    bridge=attach_map(q,result.get("answer",""),query_plan,spatial,result.get("sources") or [])
                    if bridge and bridge.get("requested"):
                        result["requires_map"]=True; result["spatial_note"]=bridge.get("note") or ""
                        result["map_bridge"]={"probes":bridge.get("probes") or [],"resolved":len(bridge.get("results") or [])}
                        if bridge.get("geojson"):
                            result["map"]=bridge["geojson"]; result["results"]=bridge.get("results") or []
                    return self.send_json(result)
                # V6.3.5 data-driven spatial planner: Gemma chooses only among fields/values actually present in local data.
                sp_plan=plan_spatial_question(q,spatial) if domain in ("spatial","mixed") else None
                if sp_plan:
                    rows=spatial.filter_property(sp_plan["field"],sp_plan["value"],kind=sp_plan.get("kind"),limit=5000)
                    # V2.2.0: no query-word post-filtering here; semantic spatial planner must choose grounded schema/value constraints.
                    gj={"type":"FeatureCollection","features":[]}
                    for x in rows:
                        p2=dict(x.get("properties") or {});p2["name"]=x.get("name") or p2.get("name");p2["source"]=x.get("source")
                        gj["features"].append({"type":"Feature","geometry":{"type":"Point","coordinates":[x["lon"],x["lat"]]},"properties":p2})
                    # Complete-list spatial requests are never silently truncated. The chat text can be long,
                    # but the user explicitly asked for the complete local result set.
                    preview=[]
                    for x in rows:
                        pp=x.get("properties") or {}; code=pp.get("iata_code") or pp.get("icao_code") or pp.get("ident") or ""
                        preview.append((x.get("name") or code)+(f" — {code}" if code else ""))
                    label=sp_plan.get("place_text") or sp_plan.get("value")
                    answer=f"{len(rows)} عارضه مطابق «{label}» در داده مکانی محلی پیدا شد. همه {len(rows)} نتیجه در متن/جدول و نقشه در دسترس‌اند."
                    if preview: answer+="\n\n"+"\n".join("• "+v for v in preview)
                    import hashlib
                    rid=hashlib.sha256((q+'|'+sp_plan['field']+'|'+sp_plan['value']+'|'+str(len(rows))).encode('utf-8')).hexdigest()[:16]
                    srcs=[]
                    for n,spth in enumerate(dict.fromkeys(str(x.get('source') or '') for x in rows if x.get('source')),1):
                        srcs.append({'n':n,'type':'spatial','source':spth,'original_path':spth,'text':f"{len([x for x in rows if str(x.get('source') or '')==spth])} عارضه در Result Set"})
                    return self.send_json({"answer":answer,"intent":"spatial_filter","requires_map":True,"map":gj,"results":rows,"sources":srcs,"result_set_id":rid,"execution_status":"success","spatial_note":"فیلتر مکانی روی داده‌های محلی اجرا شد.","query_plan":query_plan,"spatial_execution":{"field":sp_plan["field"],"value":sp_plan["value"],"kind":sp_plan.get("kind"),"result_set_id":rid},"result_count":len(rows),"text_preview_count":len(rows)})

                # V6.1.4: local aviation evidence has priority over built-in/world helper datasets.
                # It fuses the user's spatial catalog, user-defined aircraft and geotagged images.
                aviation=answer_local_aviation(q,spatial,images,rag,local_aliases) if domain in ("spatial","mixed") else None
                if aviation:
                    return self.send_json(aviation)
                # Generic map/base-map question: resolve facts from user spatial catalog; Gemma only expands aliases.
                localmap=answer_local_map(q,spatial,local_aliases) if domain in ("spatial","mixed") else None
                if localmap:
                    return self.send_json(localmap)
                sq=parse_radius_query(q) if domain in ("spatial","mixed") else None
                if sq:
                    if not sq.get("center"):
                        return self.send_json({"answer":"سؤال مکانی تشخیص داده شد، اما نام مرکز از متن استخراج نشد.","intent":"spatial_radius","requires_map":True,"spatial_note":"نام مرکز را واضح‌تر ذکر کنید."})
                    kind=sq.get("kind")
                    resolved=spatial.resolve(sq["center"],kind=kind)
                    if not resolved and kind: resolved=spatial.resolve(sq["center"],kind=None)
                    if not resolved:
                        return self.send_json({"answer":f"مرکز «{sq['center']}» در کاتالوگ مکانی پیدا نشد.","intent":"spatial_radius","requires_map":True,"spatial_note":"نام یا کد دیگری برای مرکز وارد کنید."})
                    center=resolved[0]
                    rows=spatial.nearby(center["lat"],center["lon"],sq["radius_km"],kind=kind,limit=500)
                    if not rows and kind: rows=spatial.nearby(center["lat"],center["lon"],sq["radius_km"],kind=None,limit=1000)
                    rows=[x for x in rows if float(x.get("distance_km",999999))>0.01]
                    gj={"type":"FeatureCollection","features":[]}
                    for x in rows[:500]:
                        p2=dict(x.get("properties") or {});p2["name"]=x.get("name") or p2.get("name");p2["distance_km"]=x.get("distance_km")
                        gj["features"].append({"type":"Feature","geometry":{"type":"Point","coordinates":[x["lon"],x["lat"]]},"properties":p2})
                    label="فرودگاه" if kind=="airport" else ("باند" if kind=="runway" else "عارضه")
                    preview=[]
                    for x in rows[:12]:
                        p2=dict(x.get("properties") or {});code=p2.get("iata_code") or p2.get("icao_code") or p2.get("ident") or ""
                        preview.append(f"{x.get('name') or p2.get('name') or code} ({x.get('distance_km',0):.1f} km)")
                    answer=f"{len(rows)} {label} در شعاع {sq['radius_km']:g} کیلومتری {center['name']} پیدا شد."
                    if preview: answer+="\n\n"+"\n".join(f"• {v}" for v in preview)
                    return self.send_json({"answer":answer,"intent":"spatial_radius","requires_map":True,"map":gj,"results":rows[:500],"spatial_note":f"مرکز: {center['name']} | شعاع: {sq['radius_km']:g} km"})
                # General local intelligence path. Folder scope is evaluated only after spatial
                # engines had a chance to execute, preventing stale document scope from stealing GIS questions.
                try:
                    result=unified.ask(q,scope_path=scope_path or None,scope_mode=scope_mode or None,query_plan=query_plan)
                    if not str(result.get("answer","")).strip():
                        result={"answer":"موتور پاسخ خالی برگرداند؛ پاسخ تولید نشد.","intent":"error","requires_map":False,"sources":[],"error_code":"EMPTY_ANSWER"}
                    result["query_plan"]=query_plan
                    # V2.2.3: a grounded document answer may itself reveal the place that must be mapped
                    # (e.g. question asks where an object is located; RAG answers with an airport).  Resolve
                    # that place against the LOCAL SpatialCatalog and attach real coordinates to the response.
                    bridge=attach_map(q,result.get("answer",""),query_plan,spatial,result.get("sources") or [])
                    if bridge and bridge.get("requested"):
                        result["requires_map"]=True
                        result["spatial_note"]=bridge.get("note") or ""
                        result["map_bridge"]={"probes":bridge.get("probes") or [],"resolved":len(bridge.get("results") or [])}
                        if bridge.get("geojson"):
                            result["map"]=bridge["geojson"]
                            result["results"]=bridge.get("results") or []
                    return self.send_json(result)
                except TimeoutError as e:
                    return self.send_json({"answer":"زمان پاسخ مدل محلی به پایان رسید. سؤال ثبت شد اما پاسخ تولید نشد.","intent":"error","requires_map":False,"sources":[],"error_code":"LLM_TIMEOUT","detail":str(e)},504)
                except Exception as e:
                    traceback.print_exc()
                    return self.send_json({"answer":"خطا در مسیر بازیابی/تولید پاسخ.","intent":"error","requires_map":False,"sources":[],"error_code":"QUERY_PIPELINE_FAILED","detail":str(e)},500)

            if p=="/api/ingest-job":
                path=Path(str(body.get("path","") or "")).expanduser()
                if not path.is_absolute(): path=(ROOT/path).resolve()
                if not path.exists(): return self.send_json({"error":f"path not found: {path}"},404)
                folder=path.is_dir(); jid=_start_ingest_job(path,str(body.get("ocr_mode","off") or "off"),folder=folder)
                return self.send_json({"ok":True,"job_started":True,"job_id":jid,"intent":"ingestion","answer":"ایندکس در پس‌زمینه آغاز شد."},202)
            if p=="/api/ingest":
                path=Path(str(body.get("path",""))).expanduser()
                if not path.is_absolute(): path=(ROOT/path).resolve()
                if not path.exists() or not path.is_file(): return self.send_json({"error":f"file not found: {path}"},404)
                result=omni.ingest(path,ocr_mode=str(body.get("ocr_mode","off") or "off")); code=200 if result.get("status") in ("ready","partial") else 422
                return self.send_json({"ok":code==200,**result},code)
            if p=="/api/spatial/preview":
                # UI/API contract preview; real layers will come from local spatial DB.
                return self.send_json({
                    "type":"localgeoai.map","layers":[],
                    "analysis":{"status":"ready_for_local_spatial_data"},
                    "sources":[]
                })
            return self.send_json({"error":"not found"},404)
        except Exception as e:
            traceback.print_exc()
            return self.send_json({"error":str(e)},500)

def main():
    host=CONFIG["app"].get("host","127.0.0.1")
    port=int(CONFIG["app"].get("port",8080))
    print("Starting persistent AI runtime...")
    runtime.start_all()
    httpd=ThreadingHTTPServer((host,port),H)
    print(f"[OK] LocalGeoAI Web UI: http://{host}:{port}")
    threading.Timer(1.2,lambda:webbrowser.open(f"http://{host}:{port}")).start()
    try: httpd.serve_forever()
    except KeyboardInterrupt: pass
    finally:
        httpd.server_close()
        # Explicitly release persistent SQLite handles before process shutdown.
        for obj in (spatial, structured, images):
            try:
                close=getattr(obj,"close",None)
                if callable(close): close()
            except Exception:
                traceback.print_exc()
        runtime.stop()

if __name__=="__main__": main()
