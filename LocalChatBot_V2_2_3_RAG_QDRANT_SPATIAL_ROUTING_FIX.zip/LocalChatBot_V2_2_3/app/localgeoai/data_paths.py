from __future__ import annotations
import json, os
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parents[2]

def _configured_root() -> Path:
    env = os.environ.get("LOCALCHATBOT_DATA_ROOT", "").strip()
    if env:
        p = Path(os.path.expandvars(os.path.expanduser(env)))
        return p if p.is_absolute() else (APP_ROOT / p).resolve()
    try:
        cfg=json.loads((APP_ROOT/'config.json').read_text(encoding='utf-8'))
        raw=str(cfg.get('persistence',{}).get('data_root','')).strip()
        if raw:
            p=Path(os.path.expandvars(os.path.expanduser(raw)))
            return p if p.is_absolute() else (APP_ROOT/p).resolve()
    except Exception:
        pass
    # Shared sibling directory survives side-by-side application upgrades.
    return (APP_ROOT.parent/'LocalChatBot_PersistentData').resolve()

DATA_ROOT=_configured_root()
DATA_ROOT.mkdir(parents=True,exist_ok=True)

def data_path(*parts: str) -> Path:
    p=DATA_ROOT.joinpath(*parts)
    p.parent.mkdir(parents=True,exist_ok=True)
    return p
