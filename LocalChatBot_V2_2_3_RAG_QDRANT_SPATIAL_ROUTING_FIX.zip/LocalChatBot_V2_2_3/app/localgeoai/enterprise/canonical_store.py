from pathlib import Path
import sqlite3,hashlib,time,json

class CanonicalStore:
 def __init__(self,root):
  self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True);self.db=self.root/"canonical.sqlite3"
  self._run("CREATE TABLE IF NOT EXISTS files(id INTEGER PRIMARY KEY,path TEXT UNIQUE,sha256 TEXT,size INTEGER,mtime REAL,kind TEXT,status TEXT,error TEXT,text_path TEXT,metadata TEXT,es_status TEXT DEFAULT 'pending',vector_status TEXT DEFAULT 'pending',updated REAL)")
  self._run("CREATE INDEX IF NOT EXISTS ix_sha ON files(sha256)")
 def _run(self,sql,args=(),fetchone=False):
  c=sqlite3.connect(self.db)
  try:
   cur=c.execute(sql,args);row=cur.fetchone() if fetchone else None;cur.close();c.commit();return row
  finally:
   c.close()
 def close(self): return None
 def sha256(self,p):
  h=hashlib.sha256()
  with open(p,"rb") as f:
   for b in iter(lambda:f.read(4194304),b""):h.update(b)
  return h.hexdigest()
 def changed(self,p):
  p=Path(p);s=p.stat();r=self._run("SELECT size,mtime,status FROM files WHERE path=?",(str(p),),True)
  return not r or r[0]!=s.st_size or abs((r[1] or 0)-s.st_mtime)>.001 or r[2]!="ready"

 def get(self,p):
  p=Path(p);r=self._run("SELECT sha256,size,mtime,kind,status,text_path,metadata,es_status,vector_status FROM files WHERE path=?",(str(p),),True)
  if not r:return None
  return {"sha256":r[0],"size":r[1],"mtime":r[2],"kind":r[3],"status":r[4],"text_path":r[5],"metadata":r[6],"es_status":r[7],"vector_status":r[8]}
 def unchanged_sha(self,p,sha):
  r=self.get(p)
  return bool(r and r.get("sha256")==sha and r.get("status") in {"ready","partial"})
 def mark(self,p,kind,status,sha=None,text_path="",metadata=None,error=None):
  p=Path(p);s=p.stat()
  self._run("INSERT INTO files(path,sha256,size,mtime,kind,status,error,text_path,metadata,updated) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(path) DO UPDATE SET sha256=excluded.sha256,size=excluded.size,mtime=excluded.mtime,kind=excluded.kind,status=excluded.status,error=excluded.error,text_path=excluded.text_path,metadata=excluded.metadata,updated=excluded.updated",(str(p),sha,s.st_size,s.st_mtime,kind,status,error,str(text_path),json.dumps(metadata or {},ensure_ascii=False),time.time()))

 def list_files(self,kind=None,statuses=("ready","partial")):
  c=sqlite3.connect(self.db)
  try:
   sql="SELECT path,sha256,kind,status,text_path,metadata FROM files"; args=[]; where=[]
   if kind:
    where.append("kind=?"); args.append(str(kind))
   if statuses:
    qs=','.join('?' for _ in statuses); where.append(f"status IN ({qs})"); args.extend(statuses)
   if where: sql += " WHERE " + " AND ".join(where)
   rows=c.execute(sql,args).fetchall()
   return [{"path":r[0],"sha256":r[1],"kind":r[2],"status":r[3],"text_path":r[4],"metadata":r[5]} for r in rows]
  finally:c.close()
