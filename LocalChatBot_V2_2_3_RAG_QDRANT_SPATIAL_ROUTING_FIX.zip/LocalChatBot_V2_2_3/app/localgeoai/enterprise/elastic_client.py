import json,urllib.request
class ElasticClient:
 def __init__(self,url="http://127.0.0.1:9200",index="localgeoai"):self.url=url.rstrip("/");self.index=index
 def _req(self,method,path,data=None,timeout=5):
  b=None if data is None else json.dumps(data,ensure_ascii=False).encode()
  q=urllib.request.Request(self.url+path,data=b,method=method,headers={"Content-Type":"application/json"})
  with urllib.request.urlopen(q,timeout=timeout) as r:
   x=r.read();return json.loads(x) if x else {}
 def health(self):
  try:return {"ok":True,"info":self._req("GET","/")}
  except Exception as e:return {"ok":False,"error":str(e)}
 def ensure(self):
  try:self._req("GET","/"+self.index);return
  except:pass
  self._req("PUT","/"+self.index,{"mappings":{"properties":{"path":{"type":"keyword"},"sha256":{"type":"keyword"},"kind":{"type":"keyword"},"title":{"type":"text"},"subject":{"type":"text"},"body":{"type":"text"},"normalized_body":{"type":"text"},"from":{"type":"keyword"},"to":{"type":"keyword"},"date":{"type":"date","ignore_malformed":True}}}})
 def index_doc(self,id,doc):self.ensure();return self._req("PUT",f"/{self.index}/_doc/{id}",doc)
 def search(self,q,size=30,filters=None):
  self.ensure();body={"size":size,"query":{"bool":{"must":[{"multi_match":{"query":q,"fields":["title^3","subject^4","body","normalized_body^2","path"]}}],"filter":filters or []}}}
  r=self._req("POST",f"/{self.index}/_search",body);return [{"id":x["_id"],"score":x.get("_score"),"source":x["_source"]} for x in r.get("hits",{}).get("hits",[])]

 def list_path(self,path,size=50):
  self.ensure(); body={"size":int(size),"query":{"bool":{"filter":[{"term":{"path":str(path)}}]}}}
  r=self._req("POST",f"/{self.index}/_search",body);return [{"id":x["_id"],"score":x.get("_score") or 1.0,"source":x["_source"]} for x in r.get("hits",{}).get("hits",[])]

 def search_path(self,q,path,size=12):
  self.ensure(); body={"size":int(size),"query":{"bool":{"must":[{"multi_match":{"query":q,"fields":["title^3","subject^4","body"]}}],"filter":[{"term":{"path":str(path)}}]}}}
  r=self._req("POST",f"/{self.index}/_search",body);return [{"id":x["_id"],"score":x.get("_score"),"source":x["_source"]} for x in r.get("hits",{}).get("hits",[])]

 def list_kind(self,kind,size=200):
  self.ensure();body={"size":int(size),"query":{"bool":{"filter":[{"term":{"kind":kind}}]}},"sort":[{"date":{"order":"desc","unmapped_type":"date"}}]}
  try:r=self._req("POST",f"/{self.index}/_search",body)
  except Exception:
   body.pop("sort",None);r=self._req("POST",f"/{self.index}/_search",body)
  return [{"id":x["_id"],"score":x.get("_score") or 1.0,"source":x["_source"]} for x in r.get("hits",{}).get("hits",[])]

 def search_scope(self,q,folder=None,kind=None,size=30):
  self.ensure(); filters=[]
  if folder:
   prefix=str(folder).rstrip('\\/')+('\\' if '\\' in str(folder) else '/')
   filters.append({'prefix':{'path':prefix}})
  if kind: filters.append({'term':{'kind':str(kind)}})
  must=[{'multi_match':{'query':q,'fields':['title^3','subject^4','body','normalized_body^2','path']}}] if str(q or '').strip() else [{'match_all':{}}]
  body={'size':int(size),'query':{'bool':{'must':must,'filter':filters}}}
  r=self._req('POST',f'/{self.index}/_search',body);return [{'id':x['_id'],'score':x.get('_score') or 1.0,'source':x['_source']} for x in r.get('hits',{}).get('hits',[])]

 def list_scope(self,folder=None,kind=None,size=500):
  return self.search_scope('',folder=folder,kind=kind,size=size)

# V6.3.9 exact corpus-manifest retrieval: avoids fragile folder-prefix assumptions.
def _lg_search_paths(self,q,paths,kind=None,size=60):
 self.ensure(); paths=[str(x) for x in paths if str(x).strip()]
 if not paths:return []
 filters=[{'terms':{'path':paths}}]
 if kind:filters.append({'term':{'kind':str(kind)}})
 must=[{'multi_match':{'query':q,'fields':['title^4','subject^5','body^2','normalized_body^3','path']}}] if str(q or '').strip() else [{'match_all':{}}]
 body={'size':int(size),'query':{'bool':{'must':must,'filter':filters}}}
 r=self._req('POST',f'/{self.index}/_search',body)
 return [{'id':x['_id'],'score':x.get('_score') or 1.0,'source':x['_source']} for x in r.get('hits',{}).get('hits',[])]
ElasticClient.search_paths=_lg_search_paths
