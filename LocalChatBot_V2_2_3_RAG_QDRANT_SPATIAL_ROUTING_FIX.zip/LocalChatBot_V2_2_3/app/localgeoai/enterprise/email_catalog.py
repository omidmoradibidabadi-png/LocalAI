from __future__ import annotations
from pathlib import Path
import sqlite3,json,time

class EmailCatalog:
    def __init__(self,root,data_root_mode=False):
        self.root=Path(root); self.data_root_mode=data_root_mode; self.dir=(self.root/'email_catalog' if data_root_mode else self.root/'data/email_catalog'); self.dir.mkdir(parents=True,exist_ok=True); self.db=self.dir/'emails.sqlite3'
        self._run("CREATE TABLE IF NOT EXISTS emails(sha256 TEXT PRIMARY KEY,path TEXT UNIQUE,subject TEXT,sender TEXT,recipients TEXT,cc TEXT,bcc TEXT,date TEXT,message_id TEXT,thread_refs TEXT,body TEXT,attachments TEXT,updated REAL)")
        self._run("CREATE INDEX IF NOT EXISTS ix_email_path ON emails(path)")
    def _run(self,sql,args=(),fetch=False):
        c=sqlite3.connect(self.db)
        try:
            cur=c.execute(sql,args); rows=cur.fetchall() if fetch else None; cur.close(); c.commit(); return rows
        finally:c.close()
    def upsert(self,sha,path,meta,body):
        a=json.dumps(meta.get('attachments',[]),ensure_ascii=False)
        refs=' '.join(str(meta.get(k,'')) for k in ('message_id','in_reply_to','references'))
        self._run("INSERT INTO emails(sha256,path,subject,sender,recipients,cc,bcc,date,message_id,thread_refs,body,attachments,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(sha256) DO UPDATE SET path=excluded.path,subject=excluded.subject,sender=excluded.sender,recipients=excluded.recipients,cc=excluded.cc,bcc=excluded.bcc,date=excluded.date,message_id=excluded.message_id,thread_refs=excluded.thread_refs,body=excluded.body,attachments=excluded.attachments,updated=excluded.updated",(sha,str(Path(path).resolve()),str(meta.get('subject','')),str(meta.get('from','')),str(meta.get('to','')),str(meta.get('cc','')),str(meta.get('bcc','')),str(meta.get('date','')),str(meta.get('message_id','')),refs,str(body or ''),a,time.time()))
    def list(self,limit=500,path=None):
        if path: rows=self._run("SELECT sha256,path,subject,sender,recipients,cc,bcc,date,message_id,body,attachments FROM emails WHERE path=? ORDER BY updated DESC LIMIT ?",(str(Path(path).resolve()),int(limit)),True)
        else: rows=self._run("SELECT sha256,path,subject,sender,recipients,cc,bcc,date,message_id,body,attachments FROM emails ORDER BY updated DESC LIMIT ?",(int(limit),),True)
        keys=('sha256','path','subject','from','to','cc','bcc','date','message_id','body','attachments')
        out=[]
        for r in rows:
            d=dict(zip(keys,r))
            try:d['attachments']=json.loads(d['attachments'] or '[]')
            except:d['attachments']=[]
            out.append(d)
        return out
    def search(self,q,limit=200,path=None):
        docs=self.list(max(limit*3,300),path); terms=[x.casefold() for x in str(q or '').replace('؟',' ').replace('?',' ').split() if len(x)>2]
        if not terms:return docs[:limit]
        scored=[]
        for d in docs:
            hay=' '.join(str(d.get(k,'')) for k in ('subject','from','to','body')).casefold(); s=sum(hay.count(t) for t in terms)
            if s:scored.append((s,d))
        scored.sort(key=lambda x:-x[0]); return [d for _,d in scored[:limit]] or docs[:limit]
    def count(self):return int(self._run('SELECT count(*) FROM emails',fetch=True)[0][0])
    def rebuild(self,parse_email,sha_fn):
        ok=bad=0
        for base in ((self.root/'inbox', self.root/'documents', self.root/'extracted_archives') if self.data_root_mode else (self.root/'data/inbox', self.root/'data/documents', self.root/'data/extracted_archives')):
            if not base.exists():continue
            for p in base.rglob('*'):
                if p.is_file() and p.suffix.lower() in {'.eml','.msg'}:
                    try:
                        meta,body=parse_email(p,(self.root/'attachments' if self.data_root_mode else self.root/'data/attachments')/sha_fn(p)[:16]); self.upsert(sha_fn(p),p,meta,body);ok+=1
                    except Exception:bad+=1
        return {'indexed':ok,'failed':bad,'total':self.count(),'db':str(self.db)}
