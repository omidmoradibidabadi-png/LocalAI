from __future__ import annotations
import json,re,collections
from pathlib import Path
from app.localgeoai.ingestion.email_parser import parse_email
from app.localgeoai.orchestrator.answer_reliability import evidence_fallback

EMAIL_HINT=re.compile(r'(ایمیل|ايميل|نامه.?های الکترونیک|email|e-mail|mail)',re.I)
SUMMARY_HINT=re.compile(r'(همه|تمام|کل|جامع|تحلیل.*(?:ایمیل|ايميل)|(?:ایمیل|ايميل).*تحلیل|خلاصه.*(?:ایمیل|ايميل)|جمع.?بندی|موضوعات.*(?:ایمیل|ايميل)|مرور.*(?:ایمیل|ايميل)|all\s+(?:emails?|mail)|entire.*(?:emails?|mail)|corpus|collection|overview.*(?:emails?|mail)|analy[sz]e.*(?:emails?|mail))',re.I)
def is_email_collection_question(q):return bool(EMAIL_HINT.search(q or '') and SUMMARY_HINT.search(q or ''))

def _json_obj(text):
    text=str(text or '').strip()
    for pat in (r'```(?:json)?\s*([\s\S]*?)```',r'(\{[\s\S]*\})'):
        m=re.search(pat,text,re.I)
        if m:
            try:return json.loads(m.group(1))
            except Exception:pass
    return None

class EmailIntelligence:
    """V2.0.2: Canonical Store is authoritative; EmailCatalog is only a derived cache."""
    def __init__(self,catalog,chat_fn,manifest=None,data_root=None):
        self.catalog=catalog;self.chat=chat_fn;self.manifest=manifest;self.data_root=Path(data_root) if data_root else None

    def _canonical_docs(self,scope_path=None):
        rows=self.manifest.list_files(kind='email') if self.manifest else []
        scope=Path(scope_path).resolve() if scope_path else None
        docs=[]; failed=[]
        for row in rows:
            p=Path(row.get('path') or '')
            try:
                rp=p.resolve()
                if scope:
                    if scope.is_file() and rp!=scope: continue
                    if scope.is_dir():
                        try: rp.relative_to(scope)
                        except ValueError: continue
                if not p.is_file() or p.suffix.lower() not in {'.eml','.msg'}:
                    failed.append({'path':str(p),'error':'source file missing or unsupported'});continue
                meta,body=parse_email(p,(self.data_root/'attachments'/(row.get('sha256') or 'unknown')[:16]) if self.data_root else None)
                d={'sha256':row.get('sha256'),'path':str(rp),'subject':str(meta.get('subject','')),'from':str(meta.get('from','')),'to':str(meta.get('to','')),'cc':str(meta.get('cc','')),'bcc':str(meta.get('bcc','')),'date':str(meta.get('date','')),'message_id':str(meta.get('message_id','')),'body':str(body or ''),'attachments':meta.get('attachments',[])}
                docs.append(d)
                try:
                    if self.catalog and not self.catalog.list(1,p):self.catalog.upsert(row.get('sha256') or '',p,meta,body)
                except Exception:pass
            except Exception as e:failed.append({'path':str(p),'error':str(e)})
        docs.sort(key=lambda d:(d.get('date',''),d.get('path','')))
        return docs,failed,len(rows)

    def inventory(self,scope_path=None):
        docs,failed,canonical=self._canonical_docs(scope_path)
        return {'canonical_emails':canonical,'readable_emails':len(docs),'failed_emails':len(failed),'failures':failed[:20]}

    def _map_batch(self,batch,start,question=None,filter_mode=False):
        ev='\n\n'.join(f"EMAIL [{start+j}]\nSubject: {d.get('subject','')}\nFrom: {d.get('from','')}\nTo: {d.get('to','')}\nCC: {d.get('cc','')}\nDate: {d.get('date','')}\nAttachments: {d.get('attachments',[])}\nBody: {str(d.get('body',''))[:12000]}" for j,d in enumerate(batch))
        if filter_mode:
            prompt=f'''Inspect EVERY email below against the user's exact question. Accuracy is more important than speed. Return JSON only. For each email that materially helps answer the question, include its source number and a concise evidence-grounded analysis. Do not select an email merely because generic words overlap. Do not omit a relevant email.\nSchema: {{"matches":[{{"source":1,"why_relevant":"","findings":[""]}}]}}\nUSER QUESTION: {question}\nEMAILS:\n{ev}'''
        else:
            prompt=f'''Analyze EVERY email below for a corpus-wide report answering the user's request. Return JSON only. Do not omit minority findings merely because they are rare. Preserve source email numbers for every finding. Schema:\n{{"topics":[{{"name":"","sources":[1]}}],"people":[],"organizations":[],"events":[{{"text":"","sources":[1]}}],"action_items":[{{"text":"","sources":[1]}}],"anomalies":[{{"text":"","sources":[1]}}],"important_findings":[{{"text":"","sources":[1]}}]}}\nUse only supplied emails; do not guess.\nUSER QUESTION: {question or ''}\nEMAILS:\n{ev}'''
        try:
            raw=self.chat(prompt,900);obj=_json_obj(raw)
            if isinstance(obj,dict):return obj
            return {'batch_error':'model returned non-JSON','raw':str(raw)[:4000]}
        except Exception as e:return {'batch_error':str(e)}

    def _reduce_group(self,items,question):
        raw=json.dumps(items,ensure_ascii=False)
        prompt=f'''Merge these structured email analyses into ONE evidence-grounded structured analysis for the exact user question. Preserve/union source numbers. Keep rare but relevant findings. Do not invent facts. USER QUESTION: {question}\nReturn JSON only. INPUT:\n{raw}'''
        try:
            obj=_json_obj(self.chat(prompt,1100));return obj if isinstance(obj,dict) else {'important_findings':[{'text':str(obj or '')[:5000],'sources':[]}]}
        except Exception:return {'important_findings':[{'text':raw[:5000],'sources':[]}]}

    def _hierarchical_reduce(self,items,question):
        cur=items
        while len(cur)>1:
            cur=[self._reduce_group(cur[i:i+5],question) for i in range(0,len(cur),5)]
        return cur[0] if cur else {}

    def answer(self,q,limit=200,scope_path=None,collection=False,exhaustive=False,filtered=False,progress_cb=None):
        # Every email analysis begins from Canonical Store, never from an independent catalog count.
        all_docs,read_failures,canonical_total=self._canonical_docs(scope_path if not collection else None)
        if not all_docs:
            return {'answer':'در Canonical Store ایمیل قابل‌خواندن پیدا نشد.','intent':'email_analysis','sources':[],'email_count':0,'requires_map':False,'scope':'canonical-email-only','coverage':{'processed':0,'total':canonical_total,'readable':0,'failed':len(read_failures),'percent':0},'integrity':self.inventory(scope_path)}
        total=len(all_docs);batch_size=6;batches=(total+batch_size-1)//batch_size
        if collection or exhaustive or filtered:
            mode='filtered' if filtered and not (collection or exhaustive) else 'exhaustive'
            if progress_cb:progress_cb(processed=0,total=total,batch=0,batches=batches,failed=len(read_failures),stage='خواندن Canonical Store')
            mapped=[];batch_failed=0
            for bi,i in enumerate(range(0,total,batch_size),1):
                obj=self._map_batch(all_docs[i:i+batch_size],i+1,q,filter_mode=(mode=='filtered'))
                if obj.get('batch_error'):batch_failed+=1
                mapped.append(obj)
                if progress_cb:progress_cb(processed=min(i+len(all_docs[i:i+batch_size]),total),total=total,batch=bi,batches=batches,failed=len(read_failures)+batch_failed,stage=f'تحلیل محتوایی Batch {bi} از {batches}')
            if progress_cb:progress_cb(processed=total,total=total,batch=batches,batches=batches,failed=len(read_failures)+batch_failed,stage='تجمیع و کنترل پوشش')
            merged=self._hierarchical_reduce(mapped,q)
            if mode=='filtered':
                # Collect exact matched source ordinals from first-pass outputs as a deterministic coverage ledger.
                matched=[]
                for obj in mapped:
                    for m in obj.get('matches',[]) if isinstance(obj,dict) else []:
                        try:n=int(m.get('source'));matched.append(n)
                        except Exception:pass
                matched=sorted(set(n for n in matched if 1<=n<=total))
                evidence='\n'.join(f"[{n}] {all_docs[n-1].get('subject','')} | {all_docs[n-1].get('from','')} | {all_docs[n-1].get('date','')}" for n in matched)
                prompt=f'''Answer the user's Persian question only from the structured analysis and matched-email ledger below. State that all {total} readable canonical emails were checked, state how many matched, explain what was discussed, and cite [n]. Do not add outside knowledge.\nQUESTION: {q}\nMATCHED EMAILS:\n{evidence or 'NONE'}\nANALYSIS:\n{json.dumps(merged,ensure_ascii=False)}'''
                intent='email_filtered_corpus_analysis';matched_count=len(matched)
            else:
                senders=collections.Counter(str(d.get('from') or '').strip() for d in all_docs if str(d.get('from') or '').strip());top='، '.join(f'{k} ({v})' for k,v in senders.most_common(8)) or 'نامشخص'
                prompt=f'''Write a comprehensive Persian analytical report ONLY from the corpus analysis below. Coverage is {total}/{canonical_total} canonical emails readable. Mention coverage explicitly. Organize findings when supported and cite [n]. Do not add outside knowledge. USER QUESTION: {q}\nFrequent senders: {top}\nCORPUS ANALYSIS:\n{json.dumps(merged,ensure_ascii=False)}'''
                intent='email_corpus_analysis';matched_count=total
            try:answer=self.chat(prompt,1800).strip()
            except Exception:answer=json.dumps(merged,ensure_ascii=False,indent=2)
            coverage={'processed':total,'total':canonical_total,'readable':total,'matched':matched_count,'percent':round(100*total/max(canonical_total,1),2),'batches':batches,'failed_files':len(read_failures),'failed_batches':batch_failed,'mode':mode+'_canonical_scan'}
            docs=all_docs
        else:
            # Fast retrieval mode still uses the derived catalog, but cannot claim corpus-wide coverage.
            docs=self.catalog.search(q,limit,scope_path) if self.catalog else []
            ev=[{'n':i+1,'text':f"Subject: {d.get('subject','')}. {str(d.get('body',''))[:1800]}",'score':1} for i,d in enumerate(docs[:30])]
            if not ev:return {'answer':'در جست‌وجوی سریع ایمیل شاهد کافی پیدا نشد. برای بررسی همه ایمیل‌ها درخواست تحلیل جامع/سراسری بدهید.','intent':'email_retrieval','sources':[],'email_count':total,'requires_map':False,'scope':'canonical-email-only','coverage':{'processed':0,'total':canonical_total,'percent':0,'mode':'retrieval'}}
            try:answer=self.chat('فقط بر اساس ایمیل‌های زیر پاسخ بده و [n] را حفظ کن.\n'+'\n\n'.join(f"[{x['n']}] {x['text']}" for x in ev),700).strip()
            except Exception:answer=evidence_fallback(q,ev)
            intent='email_retrieval';coverage={'processed':len(ev),'total':canonical_total,'percent':round(100*len(ev)/max(canonical_total,1),2),'mode':'retrieval'}
        src=[{'n':n,'type':'email-local','source':d.get('path') or 'email','original_path':d.get('path') or '','page':'email','score':1.0,'text':f"Subject: {d.get('subject','')} | From: {d.get('from','')} | Date: {d.get('date','')}"} for n,d in enumerate(docs[:100],1)]
        return {'answer':answer,'intent':intent,'sources':src,'email_count':len(docs),'requires_map':False,'scope':'canonical-email-only','coverage':coverage,'integrity':{'canonical_emails':canonical_total,'readable_emails':total,'failed_emails':len(read_failures)}}
