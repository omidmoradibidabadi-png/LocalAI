import re
def classify(q):
 s=q.strip().lower()
 if re.search(r"(نقشه|شعاع|فاصله|اطراف|نزدیک|مختصات|map|radius)",s): return "spatial"
 if re.search(r"\d",s) and re.search(r"(بیشتر|کمتر|حداقل|حداکثر|بین|>|<|برد|سرعت|ظرفیت)",s): return "structured"
 email=bool(re.search(r"(ایمیل|فرستنده|گیرنده|subject|from:|to:|@[A-Za-z0-9._-]+)",q,re.I))
 code=bool(re.search(r"[A-Za-z]{1,8}[-_/]?\d{2,}",q))
 semantic=bool(re.search(r"(چرا|علت|نشانه|مفهوم|مرتبط|مشابه|تحلیل|خلاصه|چه می)",s))
 if email and not semantic:return "elastic"
 if (email or code) and semantic:return "hybrid"
 if semantic:return "vector"
 if code:return "elastic"
 return "hybrid"
def rrf(named,k=60,limit=12):
 scores={};obj={}
 for name,items in named.items():
  for rank,x in enumerate(items,1):
   key=str(x.get("key") or x.get("id") or x.get("path") or name+str(rank))
   scores[key]=scores.get(key,0)+1/(k+rank);obj[key]=x
 return [dict(obj[x],rrf_score=scores[x]) for x in sorted(scores,key=scores.get,reverse=True)[:limit]]
