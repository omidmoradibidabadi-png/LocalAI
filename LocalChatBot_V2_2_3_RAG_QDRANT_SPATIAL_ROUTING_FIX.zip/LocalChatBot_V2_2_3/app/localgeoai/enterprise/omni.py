from __future__ import annotations
from pathlib import Path
import json,hashlib,time,csv
from app.localgeoai.enterprise.elastic_client import ElasticClient
from app.localgeoai.enterprise.canonical_store import CanonicalStore
from app.localgeoai.data_paths import DATA_ROOT
from app.localgeoai.ingestion.registry import classify
from app.localgeoai.ingestion.email_parser import parse_email
from app.localgeoai.enterprise.email_catalog import EmailCatalog
from app.localgeoai.text_normalization import normalize_search_text
class OmniIndex:
 def __init__(self,root,rag,structured,spatial,config):
  self.root=Path(root);self.rag=rag;self.structured=structured;self.spatial=spatial;self.cfg=config
  es=config.get('enterprise_search',{});self.es=ElasticClient(es.get('elasticsearch_url','http://127.0.0.1:9200'));self.manifest=CanonicalStore(DATA_ROOT/'canonical_store');self.cache=DATA_ROOT/'extracted';self.cache.mkdir(parents=True,exist_ok=True);self.email_catalog=EmailCatalog(DATA_ROOT, data_root_mode=True)
 def reconcile_email_catalog(self):
  """Make exhaustive email analysis use the same Canonical Store as normal ingestion."""
  seen=added=failed=0
  for row in self.manifest.list_files(kind='email'):
   seen+=1; p=Path(row.get('path') or '')
   if not p.is_file() or p.suffix.lower() not in {'.eml','.msg'}: continue
   try:
    sha=row.get('sha256') or self._sha(p)
    if not self.email_catalog.list(1,p):
     meta,body=parse_email(p,DATA_ROOT/'attachments'/sha[:16]); self.email_catalog.upsert(sha,p,meta,body);added+=1
   except Exception: failed+=1
  return {'canonical_emails':seen,'catalog_total':self.email_catalog.count(),'added':added,'failed':failed}
 def _sha(self,p):
  h=hashlib.sha256();
  with open(p,'rb') as f:
   for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
  return h.hexdigest()
 def _es_doc(self,p,kind,text='',meta=None,sha=''):
  m=meta or {};return {'path':str(p.resolve()),'sha256':sha,'kind':kind,'title':p.stem,'subject':m.get('subject',''),'body':text[:500000],'normalized_body':normalize_search_text(text)[:500000],'from':m.get('from',''),'to':m.get('to',''),'date':m.get('date',''),'metadata':m}
 def _sections(self,p,ocr_mode="off"):
  from app.localgeoai.ingestion.universal_parser import parse
  return parse(p,ocr_mode=ocr_mode)
 def _text(self,p,ocr_mode="off"):
  return '\n'.join(t for _,t in self._sections(p,ocr_mode))
 def _coordinate_csv(self,p):
  """Cheap schema probe. Coordinate CSVs are spatial+structured data and must not be sent through serial RAG embedding during ingestion."""
  try:
   if Path(p).suffix.lower()!='.csv': return False
   with open(p,'r',encoding='utf-8-sig',errors='replace',newline='') as fh:
    r=csv.reader(fh); heads=next(r,[])
   keys={str(x or '').strip().casefold() for x in heads}
   lat={'lat','latitude','latitude_deg','y'}; lon={'lon','lng','longitude','longitude_deg','x'}
   return bool(keys & lat) and bool(keys & lon)
  except Exception:
   return False
 def ingest(self,p,depth=0,ocr_mode="off",progress_cb=None):
  ocr_mode=str(ocr_mode or "off").lower()
  if ocr_mode not in {"off","auto","force"}: ocr_mode="off"
  p=Path(p);kind=classify(p);sha=self._sha(p);out={'file':str(p),'kind':kind,'sha256':sha,'chunks':0,'rows':0,'features':0,'es':False,'attachments':0,'status':'processing','warnings':[]}
  if depth>3:return {**out,'status':'skipped','error':'container nesting limit reached'}
  if self.cfg.get('persistence',{}).get('incremental_indexing',True) and self.manifest.unchanged_sha(p,sha):
   # V2.1.2: Canonical Store says the source bytes are unchanged, but derived stores may
   # be empty after an application upgrade/move. Rebuild ONLY missing derived indexes.
   recovered=False
   if kind=='email' and p.suffix.lower() in {'.eml','.msg'}:
    try:
     if not self.email_catalog.list(1,p):
      meta,text=parse_email(p,DATA_ROOT/'attachments'/sha[:16]);self.email_catalog.upsert(sha,p,meta,text);recovered=True
    except Exception as e:
     out.setdefault('warnings',[]).append('Email catalog reconcile: '+str(e))
   if kind=='spatial':
    try:
     existing=int(self.spatial.source_count(p)) if hasattr(self.spatial,'source_count') else 0
     if existing<=0:
      sr=self.spatial.ingest(p,kind='auto');out['features']=int(sr.get('count',0));out['spatial_recovered']=True;recovered=True
     else:
      out['features']=existing;out['spatial_present']=True
    except Exception as e:
     out.setdefault('warnings',[]).append('Spatial catalog reconcile: '+str(e))
   elif kind=='structured' and p.suffix.lower()=='.csv':
    # Coordinate CSVs are structured-first, but they must also survive/rebuild the spatial catalog.
    try:
     existing=int(self.spatial.source_count(p)) if hasattr(self.spatial,'source_count') else 0
     if existing<=0:
      sr=self.spatial.ingest(p,kind='auto');out['features']=int(sr.get('count',0));out['spatial_auto']=True;out['spatial_recovered']=True;recovered=bool(out['features'])
     else:
      out['features']=existing;out['spatial_auto']=True;out['spatial_present']=True
    except Exception as e:
     # A normal non-coordinate CSV is not an error.
     if 'latitude/longitude' not in str(e):out.setdefault('warnings',[]).append('Spatial auto-index reconcile: '+str(e))
   # V2.2.3: Canonical readiness is not proof that semantic vectors exist.
   # Verify the derived Qdrant store for every text-bearing source and rebuild it when absent.
   if kind in {'document','presentation','image','email'} or (kind=='structured' and not self._coordinate_csv(p)):
    try:
     qcount=int(self.rag.indexed_count(p)) if hasattr(self.rag,'indexed_count') else len(self.rag.retrieve_path(p,limit=1))
     out['qdrant_points']=qcount
     if qcount<=0:
      if progress_cb: progress_cb(stage='chunking',current_file=str(p),heartbeat=True)
      if kind=='email' and p.suffix.lower() in {'.eml','.msg'}:
       ad=DATA_ROOT/'attachments'/sha[:16];meta,text=parse_email(p,ad)
       sections=[(1,'\n'.join(f'{k}: {v}' for k,v in meta.items() if k!='attachments')+'\n\n'+text)]
       out['chunks']=self.rag.ingest_pages(p,sections,progress_cb=progress_cb)
      else:
       sections=self._sections(p,ocr_mode)
       out['chunks']=self.rag.ingest_pages(p,sections,progress_cb=progress_cb)
      out['qdrant_points']=int(self.rag.indexed_count(p)) if hasattr(self.rag,'indexed_count') else out['chunks']
      out['rag_recovered']=True; recovered=True
    except Exception as e:
     out.setdefault('warnings',[]).append('Qdrant/embedding reconcile: '+str(e))
   status='partial' if out.get('warnings') else ('ready' if recovered else 'unchanged')
   return {**out,'status':status,'skipped_unchanged':not recovered,'derived_reconciled':True}
  try:
   self.manifest.mark(p,kind,'processing',sha=sha)
   if kind=='email':
    if p.suffix.lower() not in {'.eml','.msg'}:raise RuntimeError(f'{p.suffix} recognized but parser is not ready in this build')
    ad=DATA_ROOT/'attachments'/sha[:16];meta,text=parse_email(p,ad);self.email_catalog.upsert(sha,p,meta,text);out['email_catalog']=True;out['attachments']=len(meta.get('attachments',[]));cache=self.cache/(sha+'.txt');cache.write_text('\n'.join(f'{k}: {v}' for k,v in meta.items() if k!='attachments')+'\n\n'+text,encoding='utf-8')
    try:self.es.index_doc(sha,self._es_doc(p,kind,text,meta,sha));out['es']=True
    except Exception as e:out['warnings'].append('Elasticsearch: '+str(e))
    try:out['chunks']=self.rag.ingest_pages(p,[(1,'\n'.join(f'{k}: {v}' for k,v in meta.items() if k!='attachments')+'\n\n'+text)],progress_cb=progress_cb);out['qdrant_points']=self.rag.indexed_count(p)
    except Exception as e:out['warnings'].append('Qdrant/embedding: '+str(e))
    for a in meta.get('attachments',[]):
     ap=Path(a.get('path',''))
     if ap.exists() and classify(ap)!='unsupported':out.setdefault('children',[]).append(self.ingest(ap,depth+1,ocr_mode))
   elif kind in {'document','presentation'}:
    sections=self._sections(p,ocr_mode); text='\n'.join(t for _,t in sections)
    cache=self.cache/(sha+'.txt'); cache.write_text(text,encoding='utf-8')
    extraction_method='native_text+ocr' if '[OCR' in text else 'native_text'
    try:
     if sections:
      for sec_no,sec_text in sections:
       doc=self._es_doc(p,kind,str(sec_text),{},sha);doc['section']=sec_no;doc['section_label']=('Slide '+str(sec_no) if kind=='presentation' else 'Page/Section '+str(sec_no))
       self.es.index_doc(sha+'__'+str(sec_no),doc)
     else:self.es.index_doc(sha,self._es_doc(p,kind,text,{},sha))
     out['es']=True;out['sections']=len(sections)
    except Exception as e:out['warnings'].append('Elasticsearch: '+str(e))
    try:out['chunks']=self.rag.ingest_pages(p,sections,progress_cb=progress_cb);out['qdrant_points']=self.rag.indexed_count(p)
    except Exception as e:out['warnings'].append('Qdrant/embedding: '+str(e))
   elif kind=='structured':
    # V2.1.3: coordinate CSV is a first-class spatial dataset. In older builds it was
    # spatially inserted and then synchronously sent through ES + serial EmbeddingGemma
    # RAG, so the browser remained on "indexing" for a very long time although GIS work
    # was already complete. Spatial/structured indexing must finish independently.
    coord_csv=self._coordinate_csv(p)
    t0=time.monotonic()
    try:out['rows']=self.structured.ingest(p)
    except Exception as e:out['warnings'].append('Structured: '+str(e))
    out.setdefault('timings',{})['structured_sec']=round(time.monotonic()-t0,3)
    if coord_csv:
     t1=time.monotonic()
     try:
      sr=self.spatial.ingest(p,kind='auto');out['features']=int(sr.get('count',0));out['spatial_auto']=True;out['spatial_primary']=True
      out['spatial_schema']=sr.get('schema');out['spatial_sample']=sr.get('sample',[])
     except Exception as e:
      out['warnings'].append('Spatial auto-index: '+str(e))
     out['timings']['spatial_sec']=round(time.monotonic()-t1,3)
     # Deliberately do not run full-file RAG embeddings here. Attributes remain available
     # in StructuredCatalog + SpatialCatalog; spatial questions use the spatial engine.
     out['rag_skipped']='coordinate_csv_spatial_fast_path'
    else:
     try:
      sections=self._sections(p,ocr_mode);text='\n'.join(t for _,t in sections);self.es.index_doc(sha,self._es_doc(p,kind,text,{'ocr_mode':ocr_mode},sha));out['es']=True;out['ocr_mode']=ocr_mode
     except Exception as e:out['warnings'].append('Elasticsearch: '+str(e))
     try:out['chunks']=self.rag.ingest(p,progress_cb=progress_cb);out['qdrant_points']=self.rag.indexed_count(p)
     except Exception as e:out['warnings'].append('Qdrant/embedding: '+str(e))
   elif kind=='spatial':
    r=self.spatial.ingest(p,kind='auto');out['features']=int(r.get('count',0) if isinstance(r,dict) else r or 0)
   elif kind=='image':
    from app.localgeoai.vision.image_catalog import ImageCatalog
    out['image']=ImageCatalog(self.root).ingest(p)
    sections=[]; text=''
    try:
     sections=self._sections(p,ocr_mode);text='\n'.join(t for _,t in sections)
     marker='[OCR confidence='
     ocr_text=text.split(']\n',1)[1].strip() if marker in text and ']\n' in text else ''
     out['ocr']={'mode':ocr_mode,'attempted':ocr_mode in {'auto','force'},'ok':bool(ocr_text),'characters':len(ocr_text)}
     if ocr_mode in {'auto','force'}:
      from app.localgeoai.ingestion.ocr_engine import status as _ocr_status
      ost=_ocr_status();out['ocr']['runtime']=ost
      if not ost.get('engine_ready'): raise RuntimeError('OCR runtime not found: runtime\\ocr\\tesseract.exe')
      if not ost.get('multilingual_ready'): raise RuntimeError('OCR language pack incomplete: fas, eng, ara, heb, chi_sim and chi_tra are required')
     self.es.index_doc(sha,self._es_doc(p,kind,text,{'ocr_mode':ocr_mode,'ocr_characters':len(ocr_text)},sha));out['es']=True;out['ocr_mode']=ocr_mode
    except Exception as e:
     out['ocr']={'mode':ocr_mode,'attempted':ocr_mode in {'auto','force'},'ok':False,'characters':0,'error':str(e)}
     out['warnings'].append('Image text/OCR index: '+str(e))
    try: out['chunks']=self.rag.ingest_pages(p,sections,progress_cb=progress_cb);out['qdrant_points']=self.rag.indexed_count(p) if sections else 0
    except Exception as e: out['warnings'].append('Image Qdrant/embedding: '+str(e))
   elif kind=='archive':
    from app.localgeoai.ingestion.archive_engine import extract
    d=DATA_ROOT/'extracted_archives'/sha[:16];children=extract(p,d);out['children']=[self.ingest(x,depth+1,ocr_mode) for x in children if classify(x)!='unsupported'];out['extracted']=len(children)
   elif kind in {'audio','video','database'}:
    out['warnings'].append(f'{kind} recognized and cataloged; specialist decoder/connector is optional')
   else:raise ValueError('Unsupported file type: '+p.suffix)
   out['status']='partial' if out['warnings'] else 'ready'; meta={'result':out,'original_text_preserved':True,'normalized_search_text':True,'ocr_mode':ocr_mode}; self.manifest.mark(p,kind,out['status'],sha=sha,text_path=(locals().get('cache') or ''),metadata=meta);return out
  except Exception as e:
   out['status']='error';out['error']=str(e)
   try:self.manifest.mark(p,kind,'error',sha=sha,error=str(e))
   except Exception:pass
   return out
 def folder(self,folder,ocr_mode="off",progress_cb=None):
  rows=[]; root=Path(folder).resolve()
  internal_suffixes=('.eml.meta.csv','.chunks.json','.ocr.txt','.extracted.txt')
  eligible=[]
  for p in root.rglob('*'):
   if not p.is_file(): continue
   low=p.name.lower()
   if low.endswith(internal_suffixes): continue
   if classify(p)!='unsupported': eligible.append(p)
  total=len(eligible)
  if progress_cb: progress_cb(stage='classifying',processed=0,total=total,current_file='',heartbeat=True)
  for i,p in enumerate(eligible,1):
   if progress_cb: progress_cb(stage='indexing',processed=i-1,total=total,current_file=str(p),heartbeat=True)
   rows.append(self.ingest(p,ocr_mode=ocr_mode,progress_cb=(lambda **kw: progress_cb(processed=i-1,total=total,current_file=str(p),**kw)) if progress_cb else None))
   if progress_cb: progress_cb(stage='indexing',processed=i,total=total,current_file=str(p),heartbeat=True)
  stats={}
  for x in rows:
   k=x.get('kind','unknown'); stats[k]=stats.get(k,0)+1
  # V6.4.12 folder-only recovery pass. Single-file ingest() above is intentionally unchanged.
  # Batch OCR can temporarily starve the local embedding/ES services on modest hardware;
  # retry only failed downstream indexing after OCR has completed, preserving each image source_path.
  import time
  for x in rows:
   if x.get('kind')!='image': continue
   fp=Path(x.get('file',''))
   if not fp.exists(): continue
   if (x.get('ocr') or {}).get('ok') and int(x.get('chunks') or 0)==0:
    try:
     secs=self._sections(fp,ocr_mode)
     last=None
     for attempt in range(3):
      try:
       x['chunks']=self.rag.ingest_pages(fp,secs) if secs else 0; last=None; break
      except Exception as e:
       last=e; time.sleep(1.5*(attempt+1))
     if last: x.setdefault('warnings',[]).append('Folder RAG retry: '+str(last))
    except Exception as e: x.setdefault('warnings',[]).append('Folder RAG recovery: '+str(e))
   if (x.get('ocr') or {}).get('ok') and not x.get('es'):
    try:
     # Always parse THIS file. Never reuse `secs` left by a previous image iteration.
     es_secs=self._sections(fp,ocr_mode)
     text='\n'.join(t for _,t in es_secs)
     self.es.index_doc(x.get('sha256') or self._sha(fp),self._es_doc(fp,'image',text,{'ocr_mode':ocr_mode,'folder_batch':True},x.get('sha256') or self._sha(fp)));x['es']=True
    except Exception as e: x.setdefault('warnings',[]).append('Folder ES retry: '+str(e))
   if x.get('warnings') and x.get('status')=='ready': x['status']='partial'
  images=[x for x in rows if x.get('kind')=='image']
  ocr_attempted=[x for x in images if (x.get('ocr') or {}).get('attempted')]
  ocr_ok=[x for x in images if (x.get('ocr') or {}).get('ok')]
  ocr_failed=[x for x in ocr_attempted if not (x.get('ocr') or {}).get('ok')]
  image_summary={'found':len(images),'ocr_attempted':len(ocr_attempted),'ocr_ok':len(ocr_ok),'ocr_failed':len(ocr_failed),
                 'ocr_characters':sum(int((x.get('ocr') or {}).get('characters') or 0) for x in images),
                 'rag_chunks':sum(int(x.get('chunks') or 0) for x in images),'es_documents':sum(1 for x in images if x.get('es'))}
  return {'files':len(rows),'results':rows,'stats':stats,'image_summary':image_summary,'errors':[x for x in rows if x.get('status')=='error'],'partial':[x for x in rows if x.get('status')=='partial']}
 def health(self):return self.es.health()
