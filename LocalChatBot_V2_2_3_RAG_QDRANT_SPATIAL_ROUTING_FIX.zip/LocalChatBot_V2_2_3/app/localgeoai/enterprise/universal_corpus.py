from __future__ import annotations
import json, math, re, time
from pathlib import Path
from app.localgeoai.ingestion.registry import classify
from app.localgeoai.ingestion.universal_parser import parse

class UniversalCorpusAnalyzer:
    """V2.1.1 exhaustive analyzer: Canonical Store membership + full-text segmented map/reduce."""
    def __init__(self, manifest, chat_fn, data_root=None):
        self.manifest=manifest; self.chat=chat_fn; self.data_root=Path(data_root) if data_root else None

    def _rows(self,scope_path=None):
        rows=self.manifest.list_files() if self.manifest else []
        scope=Path(scope_path).resolve() if scope_path else None; out=[]
        for r in rows:
            p=Path(r.get('path') or '')
            if not p.is_file(): continue
            try: rp=p.resolve()
            except Exception: continue
            if scope:
                if scope.is_file() and rp!=scope: continue
                if scope.is_dir():
                    try: rp.relative_to(scope)
                    except ValueError: continue
            k=str(r.get('kind') or classify(p))
            if k in {'document','presentation','email','structured','image'}: out.append({**r,'path':str(rp),'kind':k})
        return out

    def _content(self,row):
        p=Path(row['path']); tp=Path(row.get('text_path') or '') if row.get('text_path') else None
        if tp and tp.is_file(): return tp.read_text(encoding='utf-8',errors='replace')
        secs=parse(p,ocr_mode='auto')
        return '\n'.join(str(t) for _,t in secs if str(t).strip())

    @staticmethod
    def _json(text):
        s=str(text or '')
        for pat in (r'```(?:json)?\s*([\s\S]*?)```',r'(\{[\s\S]*\})'):
            m=re.search(pat,s,re.I)
            if m:
                try:return json.loads(m.group(1))
                except Exception:pass
        return None

    def _chat_json(self,prompt,max_tokens=700,retries=2):
        last=None
        for attempt in range(retries+1):
            try:
                raw=self.chat(prompt,max_tokens if attempt==0 else min(max_tokens,520))
                obj=self._json(raw)
                if isinstance(obj,dict): return obj
                last=RuntimeError('LLM returned non-JSON output')
            except Exception as e: last=e
            time.sleep(.25*(attempt+1))
        raise RuntimeError(str(last or 'local LLM call failed'))

    @staticmethod
    def _segments(text,size=6000):
        text=str(text or ''); return [text[i:i+size] for i in range(0,len(text),size)] or ['']

    def _map_unit(self,source_no,seg_no,seg_total,row,text,question):
        prompt=("You are analyzing ONE segment of a local source. Use ONLY the supplied text. Return compact JSON only. "
                "Do not omit relevant facts merely because they are rare. Never invent facts. "
                "Schema: {\"summary\":\"\",\"topics\":[\"\"],\"findings\":[\"\"],\"entities\":[\"\"],\"events\":[\"\"],\"anomalies\":[\"\"]}.\n"
                f"USER REQUEST: {question}\nSOURCE_ID: {source_no}\nSEGMENT: {seg_no}/{seg_total}\nFILE: {row['path']}\nTYPE: {row['kind']}\nTEXT:\n{text}")
        return self._chat_json(prompt,650)

    def _reduce_group(self,group,question):
        raw=json.dumps(group,ensure_ascii=False,separators=(',',':'))
        prompt=("Merge the following LOCAL analyses. Preserve factual diversity and source_id values. Use no outside knowledge. "
                "Return compact JSON only with keys summary, topics, findings, entities, events, anomalies, source_ids.\n"
                f"USER REQUEST: {question}\nINPUT:\n{raw}")
        return self._chat_json(prompt,750)

    def _reduce(self,items,question):
        cur=items[:]
        while len(cur)>1:
            nxt=[]; group=[]; chars=0
            for item in cur:
                s=json.dumps(item,ensure_ascii=False,separators=(',',':'))
                if group and (len(group)>=3 or chars+len(s)>12000):
                    nxt.append(self._reduce_group(group,question)); group=[]; chars=0
                group.append(item); chars+=len(s)
            if group: nxt.append(self._reduce_group(group,question) if len(group)>1 else group[0])
            cur=nxt
        return cur[0] if cur else {}

    def answer(self,question,scope_path=None,progress_cb=None):
        rows=self._rows(scope_path); total_files=len(rows); docs=[]; failures=[]
        if progress_cb: progress_cb(processed=0,total=total_files,batch=0,batches=0,failed=0,stage='خواندن همه منابع Canonical Store')
        for i,r in enumerate(rows,1):
            try:
                text=self._content(r)
                if text.strip(): docs.append({**r,'text':text})
                else: failures.append({'path':r['path'],'error':'empty extracted text'})
            except Exception as e: failures.append({'path':r['path'],'error':str(e)})
            if progress_cb: progress_cb(processed=i,total=total_files,batch=0,batches=0,failed=len(failures),stage='خواندن همه منابع محلی')
        if not docs:
            return {'answer':'در محدوده انتخاب‌شده منبع متنی قابل‌خواندن برای تحلیل جامع پیدا نشد.','intent':'universal_corpus_analysis','sources':[], 'coverage':{'processed':0,'total':total_files,'readable':0,'failed':len(failures),'percent':0},'failures':failures[:50]}

        units=[]
        for source_no,d in enumerate(docs,1):
            segs=self._segments(d['text'])
            for seg_no,txt in enumerate(segs,1): units.append((source_no,seg_no,len(segs),d,txt))
        mapped=[]; failed_units=[]; unit_total=len(units)
        for ui,(source_no,seg_no,seg_total,d,txt) in enumerate(units,1):
            try:
                obj=self._map_unit(source_no,seg_no,seg_total,d,txt,question)
                obj['source_ids']=[source_no]; mapped.append(obj)
            except Exception as e:
                failed_units.append({'source':source_no,'segment':seg_no,'path':d['path'],'error':str(e)})
            if progress_cb: progress_cb(processed=ui,total=unit_total,batch=ui,batches=unit_total,failed=len(failures)+len(failed_units),stage=f'تحلیل کامل متن: بخش {ui} از {unit_total}')

        if failed_units:
            # Exhaustive means exhaustive: never pretend success after skipped LLM segments.
            return {'answer':f'تحلیل جامع کامل نشد: {len(failed_units)} بخش از {unit_total} بخش در مدل زبانی محلی خطا داد. نتیجه ناقص به‌عنوان گزارش نهایی منتشر نشد. می‌توانید عملیات را دوباره اجرا کنید.',
                    'intent':'universal_corpus_analysis','sources':[], 'execution_status':'incomplete',
                    'coverage':{'processed':unit_total-len(failed_units),'total':unit_total,'readable_files':len(docs),'total_files':total_files,'failed_files':len(failures),'failed_segments':len(failed_units),'percent':round(100*(unit_total-len(failed_units))/max(unit_total,1),2),'mode':'exhaustive_segmented_map_reduce'},
                    'failures':(failures+failed_units)[:80]}
        if progress_cb: progress_cb(processed=unit_total,total=unit_total,batch=unit_total,batches=unit_total,failed=len(failures),stage='تجمیع سلسله‌مراتبی')
        try: merged=self._reduce(mapped,question)
        except Exception as e:
            return {'answer':f'همه منابع خوانده شدند، اما مرحله تجمیع گزارش جامع با خطای مدل محلی متوقف شد: {e}', 'intent':'universal_corpus_analysis','sources':[],'execution_status':'reduce_error','coverage':{'processed':unit_total,'total':unit_total,'readable_files':len(docs),'total_files':total_files,'failed_files':len(failures),'percent':100,'mode':'exhaustive_segmented_map_reduce'}}
        final_prompt=("Write a useful, detailed Persian report ONLY from this merged local-corpus analysis. Do not add outside knowledge. "
                      "Mention coverage. Keep concrete findings and cite source ordinals like [1].\n"
                      f"USER REQUEST: {question}\nCOVERAGE: {len(docs)} readable files of {total_files}; file extraction failures={len(failures)}; analyzed text segments={unit_total}.\nANALYSIS:\n"+json.dumps(merged,ensure_ascii=False,separators=(',',':')))
        try: answer=self.chat(final_prompt,1600).strip()
        except Exception as e: return {'answer':f'تحلیل همه بخش‌ها انجام شد اما تولید گزارش نهایی با خطا متوقف شد: {e}','intent':'universal_corpus_analysis','sources':[],'execution_status':'final_error','coverage':{'processed':unit_total,'total':unit_total,'readable_files':len(docs),'total_files':total_files,'percent':100}}
        src=[{'n':i+1,'type':d['kind'],'source':d['path'],'original_path':d['path'],'page':'corpus','score':1.0,'text':d['text'][:320]} for i,d in enumerate(docs)]
        return {'answer':answer,'intent':'universal_corpus_analysis','sources':src,'requires_map':False,'execution_status':'success',
                'coverage':{'processed':unit_total,'total':unit_total,'readable_files':len(docs),'total_files':total_files,'failed_files':len(failures),'failed_segments':0,'percent':100,'segments':unit_total,'mode':'exhaustive_segmented_map_reduce'},'failures':failures[:50]}
