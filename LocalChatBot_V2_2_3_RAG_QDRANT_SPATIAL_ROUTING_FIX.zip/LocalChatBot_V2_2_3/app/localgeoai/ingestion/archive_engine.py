from pathlib import Path
import zipfile,tarfile,gzip,bz2,lzma,shutil
MAX_FILES=5000; MAX_TOTAL=2*1024*1024*1024

def _safe(base,name):
 p=(base/name).resolve()
 if base.resolve() not in p.parents:return None
 return p

def extract(path,outdir):
 p=Path(path);out=Path(outdir);out.mkdir(parents=True,exist_ok=True);e=p.suffix.lower();rows=[];total=0
 if e=='.zip':
  with zipfile.ZipFile(p) as z:
   for i in z.infolist()[:MAX_FILES]:
    if i.is_dir():continue
    total+=i.file_size
    if total>MAX_TOTAL:raise RuntimeError('Archive extraction limit exceeded')
    q=_safe(out,Path(i.filename));
    if q is None:continue
    q.parent.mkdir(parents=True,exist_ok=True)
    with z.open(i) as a,open(q,'wb') as b:shutil.copyfileobj(a,b)
    rows.append(q)
 elif e in {'.tar','.tgz'} or p.name.lower().endswith('.tar.gz'):
  with tarfile.open(p) as t:
   for i in t.getmembers()[:MAX_FILES]:
    if not i.isfile() or i.size+total>MAX_TOTAL:continue
    q=_safe(out,Path(i.name));
    if q is None:continue
    q.parent.mkdir(parents=True,exist_ok=True);src=t.extractfile(i)
    if src:
     with src,open(q,'wb') as b:shutil.copyfileobj(src,b);rows.append(q);total+=i.size
 elif e=='.7z':
  try:import py7zr
  except ImportError as x:raise RuntimeError('7Z needs py7zr') from x
  with py7zr.SevenZipFile(p) as z:z.extractall(out)
  rows=[x for x in out.rglob('*') if x.is_file()][:MAX_FILES]
 elif e in {'.gz','.bz2','.xz'}:
  opener={'.gz':gzip.open,'.bz2':bz2.open,'.xz':lzma.open}[e];q=out/p.stem
  with opener(p,'rb') as a,open(q,'wb') as b:shutil.copyfileobj(a,b)
  rows=[q]
 return rows
