from pathlib import Path
from email import policy
from email.parser import BytesParser
import html,re

def _html_text(s):
    s=re.sub(r"(?is)<(script|style).*?>.*?</\\1>"," ",s or "")
    s=re.sub(r"(?s)<[^>]+>"," ",s); return re.sub(r"\\s+"," ",html.unescape(s)).strip()

def parse_eml(path, attachment_dir=None):
    msg=BytesParser(policy=policy.default).parsebytes(Path(path).read_bytes())
    keys=['subject','from','to','cc','bcc','date','message-id','in-reply-to','references','reply-to']
    meta={k.replace('-','_'):str(msg.get(k,'')) for k in keys}
    plain=[]; htmls=[]; attachments=[]
    parts=list(msg.walk()) if msg.is_multipart() else [msg]
    for part in parts:
        disp=part.get_content_disposition(); fn=part.get_filename(); ctype=part.get_content_type()
        if disp=='attachment' or fn:
            raw=part.get_payload(decode=True) or b''
            item={'filename':fn or 'attachment.bin','content_type':ctype,'size':len(raw)}
            if attachment_dir and raw:
                d=Path(attachment_dir); d.mkdir(parents=True,exist_ok=True)
                safe=Path(item['filename']).name; out=d/safe; out.write_bytes(raw); item['path']=str(out)
            attachments.append(item); continue
        try: content=part.get_content()
        except Exception: continue
        if ctype=='text/plain': plain.append(str(content))
        elif ctype=='text/html': htmls.append(_html_text(str(content)))
    body='\n'.join(x for x in plain if x.strip()).strip() or '\n'.join(x for x in htmls if x.strip()).strip()
    meta['attachments']=attachments
    return meta,body

def parse_msg(path, attachment_dir=None):
    try: import extract_msg
    except ImportError as e: raise RuntimeError('MSG parser needs extract-msg. Run 00_INSTALL_UNIVERSAL_DEPS.bat.') from e
    m=extract_msg.Message(str(path)); m.process()
    meta={'subject':m.subject or '', 'from':m.sender or '', 'to':m.to or '', 'cc':m.cc or '', 'bcc':'',
          'date':str(m.date or ''),'message_id':'','in_reply_to':'','references':'','reply_to':'','attachments':[]}
    if attachment_dir:
        d=Path(attachment_dir); d.mkdir(parents=True,exist_ok=True)
        for a in m.attachments:
            try:
                name=getattr(a,'longFilename',None) or getattr(a,'shortFilename',None) or 'attachment.bin'
                a.save(customPath=str(d),customFilename=Path(name).name)
                q=d/Path(name).name; meta['attachments'].append({'filename':Path(name).name,'path':str(q),'size':q.stat().st_size if q.exists() else 0})
            except Exception: pass
    return meta,m.body or ''

def parse_email(path,attachment_dir=None):
    e=Path(path).suffix.lower()
    if e=='.eml': return parse_eml(path,attachment_dir)
    if e=='.msg': return parse_msg(path,attachment_dir)
    raise ValueError('Unsupported email container: '+e)
