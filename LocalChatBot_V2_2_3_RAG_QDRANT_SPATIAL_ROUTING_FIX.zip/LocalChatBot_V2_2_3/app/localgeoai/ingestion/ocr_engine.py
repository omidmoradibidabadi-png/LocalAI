from __future__ import annotations
from pathlib import Path
import os, shutil, subprocess, time

ROOT=Path(__file__).resolve().parents[3]
PREFERRED_LANGS=('fas','eng','ara','heb','chi_sim','chi_tra')
_STATUS_CACHE=None
_STATUS_CACHE_AT=0.0

def _runtime_dir(): return ROOT/'runtime/ocr'

def _bootstrap_windows_runtime():
    """If Tesseract is installed per-user/system-wide, make LocalGeoAI self-contained by copying its runtime once."""
    if os.name!='nt': return None
    dst=_runtime_dir(); local=dst/'tesseract.exe'
    if local.exists(): return local
    candidates=[]
    la=os.environ.get('LOCALAPPDATA'); pf=os.environ.get('ProgramFiles'); pfx=os.environ.get('ProgramFiles(x86)')
    if la: candidates.append(Path(la)/'Tesseract-OCR')
    if pf: candidates.append(Path(pf)/'Tesseract-OCR')
    if pfx: candidates.append(Path(pfx)/'Tesseract-OCR')
    found=shutil.which('tesseract')
    if found: candidates.append(Path(found).parent)
    for src in candidates:
        exe=src/'tesseract.exe'
        if not exe.exists(): continue
        dst.mkdir(parents=True,exist_ok=True)
        # Keep LocalGeoAI's own tessdata; import executable + runtime DLLs/tools only.
        for p in src.iterdir():
            if p.name.casefold()=='tessdata' or not p.is_file(): continue
            try: shutil.copy2(p,dst/p.name)
            except Exception: pass
        if local.exists(): return local
    return None

def _tesseract_exe():
    candidates=[ROOT/'runtime/ocr/tesseract.exe', ROOT/'runtime/tesseract/tesseract.exe']
    for p in candidates:
        if p.exists(): return p
    boot=_bootstrap_windows_runtime()
    if boot and boot.exists(): return boot
    w=shutil.which('tesseract')
    return Path(w) if w else None

def _local_tessdata():
    p=ROOT/'runtime/ocr/tessdata'
    return p if p.exists() else None

def status(force=False):
    global _STATUS_CACHE,_STATUS_CACHE_AT
    if not force and _STATUS_CACHE and time.time()-_STATUS_CACHE_AT<60: return dict(_STATUS_CACHE)
    exe=_tesseract_exe(); langs=[]; err=''
    if exe:
        try:
            flags=getattr(subprocess,'CREATE_NO_WINDOW',0); env=dict(os.environ); td=_local_tessdata()
            if td: env['TESSDATA_PREFIX']=str(td)
            r=subprocess.run([str(exe),'--list-langs'],capture_output=True,text=True,timeout=30,creationflags=flags,env=env)
            langs=[x.strip() for x in (r.stdout or '').splitlines()[1:] if x.strip()]
            if r.returncode: err=(r.stderr or '').strip()
        except Exception as e: err=str(e)
    local_models=[p.stem for p in (_local_tessdata() or Path('.')).glob('*.traineddata')] if _local_tessdata() else []
    effective=langs or local_models; required={x:(x in effective) for x in PREFERRED_LANGS}
    out={'ready':bool(exe) and all(required.values()),'engine_ready':bool(exe),'engine':'tesseract-local' if exe else 'unavailable',
         'executable':str(exe or ''),'languages':effective,'required_languages':required,'multilingual_ready':all(required.values()),
         'tessdata':str(_local_tessdata() or ''),'error':err}
    _STATUS_CACHE=dict(out); _STATUS_CACHE_AT=time.time(); return out

def _setup_pytesseract():
    try: import pytesseract
    except ImportError as e: raise RuntimeError('pytesseract is not installed in the local Python runtime.') from e
    exe=_tesseract_exe()
    if not exe: raise RuntimeError('Local OCR engine is not available: runtime\\ocr\\tesseract.exe was not found.')
    pytesseract.pytesseract.tesseract_cmd=str(exe); td=_local_tessdata()
    if td: os.environ['TESSDATA_PREFIX']=str(td)
    return pytesseract

def _detect_script(pt,image):
    try:
        d=pt.image_to_osd(image,config='--psm 0',timeout=20,output_type=pt.Output.DICT)
        return str(d.get('script') or '').strip()
    except Exception: return ''

def _language_plan(script,available):
    s=script.casefold(); a=set(available)
    if 'arabic' in s: pref=('fas','ara','eng')
    elif 'hebrew' in s: pref=('heb','eng')
    elif any(x in s for x in ('han','chinese','han_s','han_t')): pref=('chi_sim','chi_tra','eng')
    elif 'latin' in s: pref=('eng',)
    else: pref=('fas','eng','ara')
    chosen=[x for x in pref if x in a]
    if not chosen: chosen=[x for x in PREFERRED_LANGS if x in a][:3]
    return '+'.join(chosen) if chosen else None

def _resize_for_ocr(image,max_side=3200):
    try:
        w,h=image.size; m=max(w,h)
        if m<=max_side:return image
        scale=max_side/float(m)
        return image.resize((max(1,int(w*scale)),max(1,int(h*scale))))
    except Exception:return image

def image_to_text(image, languages=None):
    pt=_setup_pytesseract(); st=status(); available=set(st.get('languages') or [])
    work=_resize_for_ocr(image); script='manual' if languages else _detect_script(pt,work)
    lang=(str(languages or '').strip() or None) if languages is not None else _language_plan(script,available)
    try:
        kwargs={'output_type':pt.Output.DICT,'config':'--oem 1 --psm 3','timeout':180}
        if lang: kwargs['lang']=lang
        started=time.time(); data=pt.image_to_data(work,**kwargs)
        words=[]; conf=[]
        for t,c in zip(data.get('text',[]),data.get('conf',[])):
            t=str(t or '').strip()
            if not t: continue
            words.append(t)
            try:
                v=float(c)
                if v>=0: conf.append(v)
            except Exception: pass
        text=' '.join(words).strip()
        return {'text':text,'confidence':(sum(conf)/len(conf) if conf else None),'language':lang or 'default',
                'languages_used':(lang.split('+') if lang else []),'characters':len(text),'detected_script':script or 'unknown',
                'elapsed_seconds':round(time.time()-started,2),'resized_for_ocr':getattr(work,'size',None)!=getattr(image,'size',None)}
    except RuntimeError as e:
        if 'timeout' in str(e).casefold(): raise RuntimeError(f'Local OCR timed out after 180 seconds (script={script or "unknown"}, languages={lang or "default"}).') from e
        raise RuntimeError('Local OCR failed: '+str(e)) from e
    except Exception as e: raise RuntimeError('Local OCR failed: '+str(e)) from e
