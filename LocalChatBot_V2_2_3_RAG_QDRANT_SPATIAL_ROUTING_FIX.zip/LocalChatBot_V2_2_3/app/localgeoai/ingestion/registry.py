from pathlib import Path

DOCUMENT={'.pdf','.pdfa','.doc','.docx','.docm','.dotx','.rtf','.txt','.md','.markdown','.html','.htm','.xhtml','.xml','.odt','.ott','.epub','.tex','.log','.ini','.cfg'}
PRESENTATION={'.ppt','.pptx','.pptm','.pps','.ppsx','.odp'}
STRUCTURED={'.csv','.tsv','.json','.jsonl','.ndjson','.xlsx','.xlsm','.xls','.xlsb','.ods','.parquet','.feather','.arrow','.yaml','.yml','.toml','.dbf','.sqlite','.sqlite3','.db'}
EMAIL={'.eml','.msg','.mbox','.pst','.ost'}
VECTOR={'.geojson','.topojson','.shp','.gpkg','.kml','.kmz','.gpx','.fgb','.gml','.tab','.mif','.mid','.dxf','.sqlite','.db','.csv'}
IMAGE={'.png','.jpg','.jpeg','.jfif','.bmp','.gif','.webp','.heic','.heif','.avif','.jxl','.ico','.pcx','.tga','.psd','.psb','.svg','.dng','.cr2','.cr3','.nef','.arw','.orf','.rw2','.raf','.pef'}
ARCHIVE={'.zip','.7z','.tar','.tgz','.gz','.bz2','.xz'}
AUDIO={'.mp3','.wav','.flac','.m4a','.aac','.ogg','.opus','.wma','.aiff','.aif'}
VIDEO={'.mp4','.mkv','.mov','.avi','.webm','.mpeg','.mpg','.m4v','.wmv','.ts','.mts','.m2ts'}
DATABASE={'.mdb','.accdb','.sqlite','.sqlite3','.db'}

# Order matters for ambiguous extensions. CSV/SQLite are structured-first.
def classify(path):
    p=Path(path); e=p.suffix.lower()
    if e in EMAIL:return 'email'
    if e in ARCHIVE:return 'archive'
    if e in PRESENTATION:return 'presentation'
    if e in VECTOR and e not in {'.csv','.sqlite','.sqlite3','.db'}:return 'spatial'
    if e in STRUCTURED:return 'structured'
    if e in DOCUMENT:return 'document'
    if e in IMAGE:return 'image'
    if e in AUDIO:return 'audio'
    if e in VIDEO:return 'video'
    if e in DATABASE:return 'database'
    return 'unsupported'

def supported():
    return sorted(DOCUMENT|PRESENTATION|STRUCTURED|EMAIL|VECTOR|IMAGE|ARCHIVE|AUDIO|VIDEO|DATABASE)

def capabilities():
    import importlib.util
    def has(x): return importlib.util.find_spec(x) is not None
    return {
      'pdf':has('fitz'),'docx':has('docx'),'xlsx':has('openpyxl'),'pptx':has('pptx'),'odf':has('odf'),
      'eml':True,'msg':has('extract_msg'),'mbox':True,'pst':False,'archive_zip':True,'archive_7z':has('py7zr'),
      'image_metadata':has('PIL'),'ocr_bridge':has('pytesseract'),
      'gis_vector':has('pyogrio') or has('geopandas'),'numpy':has('numpy'),'pandas':has('pandas'),
      'parquet':has('pyarrow'),'hdf5':has('h5py'),'netcdf':has('netCDF4') or has('xarray'),
      'audio_video_metadata':False
    }
