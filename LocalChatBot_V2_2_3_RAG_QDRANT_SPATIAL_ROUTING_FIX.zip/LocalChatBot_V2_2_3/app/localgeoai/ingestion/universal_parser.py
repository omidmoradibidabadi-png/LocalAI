from __future__ import annotations
from pathlib import Path
import csv,json,re,zipfile,html,xml.etree.ElementTree as ET, subprocess, tempfile, os
from .registry import classify

def _clean(s): return re.sub(r'\s+',' ',str(s or '')).strip()

def _html(s):
    try:
        from bs4 import BeautifulSoup
        return BeautifulSoup(s,'html.parser').get_text('\n')
    except Exception:
        return re.sub(r'(?s)<[^>]+>',' ',html.unescape(s))

def parse_text(path): return [(1,Path(path).read_text(encoding='utf-8',errors='replace'))]

def parse_pdf(path, ocr_mode="off"):
    try: import fitz
    except ImportError as e: raise RuntimeError('PDF parser unavailable: install PyMuPDF with 00_INSTALL_UNIVERSAL_DEPS.bat') from e
    out=[]
    mode=str(ocr_mode or "off").lower()
    with fitz.open(path) as d:
        for i,p in enumerate(d):
            native=p.get_text('text').strip()
            need=(mode=="force") or (mode=="auto" and len(native)<40)
            ocr_text=""
            if need:
                try:
                    from PIL import Image
                    from .ocr_engine import image_to_text
                    pix=p.get_pixmap(matrix=fitz.Matrix(2.0,2.0),alpha=False)
                    im=Image.frombytes("RGB",[pix.width,pix.height],pix.samples)
                    r=image_to_text(im); ocr_text=str(r.get("text") or "").strip()
                except Exception:
                    if mode=="force": raise
            text=ocr_text if (mode=="force" and ocr_text) else (native + (("\n[OCR]\n"+ocr_text) if ocr_text and ocr_text not in native else ""))
            if text.strip(): out.append((i+1,text.strip()))
    return out

def parse_docx(path, ocr_mode="off"):
    try:
        from docx import Document
        d=Document(path); t='\n'.join(p.text for p in d.paragraphs if p.text.strip())
        for table in d.tables:
            for row in table.rows: t+='\n'+' | '.join(c.text for c in row.cells)
        mode=str(ocr_mode or 'off').lower(); ocr=[]
        if mode in {'auto','force'}:
            # DOCX is a ZIP package; OCR embedded raster images locally and append provenance.
            try:
                from PIL import Image
                from .ocr_engine import image_to_text
                with zipfile.ZipFile(path) as z:
                    for name in z.namelist():
                        if not name.startswith('word/media/') or Path(name).suffix.lower() not in {'.png','.jpg','.jpeg','.bmp','.tif','.tiff','.webp'}: continue
                        try:
                            import io
                            im=Image.open(io.BytesIO(z.read(name))).convert('RGB'); r=image_to_text(im); txt=str(r.get('text') or '').strip()
                            if txt: ocr.append(f'[OCR embedded image: {Path(name).name}; confidence={r.get("confidence")}]\n{txt}')
                        except Exception: pass
            except Exception:
                if mode=='force': raise
        if ocr: t += '\n\n'+'\n\n'.join(ocr)
        return [(1,t)]
    except ImportError:
        with zipfile.ZipFile(path) as z: x=z.read('word/document.xml')
        root=ET.fromstring(x); ns='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
        return [(1,'\n'.join(''.join((n.text or '') for n in p.iter(ns+'t')) for p in root.iter(ns+'p')))]

def parse_doc(path):
    """Legacy .doc support through locally installed Microsoft Word COM; no cloud conversion."""
    if os.name!='nt': raise RuntimeError('Legacy .doc requires Microsoft Word conversion on Windows in this build.')
    out=Path(tempfile.gettempdir())/('localgeoai_'+Path(path).stem+'_'+str(os.getpid())+'.txt')
    ps=("$w=New-Object -ComObject Word.Application; $w.Visible=$false; "
        "$d=$w.Documents.Open($env:DOC_IN,$false,$true); $d.SaveAs([ref]$env:DOC_OUT,[ref]2); "
        "$d.Close(); $w.Quit()")
    env=dict(os.environ);env['DOC_IN']=str(Path(path).resolve());env['DOC_OUT']=str(out)
    r=subprocess.run(['powershell.exe','-NoProfile','-STA','-Command',ps],capture_output=True,text=True,env=env,timeout=90)
    if r.returncode!=0 or not out.exists(): raise RuntimeError('Legacy .doc conversion failed. Microsoft Word is required. '+(r.stderr.strip() or ''))
    try:return [(1,out.read_text(encoding='utf-8',errors='replace'))]
    finally:
        try:out.unlink()
        except Exception:pass

def parse_pptx(path):
    try: from pptx import Presentation
    except ImportError as e: raise RuntimeError('PowerPoint parser unavailable: install python-pptx') from e
    out=[]
    for i,s in enumerate(Presentation(path).slides,1):
        txt=[]
        for sh in s.shapes:
            if hasattr(sh,'text') and sh.text.strip(): txt.append(sh.text)
        if txt: out.append((i,'\n'.join(txt)))
    return out

def parse_xlsx(path):
    try: from openpyxl import load_workbook
    except ImportError as e: raise RuntimeError('Excel parser unavailable: install openpyxl') from e
    out=[]; n=0
    wb=load_workbook(path,read_only=True,data_only=True)
    for ws in wb.worksheets:
        for row in ws.iter_rows(values_only=True):
            vals=[str(v) for v in row if v not in (None,'')]
            if vals:n+=1;out.append((n,f'Sheet={ws.title} | '+' | '.join(vals)))
    return out

def parse_delimited(path,delimiter=None):
    e=Path(path).suffix.lower(); delimiter=delimiter or ('\t' if e=='.tsv' else ',')
    out=[]
    with open(path,'r',encoding='utf-8-sig',errors='replace',newline='') as f:
        for i,row in enumerate(csv.reader(f,delimiter=delimiter),1):
            if row:out.append((i,' | '.join(row)))
    return out

def parse_json(path):
    out=[]
    if Path(path).suffix.lower() in {'.jsonl','.ndjson'}:
        for i,l in enumerate(Path(path).read_text(encoding='utf-8-sig',errors='replace').splitlines(),1):
            if l.strip(): out.append((i,l))
        return out
    obj=json.loads(Path(path).read_text(encoding='utf-8-sig',errors='replace'))
    seq=obj if isinstance(obj,list) else [obj]
    return [(i,json.dumps(x,ensure_ascii=False,default=str)) for i,x in enumerate(seq,1)]

def parse_email(path):
    from .email_parser import parse_email
    meta,body=parse_email(path)
    h='\n'.join(f'{k}: {v}' for k,v in meta.items() if k!='attachments')
    return [(1,h+'\n\n'+body)]

def parse_image(path, ocr_mode="off"):
    try:
        from PIL import Image,ExifTags
        with Image.open(path) as im:
            ex={ExifTags.TAGS.get(k,str(k)):str(v) for k,v in im.getexif().items()}
            txt=f'Image {Path(path).name}; width={im.width}; height={im.height}; format={im.format}; mode={im.mode}; EXIF={json.dumps(ex,ensure_ascii=False)}'
            mode=str(ocr_mode or "off").lower()
            if mode in {"auto","force"}:
                from .ocr_engine import image_to_text
                r=image_to_text(im.convert("RGB")); o=str(r.get("text") or "").strip()
                if o: txt+=f'\n[OCR confidence={r.get("confidence")}]\n'+o
                elif mode=="force": txt+='\n[OCR: no text detected]'
            return [(1,txt)]
    except Exception as e: raise RuntimeError('Image parser failed: '+str(e))

def parse_tabular_advanced(path):
    e=Path(path).suffix.lower()
    try: import pandas as pd
    except ImportError as x: raise RuntimeError('Advanced tabular parser needs pandas') from x
    if e=='.parquet': df=pd.read_parquet(path)
    elif e in {'.feather','.arrow'}: df=pd.read_feather(path)
    elif e in {'.xls','.xlsb','.ods'}: df=pd.read_excel(path)
    else: raise ValueError('Unsupported advanced table '+e)
    return [(i+1,' | '.join(f'{k}: {v}' for k,v in r.items() if str(v)!='nan')) for i,r in df.head(200000).iterrows()]

def parse(path, ocr_mode="off"):
    p=Path(path);e=p.suffix.lower();k=classify(p)
    if e=='.pdf':return parse_pdf(p,ocr_mode)
    if e in {'.txt','.md','.markdown','.log','.ini','.cfg','.tex'}:return parse_text(p)
    if e in {'.html','.htm','.xhtml'}:return [(1,_html(p.read_text(encoding='utf-8',errors='replace')))]
    if e=='.docx':return parse_docx(p,ocr_mode)
    if e=='.doc':return parse_doc(p)
    if e in {'.pptx','.pptm','.ppsx'}:return parse_pptx(p)
    if e in {'.csv','.tsv'}:return parse_delimited(p)
    if e in {'.json','.jsonl','.ndjson'}:return parse_json(p)
    if e in {'.xlsx','.xlsm'}:return parse_xlsx(p)
    if e in {'.xls','.xlsb','.ods','.parquet','.feather','.arrow'}:return parse_tabular_advanced(p)
    if k=='email' and e in {'.eml','.msg'}:return parse_email(p)
    if k=='image':return parse_image(p,ocr_mode)
    raise RuntimeError(f'No text parser ready for {e}; file can still be cataloged by its specialist engine.')
