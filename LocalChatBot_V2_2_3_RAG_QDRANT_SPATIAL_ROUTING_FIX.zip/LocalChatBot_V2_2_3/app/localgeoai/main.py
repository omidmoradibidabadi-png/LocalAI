from __future__ import annotations
import argparse, hashlib, json, os, re, subprocess, sys, time, urllib.request, urllib.error, uuid, socket
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from app.localgeoai.data_paths import DATA_ROOT

ROOT = Path(__file__).resolve().parents[2]
CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
LOGS = ROOT / "logs"
LOGS.mkdir(exist_ok=True)

def url(host: str, port: int, path: str) -> str:
    return f"http://{host}:{port}{path}"

def http_json(method: str, target: str, payload: Any | None = None, timeout: int = 120):
    data = None if payload is None else json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(target, data=data, method=method)
    if data is not None:
        req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        body = r.read()
        return json.loads(body.decode("utf-8")) if body else None

def wait_http(target: str, seconds: int) -> bool:
    end = time.time() + seconds
    while time.time() < end:
        try:
            with urllib.request.urlopen(target, timeout=2) as r:
                if r.status < 500:
                    return True
        except Exception:
            time.sleep(1)
    return False

@dataclass
class ManagedProcess:
    name: str
    proc: subprocess.Popen | None = None
    started_here: bool = False

class RuntimeManager:
    def __init__(self):
        self.items: list[ManagedProcess] = []

    def _alive(self, health: str) -> bool:
        return wait_http(health, 1)

    def _start(self, name: str, exe: Path, args: list[str], health: str, timeout: int = 120):
        if self._alive(health):
            print(f"[OK] {name} already running.")
            self.items.append(ManagedProcess(name, None, False))
            return
        out = open(LOGS / f"{name}.out.log", "ab")
        err = open(LOGS / f"{name}.err.log", "ab")
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        p = subprocess.Popen([str(exe), *args], cwd=str(exe.parent),
                             stdout=out, stderr=err, creationflags=flags)
        if not wait_http(health, timeout):
            raise RuntimeError(f"{name} failed to start. See logs/{name}.err.log")
        self.items.append(ManagedProcess(name, p, True))
        print(f"[OK] {name} ready.")

    def _start_elasticsearch(self):
        es_url = CONFIG.get("enterprise_search",{}).get("elasticsearch_url","http://127.0.0.1:9200")
        if self._alive(es_url):
            self.items.append(ManagedProcess("elasticsearch", None, False))
            print("[OK] Elasticsearch already running.")
            return
        es_home = ROOT / "runtime" / "elasticsearch"
        es_bat = es_home / "bin" / "elasticsearch.bat"
        java = es_home / "jdk" / "bin" / "java.exe"
        if not es_bat.is_file():
            raise FileNotFoundError(f"Portable Elasticsearch missing: {es_bat}")
        if not java.is_file():
            raise FileNotFoundError(f"Bundled Elasticsearch JDK missing: {java}")
        data_dir = DATA_ROOT / "elasticsearch" / "data"
        logs_dir = DATA_ROOT / "elasticsearch" / "logs"
        data_dir.mkdir(parents=True, exist_ok=True); logs_dir.mkdir(parents=True, exist_ok=True)
        env=os.environ.copy()
        # Force the bundled JDK so the offline PC never depends on JAVA_HOME/PATH.
        env["ES_JAVA_HOME"] = str(es_home / "jdk")
        env.pop("JAVA_HOME", None)
        out=open(LOGS/"elasticsearch.out.log","ab"); err=open(LOGS/"elasticsearch.err.log","ab")
        flags=getattr(subprocess,"CREATE_NO_WINDOW",0)
        args=["cmd.exe","/d","/s","/c",str(es_bat),
              "-Ediscovery.type=single-node", "-Expack.security.enabled=false",
              "-Enetwork.host=127.0.0.1", "-Ehttp.port=9200",
              f"-Epath.data={data_dir}", f"-Epath.logs={logs_dir}"]
        p=subprocess.Popen(args,cwd=str(es_home),env=env,stdout=out,stderr=err,creationflags=flags)
        if not wait_http(es_url,120):
            try: p.terminate()
            except Exception: pass
            raise RuntimeError("Elasticsearch failed to start. See logs/elasticsearch.err.log and logs/elasticsearch.out.log")
        self.items.append(ManagedProcess("elasticsearch",p,True))
        print("[OK] Elasticsearch ready.")

    def start_all(self):
        s = CONFIG["services"]
        self._start_elasticsearch()
        qexe = ROOT/"runtime/qdrant/qdrant.exe"
        lex = ROOT/"runtime/llama/llama-server.exe"
        llm = ROOT/CONFIG["models"]["generation"]
        from app.localgeoai.model_paths import resolve_embedding_model
        emb = resolve_embedding_model(ROOT, CONFIG["models"].get("embedding"))
        for f in (qexe, lex, llm, emb):
            if not f.exists():
                raise FileNotFoundError(f"Required file missing: {f}")

        q = s["qdrant"]
        # Keep Qdrant storage inside project.
        qenv = os.environ.copy()
        qenv["QDRANT__STORAGE__STORAGE_PATH"] = str(DATA_ROOT/"qdrant")
        if not self._alive(url(q["host"], q["port"], "/readyz")):
            out=open(LOGS/"qdrant.out.log","ab"); err=open(LOGS/"qdrant.err.log","ab")
            flags=getattr(subprocess,"CREATE_NO_WINDOW",0)
            p=subprocess.Popen([str(qexe)], cwd=str(qexe.parent), env=qenv,
                               stdout=out, stderr=err, creationflags=flags)
            if not wait_http(url(q["host"], q["port"], "/readyz"), 30):
                raise RuntimeError("Qdrant failed. See logs/qdrant.err.log")
            self.items.append(ManagedProcess("qdrant", p, True))
            print("[OK] Qdrant ready.")
        else:
            self.items.append(ManagedProcess("qdrant", None, False))
            print("[OK] Qdrant already running.")

        from app.localgeoai.runtime_hardware import detect_hardware,write_snapshot
        rtcfg=CONFIG.get('runtime',{}); hw=detect_hardware(llm,rtcfg.get('gpu_profile','auto'),int(rtcfg.get('vram_reserve_mb',650))); write_snapshot(ROOT,hw); self.hardware=hw
        g=s["generation"]; gl=hw.get("generation_gpu_layers",g.get("gpu_layers",0)) if hw.get("cuda") else 0
        self._start("generation", lex,
                    ["-m",str(llm),"--host",g["host"],"--port",str(g["port"]),
                     "-ngl",str(gl),"-c",str(g["context"]),
                     "--threads",str(CONFIG.get("runtime",{}).get("cpu_threads",4)),
                     "--threads-batch",str(CONFIG.get("runtime",{}).get("cpu_threads_batch",4)),
                     "--batch-size",str(CONFIG.get("runtime",{}).get("batch_size",256)),
                     "--ubatch-size",str(CONFIG.get("runtime",{}).get("ubatch_size",128)),
                     "--reasoning","off","--reasoning-budget","0","--reasoning-format","none"],
                    url(g["host"],g["port"],"/health"), 180)

        e=s["embedding"]; el=hw.get("embedding_gpu_layers",e.get("gpu_layers",0)) if hw.get("cuda") else 0
        self._start("embedding", lex,
                    ["-m",str(emb),"--embedding","--host",e["host"],"--port",str(e["port"]),
                     "-ngl",str(el)],
                    url(e["host"],e["port"],"/health"), 180)
        print(f"[HW] {hw.get('gpu') or 'CPU'} | VRAM {hw.get('vram_total_mb',0)} MB | LLM ngl={gl} | EMB ngl={el} | {hw.get('policy')}")

    def _pid_listening_on_port(self, port: int):
        if os.name != "nt": return None
        ps=("$c=Get-NetTCPConnection -State Listen -LocalPort %d -ErrorAction SilentlyContinue | "
            "Select-Object -First 1 -ExpandProperty OwningProcess; if($c){$c}") % port
        try:
            r=subprocess.run(["powershell.exe","-NoProfile","-Command",ps],capture_output=True,text=True,timeout=8,
                             creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
            v=(r.stdout or "").strip().splitlines()
            return int(v[-1].strip()) if v and v[-1].strip().isdigit() else None
        except Exception:return None

    def _windows_process_commandline(self, pid: int):
        if os.name != "nt": return ""
        ps=("$p=Get-CimInstance Win32_Process -Filter \"ProcessId=%d\" -ErrorAction SilentlyContinue; "
            "if($p){$p.CommandLine}") % pid
        try:
            r=subprocess.run(["powershell.exe","-NoProfile","-Command",ps],capture_output=True,text=True,timeout=8,
                             creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
            return (r.stdout or "").strip()
        except Exception:return ""

    def _terminate_pid(self, pid: int):
        if os.name != "nt": raise RuntimeError("PID adoption is implemented for the Windows runtime.")
        cmd=self._windows_process_commandline(pid)
        if "llama-server" not in cmd.casefold():
            raise RuntimeError(f"Refusing to terminate unverified PID {pid}.")
        r=subprocess.run(["taskkill","/PID",str(pid),"/T","/F"],capture_output=True,text=True,timeout=15,
                         creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
        if r.returncode not in (0,128): raise RuntimeError(f"Could not stop generation PID {pid}: {(r.stderr or r.stdout).strip()}")

    def switch_generation(self, model_path: Path):
        """Hot-switch only the generation server; embedding service is intentionally untouched."""
        g=CONFIG["services"]["generation"]; health=url(g["host"],g["port"],"/health")
        current=next((x for x in self.items if x.name=="generation"),None)
        if current and current.started_here and current.proc and current.proc.poll() is None:
            current.proc.terminate()
            try: current.proc.wait(timeout=12)
            except Exception: current.proc.kill()
            try:self.items.remove(current)
            except ValueError:pass
        elif self._alive(health):
            # V6.4.8: safely adopt/replace an already-running generation server on 8081.
            # Never kill by image name: embedding also uses llama-server.exe on 8082.
            pid=self._pid_listening_on_port(int(g["port"]))
            if not pid:
                raise RuntimeError(f"Generation server is online on port {g['port']} but its PID could not be resolved safely.")
            cmd=self._windows_process_commandline(pid)
            if "llama-server" not in cmd.casefold():
                raise RuntimeError(f"Port {g['port']} belongs to PID {pid}, but it is not a verified llama-server process. Hot-swap aborted.")
            self._terminate_pid(pid)
            end=time.time()+20
            while time.time()<end and self._alive(health): time.sleep(.5)
            if self._alive(health):
                raise RuntimeError(f"Old generation server PID {pid} did not release port {g['port']}.")
            if current:
                try:self.items.remove(current)
                except ValueError:pass
        lex=ROOT/"runtime/llama/llama-server.exe"
        from app.localgeoai.runtime_hardware import detect_hardware, write_snapshot
        rtcfg=CONFIG.get('runtime',{});hw=detect_hardware(model_path,rtcfg.get('gpu_profile','auto'),int(rtcfg.get('vram_reserve_mb',650)));gl=hw.get("generation_gpu_layers",g.get("gpu_layers",0)) if hw.get("cuda") else 0
        self._start("generation",lex,["-m",str(model_path),"--host",g["host"],"--port",str(g["port"]),"-ngl",str(gl),"-c",str(g["context"]),"--threads",str(CONFIG.get("runtime",{}).get("cpu_threads",4)),"--threads-batch",str(CONFIG.get("runtime",{}).get("cpu_threads_batch",4)),"--batch-size",str(CONFIG.get("runtime",{}).get("batch_size",256)),"--ubatch-size",str(CONFIG.get("runtime",{}).get("ubatch_size",128)),"--reasoning","off","--reasoning-budget","0","--reasoning-format","none"],health,240)
        # Verify the model actually served on 8081; a combobox selection is never treated as activation.
        models=http_json("GET",url(g["host"],g["port"],"/v1/models"),timeout=10) or {}
        ids=[str(x.get("id") or "") for x in models.get("data",[]) if isinstance(x,dict)]
        wanted=model_path.name.casefold()
        if ids and not any(wanted in x.casefold() or str(model_path).casefold() in x.casefold() for x in ids):
            raise RuntimeError(f"LLM verification failed: requested {model_path.name}, server reports {ids}")
        self.hardware=hw; write_snapshot(ROOT,hw)
        return {"model":model_path.name,"gpu_layers_requested":gl,"hardware":hw,"server_models":ids}

    def stop(self):
        for item in reversed(self.items):
            if item.started_here and item.proc and item.proc.poll() is None:
                item.proc.terminate()
                try: item.proc.wait(timeout=8)
                except Exception: item.proc.kill()

class Parser:
    @classmethod
    def parse(cls,path:Path):
        from app.localgeoai.ingestion.universal_parser import parse
        return parse(path)

def chunks(text: str, size: int, overlap: int):
    text=re.sub(r"\s+"," ",text).strip()
    if not text: return
    start=0
    while start < len(text):
        end=min(len(text),start+size)
        if end < len(text):
            cut=max(text.rfind(". ",start,end), text.rfind("؟ ",start,end), text.rfind("\n",start,end))
            if cut > start+size//2: end=cut+1
        yield text[start:end].strip()
        if end>=len(text): break
        start=max(start+1,end-overlap)

class Embeddings:
    def __init__(self):
        e=CONFIG["services"]["embedding"]
        self.endpoint=url(e["host"],e["port"],"/v1/embeddings")
        self.debug_dir=ROOT/"logs"/"embedding_failures"; self.debug_dir.mkdir(parents=True,exist_ok=True)
    def _clean(self,text):
        text=re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]"," ",str(text or ""))
        return re.sub(r"\s+"," ",text).strip()
    def _request(self,text):
        # llama.cpp builds differ. Scalar input without a synthetic model name is the canonical request.
        variants=[{"input":text},{"input":text,"model":"embeddinggemma"},{"input":[text]}]
        last=None
        for payload in variants:
            try:
                r=http_json("POST",self.endpoint,payload,180)
                data=r.get("data") or []
                if data and data[0].get("embedding"): return data[0]["embedding"]
                last=RuntimeError("embedding response contained no vector")
            except Exception as e: last=e
        raise last or RuntimeError("embedding request failed")
    def one(self,text:str)->list[float]:
        text=self._clean(text)
        if not text: raise ValueError("empty text after sanitization")
        # Adaptive split-by-size retry. EmbeddingGemma is tested first with a small safe payload.
        candidates=[]
        for n in (min(len(text),1800),1200,800,400):
            c=text[:n].strip()
            if c and c not in candidates:candidates.append(c)
        last=None
        for candidate in candidates:
            try:return self._request(candidate)
            except Exception as e:last=e
        # Persist the exact failed text and diagnostic metadata for reproducible testing.
        try:
            import time,json,hashlib
            h=hashlib.sha256(text.encode('utf-8','replace')).hexdigest()[:16]
            (self.debug_dir/f"{h}.txt").write_text(text,encoding='utf-8')
            (self.debug_dir/f"{h}.json").write_text(json.dumps({"endpoint":self.endpoint,"chars":len(text),"utf8_bytes":len(text.encode('utf-8')),"error":str(last)},ensure_ascii=False,indent=2),encoding='utf-8')
        except Exception:pass
        raise RuntimeError(f"Embedding failed after adaptive retries: {last}")

class Qdrant:
    def __init__(self):
        q=CONFIG["services"]["qdrant"]
        self.base=url(q["host"],q["port"],"")
        self.collection=q["collection"]

    def ensure(self,dim:int):
        try:
            r=http_json("GET",f"{self.base}/collections/{self.collection}")
            existing=int(r["result"]["config"]["params"]["vectors"]["size"])
            if existing != dim:
                raise RuntimeError(f"Collection dimension {existing} != embedding dimension {dim}.")
        except urllib.error.HTTPError as e:
            if e.code != 404: raise
            http_json("PUT",f"{self.base}/collections/{self.collection}",
                      {"vectors":{"size":dim,"distance":"Cosine"}})

    def upsert(self, points:list[dict]):
        http_json("PUT",f"{self.base}/collections/{self.collection}/points?wait=true",
                  {"points":points}, 180)

    def scroll_path(self,path:str,limit:int=64):
        body={"limit":int(limit),"with_payload":True,"with_vector":False,"filter":{"must":[{"key":"source_path","match":{"value":str(Path(path).resolve())}}]}}
        r=http_json("POST",f"{self.base}/collections/{self.collection}/points/scroll",body,30)
        return (r.get("result") or {}).get("points") or []
    def count_path(self,path:str)->int:
        body={"exact":True,"filter":{"must":[{"key":"source_path","match":{"value":str(Path(path).resolve())}}]}}
        try:
            r=http_json("POST",f"{self.base}/collections/{self.collection}/points/count",body,30)
            return int((r.get("result") or {}).get("count") or 0)
        except Exception:
            # Conservative compatibility fallback for older Qdrant builds.
            return len(self.scroll_path(path,limit=10000))

    def search(self,vector:list[float],limit:int):
        # Qdrant Query API; fallback to legacy search endpoint for older builds.
        body={"query":vector,"limit":limit,"with_payload":True}
        try:
            r=http_json("POST",f"{self.base}/collections/{self.collection}/points/query",body)
            return r["result"]["points"]
        except Exception:
            r=http_json("POST",f"{self.base}/collections/{self.collection}/points/search",
                        {"vector":vector,"limit":limit,"with_payload":True})
            return r["result"]

class RAG:
    def __init__(self):
        self.emb=Embeddings(); self.db=Qdrant()

    def ingest(self,path:Path,progress_cb=None):
        pages=Parser.parse(path)
        return self.ingest_pages(path,pages,progress_cb=progress_cb)

    def ingest_pages(self,path:Path,pages,progress_cb=None):
        path=Path(path)
        sha=hashlib.sha256(path.read_bytes()).hexdigest()
        cfg=CONFIG["rag"]
        # Materialize chunks first so UI progress is real rather than a guessed file-level percentage.
        work=[]
        for page,text in pages:
            for idx,chunk in enumerate(chunks(text,cfg["chunk_chars"],cfg["chunk_overlap"])):
                work.append((page,idx,chunk))
        total=len(work)
        if progress_cb:
            progress_cb(stage="embedding",embedding_total=total,embedding_done=0,qdrant_points=0,embedding_failed=0,heartbeat=True)
        points=[]; first_vec=None; count=0; attempted=0; failed=0; upserted=0
        for page,idx,chunk in work:
            attempted+=1
            try:
                vec=self.emb.one(chunk)
            except Exception as ex:
                failed+=1
                if progress_cb:
                    progress_cb(stage="embedding",embedding_total=total,embedding_done=count,qdrant_points=upserted,embedding_failed=failed,heartbeat=True)
                print(f"[WARN] skipped embedding chunk {page}:{idx} from {path.name}: {ex}",flush=True)
                continue
            first_vec=first_vec or vec
            pid=str(uuid.uuid5(uuid.NAMESPACE_URL,f"{sha}:{page}:{idx}"))
            points.append({"id":pid,"vector":vec,"payload":{
                "source":path.name,"source_path":str(path.resolve()),"page":page,
                "chunk_index":idx,"text":chunk,"sha256":sha
            }})
            count+=1
            if progress_cb:
                progress_cb(stage="embedding",embedding_total=total,embedding_done=count,qdrant_points=upserted,embedding_failed=failed,heartbeat=True)
            if len(points)>=32:
                self.db.ensure(len(first_vec)); self.db.upsert(points); upserted+=len(points); points=[]
                if progress_cb:
                    progress_cb(stage="qdrant_upsert",embedding_total=total,embedding_done=count,qdrant_points=upserted,embedding_failed=failed,heartbeat=True)
        if first_vec is None:
            raise RuntimeError("No embeddable text was found. Check parser/OCR/EmbeddingGemma status.")
        self.db.ensure(len(first_vec))
        if points:
            self.db.upsert(points); upserted+=len(points)
        verified=self.db.count_path(path)
        if verified < count:
            raise RuntimeError(f"Qdrant verification failed for {path.name}: embedded={count}, verified_points={verified}")
        if progress_cb:
            progress_cb(stage="qdrant_verified",embedding_total=total,embedding_done=count,qdrant_points=verified,embedding_failed=failed,heartbeat=True)
        status="FULL" if failed==0 else ("PARTIAL" if count else "FAILED")
        print(f"[{status}] Vector index {path.name}: embedded={count}/{attempted}, qdrant={verified}, failed={failed}.")
        return count

    def indexed_count(self,path:Path)->int:
        return self.db.count_path(str(Path(path).resolve()))

    def retrieve_path(self,path:str,limit:int=64):
        evidence=[]
        try: hits=self.db.scroll_path(path,limit)
        except Exception: hits=[]
        for i,h in enumerate(hits,1):
            p=h.get("payload") or {}; text=str(p.get("text") or "").strip()
            if not text: continue
            evidence.append({"n":len(evidence)+1,"source":p.get("source_path") or p.get("source") or str(path),"original_path":p.get("source_path") or str(path),"page":p.get("page"),"score":1.0,"text":text,"engine":"qdrant-scope"})
        return evidence

    def retrieve(self,question:str,limit=None):
        qv=self.emb.one(question)
        hits=self.db.search(qv,int(limit or CONFIG["rag"]["top_k"]))
        hits=[h for h in hits if float(h.get("score",0))>=CONFIG["rag"]["score_threshold"]]
        evidence=[]
        for i,h in enumerate(hits,1):
            p=h["payload"]
            evidence.append({"n":i,"source":p.get("source_path") or p["source"],"original_path":p.get("source_path"),"page":p.get("page"),
                             "score":float(h.get("score",0)),"text":p["text"]})
        return evidence

    def ask(self,question:str):
        evidence=self.retrieve(question,limit=min(4,int(CONFIG["rag"]["top_k"])))
        if not evidence:
            return "در بانک داده شاهد کافی برای پاسخ پیدا نشد.", []
        # 4096-token llama context: keep evidence safely below the context ceiling.
        kept=[]; used=0; budget=4800
        for e in evidence:
            t=e["text"]
            if used+len(t)>budget:
                t=t[:max(0,budget-used)]
            if not t: break
            x=dict(e); x["text"]=t; kept.append(x); used+=len(t)
            if used>=budget: break
        evidence=kept
        context="\n\n".join(f"[{e['n']}] SOURCE={e['source']} PAGE={e['page']}\n{e['text']}" for e in evidence)
        prompt=f"""You are the evidence-grounded assistant of a LOCAL knowledge system.
Answer in Persian. Use ONLY supplied local evidence. Never invent missing values.
For factual claims cite [1], [2], etc.
QUESTION:
{question}
LOCAL EVIDENCE:
{context}"""
        g=CONFIG["services"]["generation"]
        payload={"model":"local-gemma","messages":[{"role":"user","content":prompt}],
                 "temperature":0.05,"max_tokens":min(640,int(CONFIG["rag"]["answer_max_tokens"])),"reasoning_format":"none","reasoning_effort":"none","chat_template_kwargs":{"enable_thinking":False}}
        try:
            r=http_json("POST",url(g["host"],g["port"],"/v1/chat/completions"),payload,180)
        except Exception as e:
            if "400" not in str(e): raise
            # Conservative retry for llama.cpp context-limit 400 responses.
            context=context[:4200]
            payload["messages"][0]["content"]=f"Answer in Persian using only this local evidence. Cite [n].\nQUESTION:{question}\nEVIDENCE:\n{context}"
            payload["max_tokens"]=384
            r=http_json("POST",url(g["host"],g["port"],"/v1/chat/completions"),payload,180)
        return r["choices"][0]["message"]["content"], evidence

def main():
    ap=argparse.ArgumentParser()
    sp=ap.add_subparsers(dest="cmd",required=True)
    p=sp.add_parser("ingest"); p.add_argument("file")
    p=sp.add_parser("ask"); p.add_argument("question",nargs="+")
    sp.add_parser("shell")
    args=ap.parse_args()

    rt=RuntimeManager()
    try:
        rt.start_all()
        rag=RAG()
        if args.cmd=="ingest":
            rag.ingest(Path(args.file))
        elif args.cmd=="ask":
            ans,ev=rag.ask(" ".join(args.question))
            print("\nANSWER\n------\n"+ans)
            print("\nSOURCES\n-------")
            for e in ev:
                print(f"[{e['n']}] {e['source']} | page {e['page']} | score {e['score']:.3f}")
        else:
            print("\nLocalGeoAI interactive RAG. Commands: /add PATH, /quit")
            while True:
                q=input("\nسؤال> ").strip()
                if not q: continue
                if q=="/quit": break
                if q.startswith("/add "):
                    rag.ingest(Path(q[5:].strip().strip('"')))
                    continue
                ans,ev=rag.ask(q)
                print("\n"+ans)
                for e in ev:
                    print(f"  [{e['n']}] {e['source']} | page {e['page']} | {e['score']:.3f}")
    finally:
        rt.stop()

if __name__=="__main__":
    main()


def general_chat(question:str,max_tokens:int=600):
    g=CONFIG["services"]["generation"]
    payload={"model":"local-gemma","messages":[{"role":"system","content":"You are LocalGeoAI. Answer the user in Persian clearly and concisely. If the user asks about local indexed evidence, say that local retrieval is needed rather than inventing it."},{"role":"user","content":question}],"temperature":0.2,"max_tokens":max_tokens,"reasoning_format":"none","reasoning_effort":"none","chat_template_kwargs":{"enable_thinking":False}}
    r=http_json("POST",url(g["host"],g["port"],"/v1/chat/completions"),payload,180)
    return r["choices"][0]["message"]["content"]
