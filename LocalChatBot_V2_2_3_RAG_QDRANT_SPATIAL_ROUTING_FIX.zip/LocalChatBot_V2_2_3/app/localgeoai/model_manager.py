from __future__ import annotations
from pathlib import Path
import json, threading, urllib.request

class ModelManager:
    """Discovers local GGUF LLMs and reports the model actually served by llama-server."""
    def __init__(self,root,runtime,config):
        self.root=Path(root); self.runtime=runtime; self.config=config; self.lock=threading.RLock()
    def _served_ids(self):
        g=self.config['services']['generation']; u=f"http://{g['host']}:{g['port']}/v1/models"
        try:
            with urllib.request.urlopen(u,timeout=2) as r:
                obj=json.loads(r.read().decode('utf-8'))
            return [str(x.get('id') or '') for x in obj.get('data',[]) if isinstance(x,dict)]
        except Exception:return []
    def models(self):
        base=self.root/'models/llm'; base.mkdir(parents=True,exist_ok=True)
        configured=(self.root/self.config['models']['generation']).resolve(); ids=self._served_ids()
        out=[]
        for p in sorted(base.glob('*.gguf'),key=lambda x:x.name.casefold()):
            served=any(p.name.casefold() in x.casefold() or str(p.resolve()).casefold() in x.casefold() for x in ids)
            out.append({'name':p.name,'path':str(p.resolve()),'active':served,'configured':str(p.resolve()).casefold()==str(configured).casefold(),'size_bytes':p.stat().st_size})
        return out
    def status(self):
        ids=self._served_ids()
        active=""
        for m in self.models():
            if m.get('active'): active=m['name']; break
        item=next((x for x in getattr(self.runtime,'items',[]) if x.name=='generation'),None)
        pid=(item.proc.pid if item and item.proc and item.proc.poll() is None else None)
        hw=getattr(self.runtime,'hardware',{}) or {}
        return {'verified':bool(active and ids),'active_model':active,'server_models':ids,'pid':pid,'port':self.config['services']['generation']['port'],
                'cuda_detected':bool(hw.get('cuda')),'cuda_device':hw.get('gpu',''),'gpu_layers_requested':hw.get('generation_gpu_layers',0),
                'vram_total_mb':hw.get('vram_total_mb',0),'vram_used_mb':hw.get('vram_used_mb',0)}
    def switch(self,path_or_name):
        with self.lock:
            p=Path(str(path_or_name))
            if not p.is_absolute():p=self.root/'models/llm'/p.name
            p=p.resolve(); allowed=(self.root/'models/llm').resolve()
            if allowed not in p.parents or not p.exists() or p.suffix.lower()!='.gguf':raise ValueError('مدل باید یک فایل GGUF داخل models\\llm باشد.')
            runtime_info=self.runtime.switch_generation(p)
            ids=self._served_ids()
            verified=bool(ids) and any(p.name.casefold() in x.casefold() or str(p).casefold() in x.casefold() for x in ids)
            if not verified: raise RuntimeError(f'مدل جدید توسط /v1/models تأیید نشد. server={ids}')
            rel=p.relative_to(self.root).as_posix(); self.config['models']['generation']=rel
            cfg=self.root/'config.json'; disk=json.loads(cfg.read_text(encoding='utf-8'));disk['models']['generation']=rel;cfg.write_text(json.dumps(disk,ensure_ascii=False,indent=2),encoding='utf-8')
            return {'ok':True,'active':p.name,'path':str(p),'verified':True,'server_models':ids,'runtime':runtime_info}
