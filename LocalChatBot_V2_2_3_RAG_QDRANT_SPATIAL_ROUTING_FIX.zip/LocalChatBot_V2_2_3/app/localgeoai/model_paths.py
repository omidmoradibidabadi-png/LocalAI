from pathlib import Path


def resolve_embedding_model(root: Path, configured: str | None = None) -> Path:
    """Resolve the single GGUF embedding model in models/embedding.

    A concrete configured GGUF path is accepted for backward compatibility if it exists.
    Otherwise the embedding directory is auto-scanned. Exactly one GGUF must be present.
    """
    root = Path(root)
    if configured:
        p = root / configured
        if p.is_file() and p.suffix.lower() == '.gguf':
            return p.resolve()
        if p.is_dir():
            emb_dir = p
        else:
            emb_dir = root / 'models' / 'embedding'
    else:
        emb_dir = root / 'models' / 'embedding'
    if not emb_dir.exists():
        raise FileNotFoundError(f"Embedding model directory is missing: {emb_dir}")
    models = sorted((p for p in emb_dir.glob('*.gguf') if p.is_file()), key=lambda p: p.name.lower())
    if not models:
        raise FileNotFoundError(f"No GGUF embedding model found in: {emb_dir}")
    if len(models) > 1:
        names = ', '.join(p.name for p in models)
        raise RuntimeError(f"Multiple GGUF embedding models found in {emb_dir}. Keep exactly one GGUF file. Found: {names}")
    return models[0].resolve()
