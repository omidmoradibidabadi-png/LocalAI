from __future__ import annotations
import re

def _clean(s):return re.sub(r'\s+',' ',str(s or '')).strip()
def evidence_fallback(question,evidence,max_items=7):
    qterms={x.casefold() for x in re.findall(r'[\w\u0600-\u06ff-]{3,}',question or '')}
    candidates=[]
    for e in evidence:
        text=str(e.get('text','')); sentences=re.split(r'(?<=[.!?؟;:])\s+|\n+|\s+[•▪◦]\s*|\s{2,}|(?=\b(?:Challenges?|Strategic|Regional|Potential|Direct|Influence|Force|Operational)\b)',text)
        for s in sentences:
            s=_clean(s)
            if len(s)<18:continue
            st=s.casefold(); score=sum(1 for t in qterms if t in st)
            if score:candidates.append((score,len(s),e.get('n',1),s[:420]))
    candidates.sort(key=lambda x:(-x[0],x[1]))
    out=[];seen=set()
    for _,_,n,s in candidates:
        key=s[:100].casefold()
        if key in seen:continue
        seen.add(key);out.append(f'• {s} [{n}]')
        if len(out)>=max_items:break
    if not out:
        out=[f"• {_clean(e.get('text',''))[:320]} [{e.get('n',i+1)}]" for i,e in enumerate(evidence[:4]) if _clean(e.get('text',''))]
    return 'بر اساس شواهد محلی بازیابی‌شده، موارد مرتبط عبارت‌اند از:\n\n'+'\n'.join(out)+'\n\nاین پاسخ جایگزین مستقیماً از شواهد محلی ساخته شده است؛ مدل زبانی پاسخ نهایی تولید نکرد.'

def compact_evidence(evidence,total_chars=5200,per_item=1300):
    out=[];used=0;seen=set()
    for e in sorted(evidence,key=lambda x:float(x.get('score') or 0),reverse=True):
        t=_clean(e.get('text','')); key=t[:140].casefold()
        if not t or key in seen:continue
        seen.add(key); room=min(per_item,total_chars-used)
        if room<=120:break
        x=dict(e);x['text']=t[:room];out.append(x);used+=len(x['text'])
    for i,x in enumerate(out,1):x['n']=i
    return out
