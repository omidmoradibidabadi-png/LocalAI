from __future__ import annotations
from collections import deque
class ConversationState:
    def __init__(self,max_turns=8): self.turns=deque(maxlen=max_turns*2); self.active_sources=[]; self.active_entities=[]; self.active_spatial=None; self.current_task=None
    def add(self,role,content,**meta):
        self.turns.append({'role':role,'content':str(content)[:5000]})
        if meta.get('sources'): self.active_sources=meta['sources'][:12]
        if meta.get('spatial') is not None:self.active_spatial=meta['spatial']
        if meta.get('task'):self.current_task=meta['task']
    def messages(self): return list(self.turns)
    def summary(self):
        return {'recent_turns':list(self.turns)[-8:],'active_sources':[str(x.get('source') or x.get('original_path') or '') for x in self.active_sources[:8]],'current_task':self.current_task,'has_active_spatial_result':bool(self.active_spatial)}
