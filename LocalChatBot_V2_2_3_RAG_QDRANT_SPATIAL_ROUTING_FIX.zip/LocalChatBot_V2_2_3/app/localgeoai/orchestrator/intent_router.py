from app.localgeoai.spatial.contracts import AnalysisPlan, Intent

# A technical word such as "برد" is NOT by itself a GIS request.
GIS_ACTIONS=("شعاع","نزدیکترین","نزدیک‌ترین","نزدیک ","اطراف","فاصله از","روی نقشه","نقشه نشان",
             "مبدأ","مبدا","مقصد","کدام فرودگاه‌ها","کدام فرودگاه ها","چه فرودگاه‌هایی","چه فرودگاه هایی",
             "within","radius","nearest","near ","on the map","origin","destination","which airports")
TECH=("هواپیما","هواپیماها","هواگرد","مشخصات","فنی","مأموریتی","ماموریتی","مداومت","سرعت","برد","سقف پرواز",
      "وزن","محموله","ظرفیت","سوخت","موتور","مواد","جنس","دما","technical","aircraft","endurance","speed",
      "range","payload","capacity","fuel","engine","material","temperature")
DOC=("سند","مدرک","گزارش","ایمیل","صفحه","منبع","document","report","email","manual")

class IntentRouter:
    def classify(self,question:str)->AnalysisPlan:
        q=question.casefold()
        gis=any(x in q for x in GIS_ACTIONS)
        tech=any(x in q for x in TECH+DOC)
        intent=Intent.MIXED if gis and tech else Intent.SPATIAL if gis else Intent.DOCUMENT
        return AnalysisPlan(intent=intent,question=question,
            requires_map=intent in {Intent.SPATIAL,Intent.MIXED},
            requires_documents=intent in {Intent.DOCUMENT,Intent.MIXED})
