from __future__ import annotations
import json,time,uuid,urllib.error
from pathlib import Path
from app.localgeoai.main import ROOT,CONFIG,http_json,url

class LLMClient:
    """Single OpenAI-compatible llama.cpp client used by planner, chat, reranking and synthesis."""
    def __init__(self,purpose='llm'):
        self.g=CONFIG['services']['generation']; self.purpose=purpose
        self.log=ROOT/'logs'/'llama_generation.log'; self.log.parent.mkdir(parents=True,exist_ok=True)
        self.context=int(self.g.get('context',4096)); self.reserve=640
    def _estimate(self,s): return max(1,(len(str(s))+2)//3)  # conservative multilingual approximation
    def chat(self,messages,max_tokens=600,temperature=.1,json_mode=False,timeout=180):
        rid=uuid.uuid4().hex[:12]; msgs=[]; budget=max(512,self.context-int(max_tokens)-self.reserve); used=0
        # retain system + newest messages under a token budget
        system=[m for m in messages if m.get('role')=='system'][:1]; rest=[m for m in messages if m.get('role')!='system']
        selected=[]
        for m in reversed(rest):
            n=self._estimate(m.get('content',''))
            if selected and used+n>budget: break
            selected.append(m); used+=n
        msgs=system+list(reversed(selected))
        payload={'model':'local-gemma','messages':msgs,'temperature':float(temperature),'max_tokens':int(max_tokens),'stream':False,
                 'reasoning_format':'none','reasoning_effort':'none','chat_template_kwargs':{'enable_thinking':False}}
        if json_mode: payload['response_format']={'type':'json_object'}
        ep=url(self.g['host'],self.g['port'],'/v1/chat/completions'); t=time.time(); row={'request_id':rid,'purpose':self.purpose,'prompt_tokens_est':sum(self._estimate(m.get('content','')) for m in msgs),'max_tokens':max_tokens}
        try:
            r=http_json('POST',ep,payload,timeout); c=(r.get('choices') or [{}])[0]; txt=str((c.get('message') or {}).get('content') or c.get('text') or '').strip()
            row.update(ok=bool(txt),latency_s=round(time.time()-t,3),usage=r.get('usage')); self._write(row)
            if not txt: raise RuntimeError('llama-server returned empty content')
            return txt,row
        except urllib.error.HTTPError as e:
            try: body=e.read().decode('utf-8','replace')[:4000]
            except Exception: body=''
            row.update(ok=False,status=getattr(e,'code',None),error=str(e),body=body,latency_s=round(time.time()-t,3)); self._write(row); raise RuntimeError(f"llama HTTP {getattr(e,'code',None)}: {body or e}")
        except Exception as e:
            row.update(ok=False,error=repr(e),latency_s=round(time.time()-t,3)); self._write(row); raise
    def json(self,messages,max_tokens=700,timeout=180):
        txt,meta=self.chat(messages,max_tokens=max_tokens,temperature=0,json_mode=True,timeout=timeout)
        try:return json.loads(txt),meta
        except Exception:
            import re
            m=re.search(r'\{[\s\S]*\}',txt)
            if not m: raise RuntimeError('LLM did not return JSON: '+txt[:500])
            return json.loads(m.group(0)),meta
    def _write(self,row):
        try:
            with self.log.open('a',encoding='utf-8') as f:f.write(json.dumps(row,ensure_ascii=False,default=str)+'\n')
        except Exception: pass
