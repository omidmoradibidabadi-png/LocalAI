from __future__ import annotations
import json,time,uuid,urllib.error
from app.localgeoai.main import ROOT,http_json,url

class GenerationDiagnosticClient:
    def __init__(self,config):
        self.config=config; self.g=config['services']['generation']
        self.policy=config.get('generation_reliability',{})
        self.log_path=ROOT/self.policy.get('diagnostic_log','logs/llm_generation_diagnostics.jsonl')
        self.log_path.parent.mkdir(parents=True,exist_ok=True)
    def _write(self,row):
        try:
            with self.log_path.open('a',encoding='utf-8') as f:f.write(json.dumps(row,ensure_ascii=False,default=str)+'\n')
        except Exception:pass
    @staticmethod
    def _flatten(raw):
        if isinstance(raw,list):
            parts=[]
            for x in raw:
                if isinstance(x,dict): parts.append(str(x.get('text') or x.get('content') or ''))
                else: parts.append(str(x))
            raw=''.join(parts)
        return str(raw or '').strip()
    @classmethod
    def _content(cls,choice):
        msg=choice.get('message') or {}; raw=msg.get('content')
        if raw in (None,''): raw=choice.get('text','')
        return cls._flatten(raw)
    @classmethod
    def _shape(cls,choice):
        msg=choice.get('message') or {}; reasoning=''
        for k in ('reasoning_content','reasoning','analysis'):
            if msg.get(k): reasoning=cls._flatten(msg.get(k)); break
        content=cls._content(choice)
        return {'message_keys':list(msg.keys()),'content_chars':len(content),'reasoning_present':bool(reasoning),'reasoning_chars':len(reasoning)}
    def _payload(self,text,max_tokens,mode):
        payload={'model':'local-gemma','messages':[{'role':'system','content':'فقط پاسخ نهایی را به فارسی، مستقیم و منظم بنویس. فرایند استدلال داخلی را چاپ نکن.'},{'role':'user','content':text}], 'temperature':0.05,'max_tokens':int(max_tokens),'stream':False}
        if mode=='no-reasoning':
            payload['reasoning_format']='none'; payload['reasoning_effort']='none'; payload['chat_template_kwargs']={'enable_thinking':False}
        return payload
    def generate(self,prompt,max_tokens=520,purpose='answer'):
        rid=uuid.uuid4().hex[:12]; diagnostics=[]
        limits=self.policy.get('prompt_char_limits',[5200,3200]); toks=self.policy.get('max_tokens',[640,520]); tos=self.policy.get('timeouts_seconds',[150,120])
        for i,mode in enumerate(('no-reasoning','compat')):
            lim=int(limits[min(i,len(limits)-1)]); text=str(prompt)
            if len(text)>lim:
                head=max(700,lim//3); text=text[:head]+'\n...[context compacted]...\n'+text[-(lim-head-35):]
            mt=min(int(max_tokens),int(toks[min(i,len(toks)-1)])); payload=self._payload(text,mt,mode)
            endpoint=url(self.g['host'],self.g['port'],'/v1/chat/completions'); t=time.time()
            row={'request_id':rid,'purpose':purpose,'attempt':i+1,'mode':mode,'prompt_chars':len(text),'max_tokens':mt,'endpoint':endpoint}
            try:
                r=http_json('POST',endpoint,payload,int(tos[min(i,len(tos)-1)])); choice=(r.get('choices') or [{}])[0]; ans=self._content(choice); shape=self._shape(choice)
                row.update({'ok':bool(ans),'http':'ok','latency_s':round(time.time()-t,3),'response_chars':len(ans),'finish_reason':choice.get('finish_reason'),'usage':r.get('usage'),'response_keys':list(r.keys()),'choice_keys':list(choice.keys()),**shape})
                diagnostics.append(row); self._write(row)
                if ans:return {'answer':ans,'diagnostics':diagnostics,'request_id':rid}
            except urllib.error.HTTPError as e:
                try: body=e.read().decode('utf-8','replace')[:1200]
                except Exception: body=''
                row.update({'ok':False,'latency_s':round(time.time()-t,3),'error_type':'HTTPError','status':getattr(e,'code',None),'error':str(e),'body':body}); diagnostics.append(row); self._write(row)
            except Exception as e:
                row.update({'ok':False,'latency_s':round(time.time()-t,3),'error_type':type(e).__name__,'error':str(e)[:1200]}); diagnostics.append(row); self._write(row)
        return {'answer':'','diagnostics':diagnostics,'request_id':rid,'error_code':'LLM_GENERATION_FAILED'}
