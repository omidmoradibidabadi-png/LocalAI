from __future__ import annotations
import json
from app.localgeoai.orchestrator.llm_client import LLMClient
ALLOWED_MODES={'conversation','targeted_retrieval','exhaustive_corpus','filtered_corpus','structured_query','spatial_query','mixed_analysis'}

def plan_query(question,spatial_profile=None,scope_path=None,conversation=None):
    datasets=[]
    for d in (spatial_profile or {}).get('datasets',[])[:20]:
        datasets.append({'dataset':d.get('dataset'),'kind':d.get('kind'),'fields':(d.get('fields') or [])[:60]}) if isinstance(d,dict) else None
    schema='''Return strict JSON with: domain, intent, analysis_mode, scope, entities, constraints, requires_local_evidence, tools, semantic_queries, lexical_queries, needs_clarification, needs_map, reason, confidence.
domain must be one of general,knowledge,email,spatial,structured,mixed. analysis_mode must be one of conversation,targeted_retrieval,exhaustive_corpus,filtered_corpus,structured_query,spatial_query,mixed_analysis.
Use conversation for greetings/help/general reasoning that makes no factual claim about the user's corpus. Use targeted_retrieval for focused local-document facts. Use exhaustive_corpus when every eligible source must be examined. Use filtered_corpus when the whole corpus must be scanned to identify all matching sources. Use structured_query for exact table calculations. Use spatial_query for geometry/map/location operations. Use mixed_analysis only when multiple tools are truly needed.
Intent must be inferred semantically, never from isolated trigger words. semantic_queries: 1-3 meaning-preserving retrieval reformulations in the user's language; lexical_queries: 0-3 conservative exact variants. Do not invent corpus facts.'''
    user={'question':question,'selected_scope':scope_path or None,'conversation':conversation or {},'spatial_schema':datasets}
    obj,_=LLMClient('query-planner').json([{'role':'system','content':'You are the semantic tool planner for a fully local AI assistant. '+schema},{'role':'user','content':json.dumps(user,ensure_ascii=False)}],max_tokens=800,timeout=120)
    mode=str(obj.get('analysis_mode') or '').strip()
    aliases={'retrieval':'targeted_retrieval','exhaustive':'exhaustive_corpus','structured':'structured_query','spatial':'spatial_query','mixed':'mixed_analysis','conversational':'conversation'}
    mode=aliases.get(mode,mode)
    if mode not in ALLOWED_MODES: mode='targeted_retrieval'
    obj['analysis_mode']=mode; domain=str(obj.get('domain') or '').lower(); obj['domain']=domain if domain in {'general','knowledge','email','spatial','structured','mixed'} else ('general' if mode=='conversation' else 'spatial' if mode=='spatial_query' else 'structured' if mode=='structured_query' else 'knowledge'); obj['requires_local_evidence']=bool(obj.get('requires_local_evidence',mode!='conversation'))
    obj['semantic_queries']=[str(x).strip() for x in obj.get('semantic_queries',[]) if str(x).strip()][:3] or [question]
    obj['lexical_queries']=[str(x).strip() for x in obj.get('lexical_queries',[]) if str(x).strip()][:3]
    obj['tools']=[str(x) for x in obj.get('tools',[])][:6]
    return obj
