from __future__ import annotations
import re
from pathlib import Path
from app.localgeoai.main import CONFIG
from app.localgeoai.structured.catalog import StructuredCatalog
from app.localgeoai.enterprise.elastic_client import ElasticClient
from app.localgeoai.orchestrator.answer_reliability import evidence_fallback, compact_evidence
from app.localgeoai.ingestion.registry import classify
from app.localgeoai.text_normalization import normalize_search_text, query_variants

def _citation_integrity(answer,evidence):
 import re
 valid={int(e.get('n')) for e in evidence if str(e.get('n','')).isdigit()}
 # Remove model-invented citation numbers. The UI will only expose evidence IDs that exist.
 def repl(m): return m.group(0) if int(m.group(1)) in valid else ''
 answer=re.sub(r'\[(\d+)\]',repl,str(answer or ''))
 used=[]
 for n in re.findall(r'\[(\d+)\]',answer):
  n=int(n)
  if n in valid and n not in used:used.append(n)
 # If Gemma omitted citations, bind paragraphs conservatively to the strongest supplied evidence.
 if not used and evidence:
  paras=[x for x in answer.split('\n') if x.strip()]
  if paras:
   first=int(evidence[0]['n']); answer=answer.rstrip()+f' [{first}]' ; used=[first]
 return answer,used


def _document_level_evidence(evidence):
 """Collapse page/slide/chunk hits into one stable citation per original document."""
 groups={}
 for e in evidence or []:
  src=str(e.get('original_path') or e.get('source') or '').strip()
  if not src: continue
  try:key=str(Path(src).resolve()).casefold()
  except Exception:key=src.casefold()
  g=groups.setdefault(key,{'source':src,'original_path':src,'texts':[],'locations':[],'scores':[],'engines':set(),'type':e.get('type') or e.get('kind') or 'local','kind':e.get('kind')})
  txt=str(e.get('text') or '').strip()
  if txt and txt not in g['texts']:g['texts'].append(txt)
  loc=e.get('page')
  if loc not in (None,'') and str(loc) not in g['locations']:g['locations'].append(str(loc))
  try:g['scores'].append(float(e.get('score') or 0))
  except Exception:pass
  if e.get('engine'):g['engines'].add(str(e['engine']))
 out=[]
 for g in groups.values():
  locs=g.pop('locations');texts=g.pop('texts');scores=g.pop('scores');eng=g.pop('engines')
  g.update({'n':len(out)+1,'page':', '.join(locs[:12]) or None,'text':'\n---\n'.join(texts)[:6000],'score':max(scores) if scores else 0,'engine':'+'.join(sorted(eng)) or 'local','evidence_chunks':len(texts),'locations':locs})
  out.append(g)
 return out

def _negative_no_evidence(answer):
 return bool(re.search(r'(شاهد|مدرک|اطلاعات|داده).{0,45}(پیدا نشد|یافت نشد|وجود ندارد|موجود نیست)|no (relevant )?(evidence|information) (was )?found',str(answer or ''),re.I))

class GenerationFailure(Exception):
 def __init__(self,cause,diagnostics): super().__init__(str(cause)); self.diagnostics=diagnostics

def _evtext(ev):return '\n\n'.join(f"[{e['n']}] SOURCE={e['source']} LOC={e.get('page')}\n{e['text']}" for e in ev)
def _kind_hint(q):
 s=str(q or '').casefold()
 if re.search(r'ایمیل|ايميل|email|e-mail|mail',s): return 'email'
 if re.search(r'پاورپوینت|ارائه|pptx|presentation|slide',s): return 'presentation'
 if re.search(r'pdf|پی.?دی.?اف',s): return 'document'
 if re.search(r'اکسل|excel|xlsx|csv|جدول|spreadsheet',s): return 'structured'
 return None
def _comprehensive(q):
 return bool(re.search(r'همه|تمام|کل|کلی|سرفصل|خلاصه.*(پوشه|فایل|داده|ایمیل|ايميل|email|سند|مدرک)|محتوای.*(پوشه|ایمیل|ايميل|email)|overview|summar.*(folder|email|documents?)|all files',str(q or ''),re.I))
class UnifiedEngine:
 def __init__(self,rag,spatial,router):
  self.rag=rag;self.spatial=spatial;self.router=router;self.structured=StructuredCatalog();self.es=ElasticClient(CONFIG.get('enterprise_search',{}).get('elasticsearch_url','http://127.0.0.1:9200'))
 def _llm(self,prompt,max_tokens=650):
  from app.localgeoai.orchestrator.llm_diagnostics import GenerationDiagnosticClient
  r=GenerationDiagnosticClient(CONFIG).generate(prompt,max_tokens=max_tokens,purpose='grounded-answer')
  if r.get('answer'):return r['answer'],r.get('diagnostics',[])
  raise GenerationFailure(RuntimeError(r.get('error_code') or 'LLM_FAILED'),r.get('diagnostics',[]))
 def _from_hits(self,hits,limit=12):
  ev=[];seen=set()
  for h in hits:
   src=h.get('source') or {}; text=str(src.get('body') or '').strip(); path=str(src.get('path') or src.get('title') or '')
   if not text or not path:continue
   key=(path,src.get('section'),text[:120]);
   if key in seen:continue
   seen.add(key); ev.append({'n':len(ev)+1,'source':path,'original_path':path,'page':src.get('section_label') or src.get('section'),'score':float(h.get('score') or 1),'text':text[:3200],'engine':'elasticsearch','type':src.get('kind') or 'local','kind':src.get('kind')})
   if len(ev)>=limit:break
  return ev
 def _scoped_document_evidence(self,q,path,limit=8):
  ev=[]; seen=set()
  # A selected file is already an explicit scope. Do not require its OCR/body to lexically
  # contain words such as "inside the image" before it can become evidence.
  try:
   for e in self._from_hits(self.es.list_path(str(Path(path).resolve()),size=max(20,limit*3)),limit):
    key=(str(e.get('original_path') or e.get('source') or '').casefold(),str(e.get('page')),str(e.get('text') or '')[:120])
    if key not in seen: ev.append(e);seen.add(key)
  except Exception: pass
  try:
   for e in self.rag.retrieve_path(path,limit=max(32,limit*4)):
    key=(str(e.get('original_path') or e.get('source') or '').casefold(),str(e.get('page')),str(e.get('text') or '')[:120])
    if key not in seen: ev.append(e);seen.add(key)
    if len(ev)>=limit: break
  except Exception: pass
  for i,e in enumerate(ev,1): e['n']=i
  return ev[:limit]
 def _folder_manifest(self,folder):
  root=Path(folder).expanduser().resolve()
  if not root.exists() or not root.is_dir():return []
  internal=('.eml.meta.csv','.chunks.json','.ocr.txt','.extracted.txt')
  out=[]
  for p in root.rglob('*'):
   if not p.is_file() or p.name.lower().endswith(internal):continue
   k=classify(p)
   if k!='unsupported':out.append({'path':str(p.resolve()),'kind':k})
  return out
 def _folder_evidence(self,q,folder,limit=16):
  """Source-complete folder retrieval.

  Candidate generation and reranking are deliberately separated:
  1) build the corpus manifest; 2) collect exact-path Qdrant evidence for EVERY indexed file;
  3) collect scoped semantic Qdrant hits; 4) collect ES lexical/entity hits;
  5) fuse without top-1 collapse. The LLM relevance gate runs only after this union exists.
  """
  kind=_kind_hint(q); manifest=self._folder_manifest(folder)
  eligible=[x for x in manifest if not kind or x['kind']==kind]
  if kind and not eligible:return [],{'manifest_files':len(manifest),'eligible_files':0,'kind_filter':kind}
  if not eligible:eligible=manifest
  paths=[x['path'] for x in eligible]
  allowed={str(Path(x).resolve()).casefold() for x in paths}
  lexical=[]; exact=[]; semantic=[]
  # Lexical/entity branch. Failure here must NOT discard Qdrant candidates.
  try:
   lexical=self._from_hits(self.es.search_paths(q,paths,kind=kind,size=max(80,len(paths)*6)),limit=max(80,len(paths)*6))
  except Exception:
   lexical=[]
  # Recall branch: every indexed source in the selected folder gets a chance to reach reranking.
  per_file_limit=4
  for fp in paths:
   try:
    rows=self.rag.retrieve_path(fp,limit=per_file_limit)
    for e in rows:
     z=dict(e);z['engine']='qdrant-folder-path';exact.append(z)
   except Exception:
    pass
  # Semantic branch is additive, never exclusive.
  try:
   for e in self.rag.retrieve(q,limit=max(100,len(paths)*8)):
    op=str(e.get('original_path') or e.get('source') or '')
    try:key=str(Path(op).resolve()).casefold() if op else ''
    except Exception:key=op.casefold()
    if key in allowed:
     z=dict(e);z['engine']='qdrant-semantic';semantic.append(z)
  except Exception:
   pass
  # Stable union. Lexical first, then semantic, then exact-path recall. No score-based top-1 truncation.
  ev=[];seen=set()
  for e in lexical+semantic+exact:
   src=str(e.get('original_path') or e.get('source') or '')
   try:src_key=str(Path(src).resolve()).casefold() if src else ''
   except Exception:src_key=src.casefold()
   key=(src_key,str(e.get('page')),str(e.get('text') or '')[:160])
   if not src_key or key in seen:continue
   seen.add(key);ev.append(e)
  # Keep enough chunks for document-level collapse; the next stage collapses by source before LLM rerank.
  cap=max(128,min(512,max(len(paths)*8,128)))
  ev=ev[:cap]
  for i,e in enumerate(ev,1):e['n']=i
  represented=len({str(Path(str(e.get('original_path') or e.get('source') or '')).resolve()).casefold() for e in ev if (e.get('original_path') or e.get('source'))})
  indexed_paths=set()
  for e in exact:
   op=str(e.get('original_path') or e.get('source') or '')
   if op:
    try:indexed_paths.add(str(Path(op).resolve()).casefold())
    except Exception:indexed_paths.add(op.casefold())
  missing=[x for x in paths if str(Path(x).resolve()).casefold() not in indexed_paths]
  trace_candidates=[]
  for e in ev[:96]:
   trace_candidates.append({'n':e.get('n'),'source':Path(str(e.get('original_path') or e.get('source') or '')).name,'engine':e.get('engine') or e.get('type') or 'local','score':e.get('score'),'text':str(e.get('text') or '')[:220]})
  return ev,{'manifest_files':len(manifest),'eligible_files':len(eligible),'es_candidates':len(lexical),'qdrant_exact':len(exact),'semantic_scoped':len(semantic),'represented_files':represented,'qdrant_indexed_files':len(indexed_paths),'qdrant_missing_files':len(missing),'qdrant_missing_names':[Path(x).name for x in missing[:50]],'candidate_chunks':len(ev),'kind_filter':kind,'trace_candidates':trace_candidates}
 def _global_evidence(self,q,limit=8):
  ev=[];seen=set()
  for v in query_variants(q):
   try:
    for e in self._from_hits(self.es.search(v,size=max(limit,16)),max(limit,16)):
     key=(str(e.get('source')),str(e.get('page')),str(e.get('text'))[:120])
     if key not in seen: seen.add(key);ev.append(e)
   except Exception: pass
  # semantic branch is additive and especially important for Persian morphology/wording variants.
  try:
   for e in self.rag.retrieve(normalize_search_text(q),limit=max(24,limit*3)):
    key=(str(e.get('original_path') or e.get('source')),str(e.get('page')),str(e.get('text'))[:120])
    if key not in seen: seen.add(key);ev.append(e)
  except Exception: pass
  for i,e in enumerate(ev,1):e['n']=i
  return ev[:max(limit,16)]
 def _relevance_gate(self,q,evidence,folder_mode=False):
  """Local-evidence relevance gate.

  V6.4.16: folder reranking is evidence-aware and recall-safe.  The LLM receives the
  actual text for every document-level candidate and returns structured judgements.
  A pathological top-1 result is not allowed to erase the candidate pool: when the
  folder has several represented sources, a small retrieval safety set is preserved
  for the final grounded answer.  This does not create facts; it only prevents the
  reranker from hiding locally retrieved evidence.
  """
  if not evidence:return [],{'kept':0,'input':0}
  cap=96 if folder_mode else 24
  sample=[]
  for e in evidence[:cap]:
   sample.append({'n':e.get('n'),'source':Path(str(e.get('original_path') or e.get('source') or '')).name,
                  'engine':str(e.get('engine') or 'local'),'score':e.get('score'),
                  'text':str(e.get('text') or '')[:2200 if folder_mode else 900]})
  if folder_mode:
   prompt=('You are a LOCAL EVIDENCE RERANKER, not an answer generator. Judge each source against the ENTIRE user question. '
           'Read the SOURCE NAME and EVIDENCE TEXT, not retrieval score/order. Exact named organizations/documents/results and direct requested values outrank generic topical discussion. '
           'A generic PCR article must not outrank a laboratory report when the question asks for that named laboratory result. '
           'Return strict JSON only: {"judgements":[{"n":2,"relevance":0-100,"direct_support":true,"reason":"short reason"}],"ranked":[2,1]}. '
           'Evaluate ALL supplied sources. Do not use outside knowledge. USER QUESTION: '+q+'\nEVIDENCE: '+__import__('json').dumps(sample,ensure_ascii=False))
  else:
   prompt=('Evaluate evidence relevance to the ENTIRE user question, including all entities, places, dates and requested relations. '
           'Return JSON only: {"keep":[evidence numbers]}. Keep an item only if it can directly support at least one material part of the answer. '
           'Do not use outside knowledge and do not infer missing geographic/entity relationships. USER QUESTION: '+q+'\nEVIDENCE: '+__import__('json').dumps(sample,ensure_ascii=False))
  try:
   ans,_=self._llm(prompt,700 if folder_mode else 220)
   import json,re
   m=re.search(r'\{[\s\S]*\}',ans); obj=json.loads(m.group(0)) if m else {}
   if folder_mode:
    by={int(e.get('n',-1)):e for e in evidence}
    judgements={}
    for j in obj.get('judgements',[]) if isinstance(obj.get('judgements',[]),list) else []:
     try:
      n=int(j.get('n')); rel=max(0.0,min(100.0,float(j.get('relevance',0))))
     except Exception:continue
     judgements[n]={'relevance':rel,'direct_support':bool(j.get('direct_support',False)),'reason':str(j.get('reason') or '')[:180]}
    order=[]
    for x in obj.get('ranked',[]) if isinstance(obj.get('ranked',[]),list) else []:
     try:n=int(x)
     except Exception:continue
     if n in by and n not in order:order.append(n)
    # Prefer explicit direct-support judgements, then the LLM ranking.
    direct=sorted((n for n,j in judgements.items() if j['direct_support'] and n in by),key=lambda n:judgements[n]['relevance'],reverse=True)
    selected=[]
    for n in direct+order:
     if n in by and n not in selected:selected.append(n)
    # Recall safety: a folder reranker may not collapse a diverse local corpus to one
    # source. Preserve up to three distinct retrieval leaders so final Gemma can compare
    # the actual local evidence. This is especially important for OCR/entity queries.
    safety=[]
    if len(by)>=3 and len(selected)<3:
     # evidence order is the stable hybrid candidate order (ES + semantic + exact recall)
     for e in evidence:
      n=int(e.get('n',-1))
      if n in by and n not in selected and n not in safety:safety.append(n)
      if len(selected)+len(safety)>=3:break
    final_ids=(selected+safety)[:12]
    out=[by[n] for n in final_ids if n in by]
    original_ids=list(final_ids)
    for i,e in enumerate(out,1):e['n']=i
    return out,{'input':len(evidence),'evaluated':len(sample),'kept':len(out),'mode':'llm_folder_evidence_rank_v2',
                'ranked_original_ids':order[:20],'direct_support_ids':direct[:20],'safety_added_ids':safety,
                'judgements':judgements,'rerank_raw':str(ans)[:2400],
                'rerank_input':[{'n':x.get('n'),'source':x.get('source'),'engine':x.get('engine'),'score':x.get('score')} for x in sample],
                'rerank_selected':[{'original_n':original_ids[i] if i<len(original_ids) else None,'n':x.get('n'),'source':Path(str(x.get('original_path') or x.get('source') or '')).name} for i,x in enumerate(out)]}
   keep={int(x) for x in obj.get('keep',[]) if str(x).isdigit()}
   out=[e for e in evidence if int(e.get('n',-1)) in keep]
   for i,e in enumerate(out,1):e['n']=i
   return out,{'input':len(evidence),'kept':len(out),'mode':'llm_semantic'}
  except Exception as ex:
   # Fail closed for non-folder scope. In folder scope, preserve a tiny local-only
   # retrieval set rather than silently replacing it with model knowledge.
   if folder_mode:
    out=[dict(e) for e in evidence[:min(3,len(evidence))]]
    for i,e in enumerate(out,1):e['n']=i
    return out,{'input':len(evidence),'kept':len(out),'mode':'folder_local_retrieval_fallback','error':str(ex),
                'rerank_selected':[{'n':x.get('n'),'source':Path(str(x.get('original_path') or x.get('source') or '')).name} for x in out]}
   return [],{'input':len(evidence),'kept':0,'mode':'fail_closed','error':str(ex)}

 def _answer(self,q,evidence,intent,scope):
  evidence=_document_level_evidence(evidence)
  folder_mode=isinstance(scope,dict) and scope.get('mode')=='FOLDER_CORPUS'
  evidence,rel_diag=self._relevance_gate(q,evidence,folder_mode=folder_mode)
  if isinstance(scope,dict) and scope.get('mode')=='FOLDER_CORPUS':
   # Preserve LLM relevance order and source diversity for both normal and comprehensive folder questions.
   trimmed=[]; used=0; per_item=1400 if not scope.get('comprehensive') else 900; budget=12000 if not scope.get('comprehensive') else 16000
   for e in evidence:
    x=dict(e); x['text']=str(x.get('text') or '')[:per_item]; trimmed.append(x); used+=len(x['text'])
    if used>=budget: break
   evidence=trimmed
   for i,x in enumerate(evidence,1): x['n']=i
  else:
   evidence=compact_evidence(evidence)
  if not evidence:return {'answer':'در محدوده انتخاب‌شده شاهد کافی برای پاسخ پیدا نشد.','sources':[],'intent':intent,'requires_map':False,'error_code':'NO_EVIDENCE_IN_SCOPE','scope':scope}
  try:
   ans,diag=self._llm('سؤال کاربر: '+q+'\n\nشواهد محلی شماره‌گذاری‌شده:\n'+_evtext(evidence)+'\n\nفقط بر اساس همین شواهد پاسخ فارسی بده. هیچ دانشی خارج از شواهد اضافه نکن. برای هر ادعا [شماره] منبع را ذکر کن.',620)
   gen='gemma'
  except GenerationFailure as e: ans=evidence_fallback(q,evidence);diag=e.diagnostics;gen='evidence-synthesizer'
  ans,used_citations=_citation_integrity(ans,evidence)
  if _negative_no_evidence(ans):
   ans=re.sub(r'\s*\[\d+\]','',ans); used_citations=[]; evidence=[]
  # Source panel is generated from the same evidence namespace used inside the answer.
  bound=[e for e in evidence if int(e.get('n',-1)) in used_citations] or evidence
  final_trace=[{'n':e.get('n'),'source':Path(str(e.get('original_path') or e.get('source') or '')).name,'engine':e.get('engine') or e.get('type') or 'local','score':e.get('score')} for e in evidence]
  return {'answer':ans,'sources':bound,'intent':intent,'requires_map':False,'scope':scope,'generation':{'engine':gen,'diagnostics':diag},'retrieval':{'local_hits':len(evidence),'relevance_gate':rel_diag,'final_evidence':final_trace}}
 def ask(self,q,scope_path=None,scope_mode=None,query_plan=None):
  semantic_queries=(query_plan or {}).get('semantic_queries') or [q]
  retrieval_q=' '.join(dict.fromkeys(str(x).strip() for x in semantic_queries if str(x).strip())) or q
  if scope_mode=='folder' and scope_path:
   ev,diag=self._folder_evidence(retrieval_q,scope_path)
   out=self._answer(q,ev,'folder_corpus',{'mode':'FOLDER_CORPUS','path':scope_path,'comprehensive':False,'planner':query_plan or {}})
   out.setdefault('retrieval',{}).update(diag);return out
  if scope_path:
   ev=self._scoped_document_evidence(retrieval_q,scope_path)
   if not ev:return {'answer':'برای فایل انتخاب‌شده شاهد ایندکس‌شده‌ای پیدا نشد. سیستم به منابع دیگر مراجعه نکرد.','sources':[],'intent':'document','requires_map':False,'error_code':'SELECTED_SCOPE_NO_EVIDENCE','scope':{'mode':'SINGLE_FILE','path':scope_path}}
   return self._answer(q,ev,'document',{'mode':'SINGLE_FILE','path':scope_path})
  ev=self._global_evidence(retrieval_q)
  return self._answer(q,ev,'document',{'mode':'GLOBAL_CORPUS'})
