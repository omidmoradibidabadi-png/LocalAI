from __future__ import annotations
import json, subprocess, math
from pathlib import Path

def _smi():
    flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
    r=subprocess.run(['nvidia-smi','--query-gpu=name,memory.total,memory.used,utilization.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=5,creationflags=flags)
    if r.returncode!=0 or not r.stdout.strip(): return None
    row=[x.strip() for x in r.stdout.strip().splitlines()[0].split(',')]
    return {'gpu':row[0],'vram_total_mb':int(float(row[1])),'vram_used_mb':int(float(row[2])),'gpu_util_pct':int(float(row[3]))}

def recommend_gpu_layers(model_path=None, profile='auto', reserve_mb=650):
    """VRAM-aware offload estimate. Conservative on small cards, scalable on larger GPUs."""
    try: smi=_smi()
    except Exception: smi=None
    if not smi: return {'cuda':False,'gpu_layers':0,'embedding_gpu_layers':0,'policy':'cpu','gpu':'','vram_total_mb':0,'vram_used_mb':0,'gpu_util_pct':0}
    total=smi['vram_total_mb']; used=smi['vram_used_mb']; free=max(0,total-used-reserve_mb)
    size_mb=(Path(model_path).stat().st_size/1048576) if model_path and Path(model_path).exists() else 0
    # llama.cpp layer memory is not exactly file_size/layers. We use a safe model-size ratio and let server health verification reject bad starts.
    if profile=='cpu_safe': layers=0
    elif profile=='gpu_priority': layers=999
    elif not size_mb: layers=999 if total>=12000 else (32 if total>=8000 else 20)
    else:
        ratio=min(1.0, free/max(size_mb*1.12,1))
        # 999 means full offload. Otherwise estimate against a typical 48-layer family; this is intentionally model-agnostic.
        layers=999 if ratio>=0.96 else max(1,int(math.floor(48*ratio)))
        if total<=4600: layers=min(layers,28)
    
    # EmbeddingGemma must not be silently forced to CPU. Reserve a modest share on small VRAM, full offload on large cards.
    if total <= 4600: emb_layers=max(1,min(12, layers//2 if layers not in (0,999) else 8))
    elif total < 12000: emb_layers=24
    else: emb_layers=999
    return {'cuda':True,'gpu_layers':layers,'embedding_gpu_layers':emb_layers,'policy':profile,'model_size_mb':round(size_mb,1),'vram_free_budget_mb':free,**smi}

def detect_hardware(model_path=None, profile='auto', reserve_mb=650):
    x=recommend_gpu_layers(model_path,profile,reserve_mb)
    x['generation_gpu_layers']=x.pop('gpu_layers',0)
    return x

def write_snapshot(root,info):
    p=Path(root)/'logs/hardware_profile.json';p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding='utf-8');return p

def parse_offload_log(path):
    import re
    try:text=Path(path).read_text(encoding='utf-8',errors='ignore')[-250000:]
    except Exception:return {'verified':False,'gpu_layers':None,'total_layers':None,'backend':'unknown'}
    pats=[r'offloaded\s+(\d+)\s*/\s*(\d+)\s+layers',r'offloaded\s+(\d+)\s+layers.*?(\d+)\s+layers']
    for pat in pats:
        m=list(re.finditer(pat,text,re.I|re.S))
        if m:
            a,b=map(int,m[-1].groups());return {'verified':True,'gpu_layers':a,'total_layers':b,'backend':'CUDA' if a>0 else 'CPU'}
    cuda=bool(re.search(r'CUDA|ggml_cuda|NVIDIA',text,re.I))
    return {'verified':False,'gpu_layers':None,'total_layers':None,'backend':'CUDA-unverified' if cuda else 'unknown'}

def runtime_snapshot(root):
    root=Path(root)
    return {'generation':parse_offload_log(root/'logs'/'generation.err.log'),'embedding':parse_offload_log(root/'logs'/'embedding.err.log')}
