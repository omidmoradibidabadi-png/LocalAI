from __future__ import annotations
import re
AIRPORT_WORDS=r'(?:فرودگاه|airport|airfield|aerodrome)'
AIRCRAFT_WORDS=r'(?:هواپیما|هواپيما|بالگرد|aircraft|airplane|aeroplane|plane|helicopter)'
def looks_aviation(q):return bool(re.search(AIRPORT_WORDS+'|'+AIRCRAFT_WORDS,q or '',re.I))
def _terms(center):
 p=center.get('properties') or {};vals=[center.get('name','')]
 for k in ('iata','icao','iata_code','icao_code','ident','gps_code','local_code','city','municipality'):
  if p.get(k):vals.append(str(p[k]))
 return [x for x in vals if x]
def _feature(f,role):
 p=dict(f.get('properties') or {});p.update({'name':f.get('name'),'kind':f.get('kind'),'role':role,'dataset':f.get('dataset'),'source':f.get('source')})
 if f.get('distance_km') is not None:p['distance_km']=f['distance_km']
 return {'type':'Feature','geometry':{'type':'Point','coordinates':[f['lon'],f['lat']]},'properties':p}
def answer_local_aviation(q,spatial,images,rag=None,alias_expander=None):
 if not looks_aviation(q):return None
 cleaned=re.sub(AIRCRAFT_WORDS+'|'+AIRPORT_WORDS+r'|چه|چند|کدام|کجاست|کجا|نشان بده|روی نقشه|در|اطراف|موجود|هستند|هست|را|های',' ',q,flags=re.I)
 cleaned=' '.join(cleaned.replace('؟',' ').replace('?',' ').split())
 probes=[cleaned]
 if alias_expander:
  try:probes += list(alias_expander(cleaned) or [])
  except Exception:pass
 probes += [x for x in re.findall(r'[A-Za-z0-9_-]{2,}|[\u0600-\u06ff]{2,}',cleaned) if len(x)>1]
 candidates=[];used='';seen=set()
 for probe in probes:
  probe=str(probe or '').strip()
  if not probe or probe.casefold() in seen:continue
  seen.add(probe.casefold())
  try:candidates=spatial.resolve(probe,'airport') or spatial.resolve(probe)
  except Exception:candidates=[]
  if candidates:used=probe;break
 if not candidates:return None
 center=candidates[0];terms=_terms(center)
 nearby=spatial.nearby(center['lat'],center['lon'],15,kind=None,limit=1500);linked=spatial.related(terms,kind=None,limit=1500)
 merged={x['id']:x for x in [*nearby,*linked] if x.get('id')!=center.get('id')};rows=list(merged.values());aircraft=[]
 for x in rows:
  p=x.get('properties') or {};blob=(' '.join([str(x.get('kind','')),str(x.get('name','')),*map(str,p.values())])).lower()
  if str(x.get('kind','')).lower()=='aircraft' or any(w in blob for w in ('aircraft','airplane','aeroplane','helicopter','هواپیما','هواپيما','بالگرد')):aircraft.append(x)
 pics=images.nearby(center['lat'],center['lon'],15,200)
 gj={'type':'FeatureCollection','features':[_feature(center,'airport')]};gj['features'] += [_feature(x,'aircraft') for x in aircraft[:500]]
 for im in pics[:200]:gj['features'].append({'type':'Feature','geometry':{'type':'Point','coordinates':[im['lon'],im['lat']]},'properties':{'name':im['path'].split('\\')[-1].split('/')[-1],'kind':'local_image','role':'image','distance_km':im['distance_km'],'path':im['path']}})
 p=center.get('properties') or {};code=p.get('iata_code') or p.get('icao_code') or p.get('ident') or ''
 lines=[f"بر اساس کاتالوگ مکانی محلی شما: {center.get('name')} در {center['lat']:.6f}, {center['lon']:.6f}"+(f" ({code})" if code else ''),f"هواپیما/عارضه هوانوردی محلی مرتبط: {len(aircraft)}",f"تصویر ژئوتگ‌دار محلی در ۱۵ کیلومتری: {len(pics)}"]
 if aircraft:lines.append('نمونه عوارض محلی: '+ '، '.join((x.get('name') or 'بدون نام') for x in aircraft[:12]))
 return {'answer':'\n'.join(lines),'intent':'local_aviation','requires_map':True,'map':gj,'results':aircraft[:500],'sources':[{'type':'spatial','dataset':center.get('dataset'),'source':center.get('source'),'name':center.get('name')}],'local_evidence':{'matched_query':used,'airport':center,'aircraft_count':len(aircraft),'geotagged_images':len(pics)}}
