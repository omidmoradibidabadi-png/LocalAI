from __future__ import annotations
from math import radians, sin, cos, asin, sqrt
from .contracts import GeoEntity, SpatialResult
EARTH_RADIUS_KM = 6371.0088
class BasicSpatialEngine:
    @staticmethod
    def distance_km(a: GeoEntity, b: GeoEntity) -> float:
        if None in (a.latitude, a.longitude, b.latitude, b.longitude):
            raise ValueError("Coordinates are required for distance calculation.")
        lat1, lon1, lat2, lon2 = map(radians, [a.latitude, a.longitude, b.latitude, b.longitude])
        dlat, dlon = lat2-lat1, lon2-lon1
        h = sin(dlat/2)**2 + cos(lat1)*cos(lat2)*sin(dlon/2)**2
        return 2 * EARTH_RADIUS_KM * asin(sqrt(h))
    def candidates_within_km(self, center, candidates, radius_km):
        rows=[]; features=[]
        for item in candidates:
            d=self.distance_km(center,item)
            if d <= radius_km:
                row={"name":item.name,"entity_type":item.entity_type,"distance_km":round(d,3),"longitude":item.longitude,"latitude":item.latitude,"source_id":item.source_id,"properties":item.properties}
                rows.append(row)
                features.append({"type":"Feature","properties":row,"geometry":{"type":"Point","coordinates":[item.longitude,item.latitude]}})
        rows.sort(key=lambda x:x["distance_km"])
        return SpatialResult("candidates_within_km",rows,{"type":"FeatureCollection","features":features},[],[{"source_id":r.get("source_id"),"name":r["name"]} for r in rows if r.get("source_id")])
