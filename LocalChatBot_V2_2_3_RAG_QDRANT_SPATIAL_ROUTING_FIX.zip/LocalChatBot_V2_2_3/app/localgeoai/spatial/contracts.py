from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Protocol

class Intent(str, Enum):
    DOCUMENT = "document"
    SPATIAL = "spatial"
    MIXED = "mixed"
    STRUCTURED = "structured"
    REPORT = "report"

@dataclass(slots=True)
class GeoEntity:
    entity_type: str
    name: str
    longitude: float | None = None
    latitude: float | None = None
    source_id: str | None = None
    properties: dict[str, Any] = field(default_factory=dict)

@dataclass(slots=True)
class SpatialConstraint:
    kind: str
    value: float | str | None = None
    unit: str | None = None
    source_ref: str | None = None

@dataclass(slots=True)
class AnalysisPlan:
    intent: Intent
    question: str
    entities: list[GeoEntity] = field(default_factory=list)
    constraints: list[SpatialConstraint] = field(default_factory=list)
    operations: list[str] = field(default_factory=list)
    requires_map: bool = False
    requires_documents: bool = True

@dataclass(slots=True)
class SpatialResult:
    operation: str
    features: list[dict[str, Any]]
    geojson: dict[str, Any] | None
    assumptions: list[str]
    evidence: list[dict[str, Any]]

class SpatialEngine(Protocol):
    def distance_km(self, a: GeoEntity, b: GeoEntity) -> float: ...
    def candidates_within_km(self, center: GeoEntity, candidates: list[GeoEntity], radius_km: float) -> SpatialResult: ...
