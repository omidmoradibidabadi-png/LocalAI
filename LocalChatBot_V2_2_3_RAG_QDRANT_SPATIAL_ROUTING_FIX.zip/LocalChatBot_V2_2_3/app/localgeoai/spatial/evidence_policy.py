from dataclasses import dataclass
@dataclass(slots=True)
class ClaimDecision:
    allowed: bool
    label: str
    reason: str
class SpatialEvidencePolicy:
    @staticmethod
    def origin_claim(candidate_count:int,direct_origin_evidence:bool)->ClaimDecision:
        if direct_origin_evidence: return ClaimDecision(True,"supported","Direct origin evidence is available.")
        if candidate_count==0: return ClaimDecision(False,"insufficient","No spatially feasible candidate was found.")
        if candidate_count==1: return ClaimDecision(False,"single_spatial_candidate","One candidate satisfies the spatial constraints, but feasibility alone does not prove actual origin.")
        return ClaimDecision(False,"candidate_set","Multiple locations satisfy the spatial constraints; additional evidence is required to identify actual origin.")
