from __future__ import annotations
import re,json

def _feat(x,role='local_feature'):
 p=dict(x.get('properties') or {});p.update({'name':x.get('name'),'kind':x.get('kind'),'role':role,'dataset':x.get('dataset'),'source':x.get('source')})
 return {'type':'Feature','geometry':{'type':'Point','coordinates':[x['lon'],x['lat']]},'properties':p}

def map_like(q):
 return bool(re.search(r'(کجاست|کجا است|مختصات|روی نقشه|نقشه نشان|نشان بده|مکان|موقعیت|where is|coordinates|show.*map|map)',q or '',re.I))

def extract_subject(q):
 s=str(q or '')
 s=re.sub(r'(کجاست|کجا است|مختصات(?:ش)?(?: چیست)?|را روی نقشه نشان بده|روی نقشه نشان بده|را نشان بده|نشان بده|مکان(?:ش)?(?: کجاست)?|موقعیت(?:ش)?(?: کجاست)?|where is|show.*map|coordinates)',' ',s,flags=re.I)
 s=re.sub(r'[؟?،,.]+',' ',s);return ' '.join(s.split()).strip()

def answer_local_map(q,spatial,alias_expander=None):
 if not map_like(q):return None
 subject=extract_subject(q);probes=[subject]
 if alias_expander:
  try:probes += list(alias_expander(subject) or [])
  except Exception:pass
 seen=set();matches=[];used=''
 for probe in probes:
  probe=str(probe or '').strip()
  if not probe or probe.casefold() in seen:continue
  seen.add(probe.casefold());matches=spatial.resolve(probe,limit=20)
  if matches:used=probe;break
 if not matches:return None
 x=matches[0];p=x.get('properties') or {}
 code=p.get('iata_code') or p.get('icao_code') or p.get('ident') or p.get('code') or ''
 ans=f"بر اساس داده مکانی محلی شما، «{x.get('name')}» در مختصات {x['lat']:.6f}, {x['lon']:.6f} قرار دارد."
 if code:ans+=f" کد/شناسه: {code}."
 ans+=f" منبع محلی: {x.get('dataset')}."
 return {'answer':ans,'intent':'local_map','requires_map':True,'map':{'type':'FeatureCollection','features':[_feat(x,'resolved_local_feature')]},'results':matches[:20],'sources':[{'type':'spatial','dataset':x.get('dataset'),'source':x.get('source'),'name':x.get('name')}],'local_evidence':{'matched_query':used,'feature':x}}
