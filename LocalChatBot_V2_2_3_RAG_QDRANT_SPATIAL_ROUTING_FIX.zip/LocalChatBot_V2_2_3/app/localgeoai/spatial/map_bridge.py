from __future__ import annotations
"""Semantic bridge from a grounded chat answer to local SpatialCatalog features.

This module deliberately does not use a place-name/keyword table.  The local LLM
extracts map-worthy entities from the *question + grounded answer* and the
SpatialCatalog remains the authority for coordinates.
"""
from app.localgeoai.orchestrator.llm_client import LLMClient


def _feature(x):
    p=dict(x.get('properties') or {})
    p.update({'name':x.get('name'),'kind':x.get('kind'),'dataset':x.get('dataset'),'source':x.get('source'),'role':'chat_spatial_bridge'})
    return {'type':'Feature','geometry':{'type':'Point','coordinates':[float(x['lon']),float(x['lat'])]},'properties':p}


def attach_map(question, answer, query_plan, spatial, sources=None):
    """Return map payload resolved only against local spatial data, or None.

    The LLM may propose entity strings, but it cannot provide coordinates. Every
    displayed coordinate must resolve to a real SpatialCatalog row.
    """
    plan=query_plan or {}
    # Planner is the primary semantic gate. spatial/mixed modes are also eligible.
    wants=bool(plan.get('needs_map')) or str(plan.get('analysis_mode') or '') in {'spatial_query','mixed_analysis'} or str(plan.get('domain') or '') in {'spatial','mixed'}
    if not wants:
        return None
    src_names=[]
    for s in (sources or [])[:12]:
        for k in ('name','dataset'):
            v=s.get(k) if isinstance(s,dict) else None
            if v: src_names.append(str(v))
    prompt={
        'question':str(question or ''),
        'grounded_answer':str(answer or '')[:7000],
        'planner_entities':plan.get('entities') or [],
        'semantic_queries':plan.get('semantic_queries') or [],
        'source_names':src_names,
    }
    try:
        obj,_=LLMClient('map-bridge').json([
            {'role':'system','content':(
                'You connect a grounded local-data answer to a local GIS catalog. '
                'Return strict JSON: {"entities":[...],"reason":"..."}. '
                'Extract 1-8 concrete geographic entities whose location should be displayed to satisfy the user request. '
                'Prefer the location stated in grounded_answer when the question asks where another object/person/vehicle is located. '
                'Do not invent coordinates and do not invent a place absent from the question/answer. '
                'Keep names in forms likely to occur in the local GIS dataset; include a conservative shorter alias as another entity when useful.'
            )},
            {'role':'user','content':__import__('json').dumps(prompt,ensure_ascii=False)}
        ],max_tokens=360,temperature=0.0,timeout=90)
        probes=[str(x).strip() for x in (obj.get('entities') or []) if str(x).strip()][:8]
    except Exception as e:
        return {'requested':True,'features':[],'results':[],'note':'درخواست نقشه تشخیص داده شد، اما استخراج موجودیت مکانی با خطا مواجه شد: '+str(e)}
    # Add planner entities after answer-derived entities; de-duplicate without language-specific rules.
    probes += [str(x).strip() for x in (plan.get('entities') or []) if str(x).strip()]
    seen=set(); resolved=[]
    for probe in probes:
        key=probe.casefold()
        if not probe or key in seen: continue
        seen.add(key)
        try: rows=spatial.resolve(probe,limit=8)
        except Exception: rows=[]
        for x in rows:
            if x.get('id') not in {r.get('id') for r in resolved}:
                x=dict(x);x['_map_probe']=probe;resolved.append(x)
    if not resolved:
        return {'requested':True,'features':[],'results':[],'note':'درخواست نمایش روی نقشه تشخیص داده شد، اما موجودیت پاسخ در Spatial Catalog محلی پیدا نشد.','probes':probes}
    gj={'type':'FeatureCollection','features':[_feature(x) for x in resolved]}
    return {'requested':True,'features':gj['features'],'geojson':gj,'results':resolved,'note':f'{len(resolved)} عارضه مرتبط با پاسخ از Spatial Catalog محلی روی نقشه نمایش داده شد.','probes':probes}
