from __future__ import annotations
import re
PERSIAN_DIGITS=str.maketrans("۰۱۲۳۴۵۶۷۸۹","0123456789")
def parse_radius_query(q):
    x=q.translate(PERSIAN_DIGITS)
    m=re.search(r"(\d+(?:\.\d+)?)\s*(?:کیلومتر|km|kilometer|kilometre)",x,re.I)
    if not m:return None
    radius=float(m.group(1))
    # patterns: "... شعاع 700 کیلومتری مهرآباد ..." / "within 700 km of Mehrabad"
    center=None
    fa=re.search(r"(?:کیلومتر(?:ی)?|شعاع\s*\d+(?:\.\d+)?\s*کیلومتر(?:ی)?)\s+(?:از|اطراف|نزدیک|به)?\s*([آ-یA-Za-z0-9_\- ]+?)(?:\s+(?:کدام|چیست|هستند|قرار)|[؟?]|$)",x,re.I)
    en=re.search(r"(?:within|radius)\s*\d+(?:\.\d+)?\s*(?:km|kilometers?)\s*(?:of|around|from)?\s*([A-Za-z0-9_\- ]+?)(?:\?|$)",x,re.I)
    if fa:center=(fa.group(1) or "").strip()
    elif en:center=(en.group(1) or "").strip()
    return {"radius_km":radius,"center":center} if center else None
