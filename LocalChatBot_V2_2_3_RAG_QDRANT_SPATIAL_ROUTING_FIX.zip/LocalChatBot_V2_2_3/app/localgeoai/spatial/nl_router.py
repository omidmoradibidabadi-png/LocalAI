import re
FA_DIGITS=str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩","01234567890123456789")

def norm(s):
    return str(s or "").translate(FA_DIGITS).replace("ي","ی").replace("ك","ک").strip()

def clean_center(s):
    s=str(s or "")
    s=re.sub(r'(را\s+روی\s+نقشه\s+نشان\s+بده|را\s+نشان\s+بده|را\s+پیدا\s+کن|روی\s+نقشه\s+نشان\s+بده|نشان\s+بده|پیدا\s+کن|کدامند|کدام‌ها\s+هستند|کدام\s+ها\s+هستند|هستند)',' ',s,flags=re.I)
    s=re.sub(r'(فرودگاه(?:‌ها|ها|های)?|باند(?:های)?)',' ',s)
    s=re.sub(r'\b(?:airport|airports|airfield|aerodrome|runway|runways)\b',' ',s,flags=re.I)
    return re.sub(r'\s+',' ',s).strip(" -،؟?")

def parse_radius_query(q):
    q=norm(q)
    m=re.search(r'(\d+(?:\.\d+)?)\s*(?:کیلومتر|كيلومتر|km)',q,re.I)
    if not m: return None
    if not re.search(r'(شعاع|فاصله|اطراف|نزدیک|نزديک|radius|within|near)',q,re.I): return None
    radius=float(m.group(1))
    kind="airport" if re.search(r'(فرودگاه|airport|airfield|aerodrome)',q,re.I) else ("runway" if re.search(r'(باند|runway)',q,re.I) else None)
    center=None
    patterns=[
      r'(?:شعاع|فاصله)\s*(?:حداکثر\s*)?\d+(?:\.\d+)?\s*(?:کیلومتر|كيلومتر|km)\s*(?:ی\s*)?(?:از|اطراف|حول)?\s*([^؟?،,.]+)',
      r'(?:در|تا)\s*(?:شعاع\s*)?\d+(?:\.\d+)?\s*(?:کیلومتر|كيلومتر|km)\s*(?:ی\s*)?(?:از|اطراف|حول)?\s*([^؟?،,.]+)',
      r'(?:within|radius)\s+\d+(?:\.\d+)?\s*km\s+(?:of|from)\s+([^?.,]+)',
      r'(?:near)\s+([^?.,]+?)\s+(?:within|radius)\s+\d+(?:\.\d+)?\s*km'
    ]
    for p in patterns:
        x=re.search(p,q,re.I)
        if x: center=clean_center(x.group(1)); break
    return {"intent":"spatial_radius","radius_km":radius,"center":center,"kind":kind}



def extract_country_phrase(q):
    qn=norm(q)
    if "فرودگاه" not in qn: return None
    if re.search(r'(\d+(?:\.\d+)?)\s*(?:کیلومتر|كيلومتر|km)',qn,re.I): return None
    # Strip the word فرودگاه and all common plural/ezafe variants explicitly.
    c=re.sub(r'^.*?فرودگاه','',qn,count=1).strip()
    c=re.sub(r'^(?:‌?های|‌?ها|ی)\s*','',c).strip()
    c=re.sub(r'^کشور\s+','',c).strip()
    c=re.sub(r'\s*(?:را\s+)?(?:روی\s+نقشه\s+)?نشان\s+بده.*$','',c).strip(" ؟?")
    c=re.sub(r'\s*(?:کدامند|کدام‌ها.*|کدام ها.*|هستند.*)$','',c).strip(" ؟?")
    return c or None
