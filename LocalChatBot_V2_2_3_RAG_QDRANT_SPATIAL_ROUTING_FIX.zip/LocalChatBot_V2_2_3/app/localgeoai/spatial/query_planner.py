from __future__ import annotations
import json,re
from app.localgeoai.main import CONFIG,http_json,url


def _extract_json(text):
    m=re.search(r'\{[\s\S]*\}',str(text or ''))
    if not m:return None
    try:return json.loads(m.group(0))
    except:return None

def _call(prompt,max_tokens=220):
    g=CONFIG['services']['generation']
    payload={'model':'local-model','messages':[{'role':'user','content':prompt}], 'temperature':0.0,'max_tokens':max_tokens,
             'reasoning_format':'none','reasoning_effort':'none','chat_template_kwargs':{'enable_thinking':False}}
    r=http_json('POST',url(g['host'],g['port'],'/v1/chat/completions'),payload,120)
    return _extract_json(r.get('choices',[{}])[0].get('message',{}).get('content',''))

def plan_spatial_question(question, spatial):
    """Two-stage, data-driven GIS planner. No country/place answer table is hard-coded."""
    profile=spatial.query_profile(max_values=5000)
    if not profile.get('datasets'):return None
    fields=profile.get('fields',[]); categorical=profile.get('categorical_values',{}); kinds=profile.get('kinds',[])
    # The LLM interprets the full request against the real local schema. No place/country vocabulary is hard-coded.
    p=_call("You are a LOCAL GIS execution planner. Return ONLY JSON. The upstream LLM has determined that GIS execution is required. "
            "Infer the requested feature concept and geographic/category constraint from meaning, not keywords. Never invent a field. "
            "Choose field only from FIELDS and kind only from KINDS. Separate the requested FEATURE TYPE from the geographic/category constraint. "
            "Example semantics: 'airports in X' means kind=airport (if airport exists in KINDS) plus a country/city field constraint for X; do NOT search for X as the feature name. "
            "Return {intent:'spatial_filter',kind:null,field:'...',requested_value:'...',place_text:'...'} or {intent:'none'}. "
            "requested_value may be in the user language. kind may be null only when no matching feature type exists in KINDS.\nQUESTION: "+str(question)+"\nFIELDS: "+json.dumps(fields,ensure_ascii=False)+"\nKINDS: "+json.dumps(kinds,ensure_ascii=False))
    if not p or p.get('intent')!='spatial_filter':return None
    field=str(p.get('field') or '').strip()
    if field not in fields:return None
    requested=str(p.get('requested_value') or p.get('value') or '').strip()
    vals=categorical.get(field)
    value=requested
    if vals:
        # Exact match first; otherwise ask the LLM to map the user's concept to one of REAL values only.
        exact=next((v for v in vals if str(v).casefold()==requested.casefold()),None)
        if exact:value=exact
        else:
            r=_call("Map the requested concept to EXACTLY one value from VALUES. Use your language/geographic knowledge only to interpret the request; "
                    "the output value MUST occur verbatim in VALUES. Return ONLY {\"value\":\"...\"}; if impossible return {\"value\":null}.\n"
                    f"QUESTION: {question}\nREQUESTED: {requested}\nFIELD: {field}\nVALUES: {json.dumps(vals,ensure_ascii=False)}",120)
            value=(r or {}).get('value')
            if value not in vals:return None
    kind=p.get('kind');kind=None if str(kind or '').lower() in ('','null','none','all','auto') else str(kind)
    if kind and kind not in kinds:return None
    plan={'intent':'spatial_filter','kind':kind,'field':field,'value':value,'place_text':str(p.get('place_text') or requested or value)}
    return spatial.validate_plan(plan)
