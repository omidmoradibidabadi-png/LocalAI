from __future__ import annotations
import csv, json, math, re, sqlite3, unicodedata, zipfile, tempfile, shutil
from difflib import SequenceMatcher
from pathlib import Path

ROOT=Path(__file__).resolve().parents[3]
from app.localgeoai.data_paths import DATA_ROOT
DB=DATA_ROOT/"spatial/spatial_catalog.sqlite3"
DB.parent.mkdir(parents=True,exist_ok=True)

NAME_HINTS=("name","name_en","name_fa","name_ar","airport_name","official_name","title","نام","نام_فارسی","نام_انگلیسی")
CODE_HINTS=("iata","icao","iata_code","icao_code","code","ident","gps_code","local_code")
CITY_HINTS=("city","municipality","town","location","شهر")
COUNTRY_HINTS=("country","country_name","iso_country","کشور")
LAT_HINTS=("lat","latitude","latitude_deg","y")
LON_HINTS=("lon","lng","longitude","longitude_deg","x")

def norm(v):
    s=unicodedata.normalize("NFKC",str(v or "")).casefold()
    s=s.replace("ي","ی").replace("ك","ک").replace("ۀ","ه").replace("ة","ه")
    s=re.sub(r"[_\-/.,()]+"," ",s)
    return " ".join(s.split())

def hav(lat1,lon1,lat2,lon2):
    r=6371.0088
    p1,p2=math.radians(lat1),math.radians(lat2)
    dp=math.radians(lat2-lat1); dl=math.radians(lon2-lon1)
    a=math.sin(dp/2)**2+math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    return 2*r*math.asin(math.sqrt(a))

def useful(v):
    if v is None:return False
    s=str(v).strip()
    return bool(s and s.lower() not in {"none","null","nan"})

class SpatialCatalog:
    def __init__(self):
        self.db=sqlite3.connect(DB,check_same_thread=False)
        self.db.execute("""CREATE TABLE IF NOT EXISTS features(
          id INTEGER PRIMARY KEY, dataset TEXT, name TEXT, kind TEXT,
          lon REAL, lat REAL, properties TEXT, source TEXT)""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS aliases(
          feature_id INTEGER, alias TEXT, alias_norm TEXT, alias_type TEXT,
          UNIQUE(feature_id,alias_norm))""")
        self.db.execute("CREATE INDEX IF NOT EXISTS ix_features_name ON features(name)")
        self.db.execute("CREATE INDEX IF NOT EXISTS ix_features_kind ON features(kind)")
        self.db.execute("CREATE INDEX IF NOT EXISTS ix_alias_norm ON aliases(alias_norm)")
        self.db.commit()

    def _schema(self,props):
        keys=list(props.keys())
        lower={str(k).casefold():k for k in keys}
        def match(hints):
            out=[]
            for h in hints:
                if h.casefold() in lower: out.append(lower[h.casefold()])
            return out
        text=[k for k,v in props.items() if useful(v) and isinstance(v,(str,int,float))]
        return {"fields":keys,"name_fields":match(NAME_HINTS),"code_fields":match(CODE_HINTS),
                "city_fields":match(CITY_HINTS),"country_fields":match(COUNTRY_HINTS),"text_fields":text}

    def _identity(self,props,dataset,idx,schema):
        vals=[]
        for k in schema["name_fields"]:
            if useful(props.get(k)): vals.append((str(props[k]).strip(),"name"))
        for k in schema["code_fields"]:
            if useful(props.get(k)): vals.append((str(props[k]).strip(),"code"))
        # Broad alias scan is deliberate: user may search by city, airport code, translated name, etc.
        for k in schema["text_fields"]:
            v=props.get(k)
            if useful(v):
                sv=str(v).strip()
                if 1 < len(sv) <= 160: vals.append((sv,"field:"+str(k)))
        ded=[]; seen=set()
        for v,t in vals:
            n=norm(v)
            if n and n not in seen: seen.add(n); ded.append((v,t))
        canonical=next((v for v,t in ded if t=="name"),None)
        if not canonical: canonical=next((v for v,t in ded if t=="code"),None)
        if not canonical: canonical=f"{dataset}_{idx}"
        return canonical,ded

    def _insert(self,dataset,name,kind,lon,lat,props,source,aliases):
        cur=self.db.execute("INSERT INTO features(dataset,name,kind,lon,lat,properties,source) VALUES(?,?,?,?,?,?,?)",
                        (dataset,name,kind,float(lon),float(lat),json.dumps(props,ensure_ascii=False,default=str),source))
        fid=cur.lastrowid
        aliases=[(name,"canonical"),*aliases]
        for a,t in aliases:
            try:self.db.execute("INSERT OR IGNORE INTO aliases(feature_id,alias,alias_norm,alias_type) VALUES(?,?,?,?)",
                                (fid,str(a),norm(a),t))
            except Exception:pass

    def ingest(self,path:Path,name_field=None,kind="feature"):
        path=path.resolve(); dataset=path.stem
        # Delete an older import of this source without constructing a huge IN(?,?,...)
        # list. This stays below SQLite's host-parameter limit even for 80k+ features.
        self.db.execute(
            "DELETE FROM aliases WHERE feature_id IN (SELECT id FROM features WHERE source=?)",
            (str(path),)
        )
        self.db.execute("DELETE FROM features WHERE source=?",(str(path),))
        count=0; sample=[]; detected=None
        def add(props,lon,lat):
            nonlocal count,detected
            if detected is None: detected=self._schema(props)
            schema=self._schema(props)
            if name_field and name_field in props:
                schema["name_fields"]=[name_field]+[x for x in schema["name_fields"] if x!=name_field]
            canonical,aliases=self._identity(props,dataset,count+1,schema)
            row_kind=kind
            if str(kind or "").strip().lower() in ("","auto"):
                t=str(props.get("type") or props.get("aeroway") or "").strip().lower()
                if any(x in t for x in ("airport","aerodrome","heliport","seaplane","balloonport")):
                    row_kind="airport"
                elif "runway" in t:
                    row_kind="runway"
                elif any(x in t for x in ("aircraft","airplane","aeroplane","plane","helicopter")):
                    row_kind="aircraft"
                else:
                    # Also inspect common category/class fields so a user shapefile can define aircraft
                    # without requiring a special LocalGeoAI schema.
                    blob=" ".join(str(props.get(k) or "") for k in ("category","class","object_type","feature_type","نوع","دسته" )).lower()
                    row_kind="aircraft" if any(x in blob for x in ("aircraft","airplane","aeroplane","plane","helicopter","هواپیما","بالگرد")) else "feature"
            self._insert(dataset,canonical,row_kind,lon,lat,props,str(path),aliases)
            count+=1
            if len(sample)<5:
                sample.append({"name":canonical,"aliases":[a for a,_ in aliases[:8]],"lon":float(lon),"lat":float(lat)})
        ext=path.suffix.lower()
        if ext in {".geojson",".json"}:
            obj=json.loads(path.read_text(encoding="utf-8-sig"))
            def xy_pairs(v):
                if isinstance(v,(list,tuple)):
                    if len(v)>=2 and isinstance(v[0],(int,float)) and isinstance(v[1],(int,float)):
                        yield float(v[0]),float(v[1])
                    else:
                        for z in v: yield from xy_pairs(z)
            for f in obj.get("features",[]):
                g=f.get("geometry") or {}; props=f.get("properties") or {}
                gt=g.get("type"); coords=g.get("coordinates")
                if gt=="Point" and isinstance(coords,(list,tuple)) and len(coords)>=2:
                    add(props,coords[0],coords[1]); continue
                pts=list(xy_pairs(coords))
                if pts:
                    xs=[p[0] for p in pts]; ys=[p[1] for p in pts]
                    props=dict(props); props["_source_geometry_type"]=gt
                    add(props,(min(xs)+max(xs))/2.0,(min(ys)+max(ys))/2.0)
        elif ext==".csv":
            with open(path,"r",encoding="utf-8-sig",newline="") as fh:
                for row in csv.DictReader(fh):
                    keys={str(k).casefold():k for k in row}
                    latk=next((keys[x] for x in LAT_HINTS if x in keys),None)
                    lonk=next((keys[x] for x in LON_HINTS if x in keys),None)
                    if not latk or not lonk: raise ValueError("CSV needs latitude/longitude columns.")
                    add(row,row[lonk],row[latk])
        else:
            read_path=path; tmpdir=None
            # KMZ is a ZIP container. Extract locally so GDAL/OGR does not depend on a virtual-file driver.
            if ext==".kmz":
                tmpdir=Path(tempfile.mkdtemp(prefix="lcb_kmz_"))
                try:
                    with zipfile.ZipFile(path) as z: z.extractall(tmpdir)
                    kmls=sorted(tmpdir.rglob("*.kml"))
                    if not kmls: raise ValueError("KMZ contains no KML document.")
                    read_path=kmls[0]
                except Exception:
                    shutil.rmtree(tmpdir,ignore_errors=True); raise
            if ext==".shp":
                missing=[x for x in (path.with_suffix('.shx'),path.with_suffix('.dbf')) if not x.is_file()]
                if missing: raise ValueError("Shapefile is incomplete; .SHP requires matching .SHX and .DBF files in the same folder.")
            try:
                import geopandas as gpd
                try: gdf=gpd.read_file(read_path,engine="pyogrio")
                except Exception: gdf=gpd.read_file(read_path)
            except ImportError: raise RuntimeError("Vector GIS support needs GeoPandas/Pyogrio. Run 00_INSTALL_UNIVERSAL_DEPS.bat.")
            finally:
                pass
            try:
                # KML is WGS84 by specification; some readers return no CRS metadata.
                if gdf.crs is None and str(read_path).lower().endswith('.kml'): gdf=gdf.set_crs(4326,allow_override=True)
                if gdf.crs is None: raise ValueError("Vector dataset has no CRS; define/georeference it before spatial indexing.")
                gdf=gdf.to_crs(4326)
                for _,r in gdf.iterrows():
                    geom=r.geometry
                    if geom is None or geom.is_empty:continue
                    if geom.geom_type!="Point":geom=geom.representative_point()
                    props={k:v for k,v in r.items() if k!="geometry"}
                    add(props,geom.x,geom.y)
            finally:
                if tmpdir: shutil.rmtree(tmpdir,ignore_errors=True)
        self.db.commit()
        detected=detected or {"fields":[],"name_fields":[],"code_fields":[],"city_fields":[],"country_fields":[]}
        return {"dataset":dataset,"count":count,"source":str(path),"schema":detected,"sample":sample}

    def source_count(self,path):
        """Number of currently indexed spatial features for one physical source file."""
        try:
            src=str(Path(path).resolve())
            row=self.db.execute("SELECT COUNT(*) FROM features WHERE source=?",(src,)).fetchone()
            return int((row or [0])[0] or 0)
        except Exception:
            return 0

    def datasets(self):
        return [{"dataset":r[0],"count":r[1]} for r in self.db.execute(
            "SELECT dataset,COUNT(*) FROM features GROUP BY dataset ORDER BY dataset")]

    def resolve(self,q,kind=None,limit=20):
        nq=norm(q); args=[nq,nq,nq+"%", "%"+nq+"%"]
        kind_sql=""
        if kind:
            kind_sql=" AND lower(f.kind)=lower(?)"; args.append(kind)
        sql=f"""SELECT DISTINCT f.id,f.dataset,f.name,f.kind,f.lon,f.lat,f.properties,f.source,
          CASE WHEN a.alias_norm=? THEN 100
               WHEN lower(f.name)=? THEN 98
               WHEN a.alias_norm LIKE ? THEN 90
               WHEN a.alias_norm LIKE ? THEN 75 ELSE 0 END AS rank
          FROM aliases a JOIN features f ON f.id=a.feature_id
          WHERE (a.alias_norm=? OR lower(f.name)=? OR a.alias_norm LIKE ? OR a.alias_norm LIKE ?){kind_sql}
          ORDER BY rank DESC,length(f.name) LIMIT ?"""
        # query placeholders repeated for WHERE
        qargs=[nq,nq,nq+"%","%"+nq+"%",nq,nq,nq+"%","%"+nq+"%"]
        if kind:qargs.append(kind)
        qargs.append(limit)
        rows=self.db.execute(sql,qargs).fetchall()
        return [dict(self._row(r[:8]),match_score=r[8]) for r in rows]

    def find_by_alias(self,q,kind=None,limit=1000):
        nq=norm(q)
        sql="""SELECT DISTINCT f.id,f.dataset,f.name,f.kind,f.lon,f.lat,f.properties,f.source
               FROM aliases a JOIN features f ON f.id=a.feature_id WHERE a.alias_norm=?"""
        args=[nq]
        if kind:
            sql+=" AND lower(f.kind)=lower(?)"; args.append(kind)
        sql+=" ORDER BY f.name LIMIT ?"; args.append(int(limit))
        return [self._row(r) for r in self.db.execute(sql,args).fetchall()]

    def query_profile(self,max_values=260):
        """Expose only real local schema/value inventory to the LLM planner; no country/place tables are hard-coded."""
        datasets=[]; values={}; fields=set()
        for r in self.db.execute("SELECT dataset,kind,properties FROM features"):
            ds,kind,raw=r
            try: props=json.loads(raw or '{}')
            except Exception: continue
            fields.update(map(str,props.keys()))
            schema=self._schema(props)
            for f in schema.get('country_fields',[])+schema.get('city_fields',[]):
                v=props.get(f)
                if useful(v): values.setdefault(str(f),set()).add(str(v).strip())
        for d in self.datasets(): datasets.append(d)
        kinds=[str(r[0]) for r in self.db.execute("SELECT DISTINCT kind FROM features WHERE kind IS NOT NULL AND trim(kind)<>''").fetchall()]
        return {'datasets':datasets,'fields':sorted(fields)[:300],'kinds':sorted(set(kinds)),
                'categorical_values':{k:sorted(v)[:max_values] for k,v in values.items()}}

    def validate_plan(self,plan):
        field=str(plan.get('field') or '').strip(); value=str(plan.get('value') or '').strip()
        prof=self.query_profile()
        if not field or field not in prof.get('fields',[]): return None
        vals=prof.get('categorical_values',{}).get(field)
        if vals is not None and value not in vals: return None
        kind=plan.get('kind'); kind=None if str(kind or '').lower() in ('','null','none','all','auto') else str(kind)
        return {'intent':'spatial_filter','kind':kind,'field':field,'value':value,'place_text':str(plan.get('place_text') or value)}

    def filter_property(self,field,value,kind=None,limit=5000):
        out=[]; target=norm(value)
        sql="SELECT id,dataset,name,kind,lon,lat,properties,source FROM features"
        args=[]
        if kind: sql+=" WHERE lower(kind)=lower(?)"; args=[kind]
        for r in self.db.execute(sql,args):
            x=self._row(r); p=x.get('properties') or {}
            if field not in p or norm(p.get(field))!=target: continue
            out.append(x)
            if len(out)>=int(limit): break
        return out

    def features_in_country(self,country_code,kind=None,limit=5000):
        code=str(country_code or "").strip().upper()
        rows=self.find_by_alias(code,kind=kind,limit=limit)
        if rows: return rows
        out=[]
        for r in self.db.execute("SELECT id,dataset,name,kind,lon,lat,properties,source FROM features").fetchall():
            x=self._row(r); p=x.get("properties") or {}
            if str(p.get("iso_country") or "").strip().upper()!=code: continue
            if kind and str(x.get("kind") or "").lower()!=str(kind).lower(): continue
            out.append(x)
            if len(out)>=limit: break
        return out

    def nearby(self,lat,lon,radius_km,kind=None,limit=200):
        dlat=radius_km/110.574
        dlon=radius_km/(111.320*max(0.15,math.cos(math.radians(lat))))
        sql="SELECT id,dataset,name,kind,lon,lat,properties,source FROM features WHERE lat BETWEEN ? AND ? AND lon BETWEEN ? AND ?"
        args=[lat-dlat,lat+dlat,lon-dlon,lon+dlon]
        if kind:sql+=" AND lower(kind)=lower(?)";args.append(kind)
        out=[]
        for r in self.db.execute(sql,args):
            x=self._row(r);d=hav(lat,lon,x["lat"],x["lon"])
            if d<=radius_km:x["distance_km"]=round(d,3);out.append(x)
        out.sort(key=lambda x:x["distance_km"]);return out[:limit]

    def related(self,terms,kind=None,limit=500):
        """Find locally indexed features linked by airport/name/code fields, without a fixed schema."""
        needles=[norm(x) for x in (terms or []) if norm(x)]
        if not needles:return []
        sql="SELECT id,dataset,name,kind,lon,lat,properties,source FROM features"
        args=[]
        if kind:sql+=" WHERE lower(kind)=lower(?)";args=[kind]
        out=[]
        for r in self.db.execute(sql,args):
            x=self._row(r); props=x.get("properties") or {}
            hay=norm(" ".join([x.get("name",''),x.get("dataset",''),*map(str,props.values())]))
            if any(n in hay for n in needles):
                out.append(x)
                if len(out)>=limit:break
        return out

    def stats(self):
        total=self.db.execute("SELECT COUNT(*) FROM features").fetchone()[0]
        airports=self.db.execute("SELECT COUNT(*) FROM features WHERE lower(kind)='airport'").fetchone()[0]
        return {"features":total,"airports":airports,"datasets":self.datasets()}

    @staticmethod
    def _row(r):
        return {"id":r[0],"dataset":r[1],"name":r[2],"kind":r[3],"lon":r[4],"lat":r[5],
                "properties":json.loads(r[6] or "{}"),"source":r[7]}

    @staticmethod
    def geojson(rows,center=None,radius_km=None):
        fs=[]
        if center:fs.append({"type":"Feature","geometry":{"type":"Point","coordinates":[center["lon"],center["lat"]]},
            "properties":{"role":"center","name":center.get("name","Center")}})
        for x in rows:
            p={"name":x["name"],"kind":x["kind"],"distance_km":x.get("distance_km"),"role":"candidate"}
            fs.append({"type":"Feature","geometry":{"type":"Point","coordinates":[x["lon"],x["lat"]]},"properties":p})
        return {"type":"FeatureCollection","features":fs,"meta":{"radius_km":radius_km}}

    def close(self):
        """Release the persistent SQLite handle (important on Windows)."""
        db=getattr(self,"db",None)
        if db is not None:
            try: db.commit()
            except Exception: pass
            try: db.close()
            except Exception: pass
            self.db=None
