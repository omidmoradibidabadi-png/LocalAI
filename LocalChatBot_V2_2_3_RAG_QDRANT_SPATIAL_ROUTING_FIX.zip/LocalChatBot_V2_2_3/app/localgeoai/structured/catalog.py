from __future__ import annotations
from pathlib import Path
import csv, json, re, sqlite3

ROOT=Path(__file__).resolve().parents[3]
from app.localgeoai.data_paths import DATA_ROOT
DB=DATA_ROOT/"structured/technical_catalog.sqlite3"
DB.parent.mkdir(parents=True,exist_ok=True)

ALIASES={
 "range":["range","range_km","max_range","maximum_range","ferry_range","flight_range","برد"],
 "endurance":["endurance","endurance_hours","flight_endurance","duration_hours","مداومت"],
 "speed":["cruise_speed","cruise_speed_kmh","speed","max_speed","speed_kmh","سرعت"],
 "payload":["payload","payload_kg","max_payload","بار","محموله"],
 "capacity":["capacity","passengers","passenger_capacity","seats","ظرفیت"],
 "fuel":["fuel","fuel_capacity","fuel_l","fuel_kg","سوخت"],
 "ceiling":["ceiling","service_ceiling","ceiling_m","ceiling_ft","سقف"]
}
PERSIAN={"برد":"range","مداومت":"endurance","سرعت":"speed","محموله":"payload","بار":"payload",
         "ظرفیت":"capacity","سوخت":"fuel","سقف":"ceiling"}

def norm(s):
    s=str(s or "").casefold().replace("ي","ی").replace("ك","ک")
    return re.sub(r"[^0-9a-zآ-ی]+","_",s).strip("_")

def number(v):
    if v is None:return None
    x=str(v).replace(",","").translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹","0123456789"))
    m=re.search(r"-?\d+(?:\.\d+)?",x)
    return float(m.group()) if m else None

class StructuredCatalog:
    def __init__(self):
        self.db=sqlite3.connect(DB,check_same_thread=False)
        self.db.execute("""CREATE TABLE IF NOT EXISTS rows(
          id INTEGER PRIMARY KEY AUTOINCREMENT, source TEXT, row_no INTEGER, data TEXT)""")
        self.db.execute("CREATE INDEX IF NOT EXISTS ix_rows_source ON rows(source)")
        self.db.commit()

    def _records(self,path):
        ext=path.suffix.lower()
        if ext==".csv":
            with open(path,"r",encoding="utf-8-sig",errors="replace",newline="") as f:
                yield from csv.DictReader(f)
        elif ext==".json":
            obj=json.loads(path.read_text(encoding="utf-8-sig",errors="replace"))
            if isinstance(obj,list):
                for x in obj:
                    if isinstance(x,dict): yield x
            elif isinstance(obj,dict):
                # GeoJSON is spatial, not technical structured data.
                if obj.get("type")=="FeatureCollection": return
                yield obj
        elif ext==".xlsx":
            from openpyxl import load_workbook
            wb=load_workbook(path,read_only=True,data_only=True)
            for ws in wb.worksheets:
                it=ws.iter_rows(values_only=True)
                try: heads=[str(x or "").strip() for x in next(it)]
                except StopIteration: continue
                for row in it:
                    yield {heads[i] or f"col{i+1}":v for i,v in enumerate(row)}
    def ingest(self,path):
        path=Path(path).resolve()
        if path.suffix.lower() not in (".csv",".json",".xlsx"): return 0
        src=str(path)
        self.db.execute("DELETE FROM rows WHERE source=?",(src,))
        n=0
        for n,row in enumerate(self._records(path),1):
            self.db.execute("INSERT INTO rows(source,row_no,data) VALUES(?,?,?)",
                            (src,n,json.dumps(row,ensure_ascii=False,default=str)))
            if n%1000==0:self.db.commit()
        self.db.commit(); return n

    def _field(self,headers,concept):
        nh={norm(h):h for h in headers}
        for a in ALIASES.get(concept,[]):
            na=norm(a)
            if na in nh:return nh[na]
        for h in headers:
            z=norm(h)
            if any(norm(a) in z or z in norm(a) for a in ALIASES.get(concept,[]) if len(norm(a))>3):
                return h
        return None

    def query(self,q,limit=100):
        qt=str(q).translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹","0123456789"))
        concept=None
        for fa,c in PERSIAN.items():
            if fa in qt: concept=c; break
        if not concept:
            for c,als in ALIASES.items():
                if any(re.search(r"\b"+re.escape(a)+r"\b",qt,re.I) for a in als if a.isascii()):
                    concept=c;break
        if not concept:return None
        m=re.search(r"(?:زیر|کمتر\s+از|کمتر|حداکثر|تا|<)\s*(\d+(?:\.\d+)?)",qt)
        op="<=" if m else None
        if not m:
            m=re.search(r"(?:بیشتر\s+از|بالاتر\s+از|حداقل|>)\s*(\d+(?:\.\d+)?)",qt)
            op=">=" if m else None
        if not m:
            # also accept "برد 3000" only as equality-like proximity is unsafe -> leave to RAG
            return None
        target=float(m.group(1))
        allrows=self.db.execute("SELECT source,row_no,data FROM rows").fetchall()
        out=[]; field_used=None
        for src,rowno,raw in allrows:
            try:r=json.loads(raw)
            except:continue
            field=self._field(list(r.keys()),concept)
            if not field:continue
            v=number(r.get(field))
            if v is None:continue
            ok=(v<=target) if op=="<=" else (v>=target)
            if ok:
                field_used=field
                out.append({"source":Path(src).name,"row_no":rowno,"field":field,"value":v,"data":r})
                if len(out)>=limit:break
        return {"concept":concept,"operator":op,"target":target,"field":field_used,"rows":out}

    def _all(self):
        for src,rowno,raw in self.db.execute("SELECT source,row_no,data FROM rows"):
            try: yield src,rowno,json.loads(raw)
            except Exception: continue

    def fast_lookup(self,q,limit=80):
        """Schema-agnostic fast path. Avoids LLM for most questions over CSV/JSON/XLSX."""
        qt=str(q or "").translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹","0123456789"))
        qn=norm(qt)
        rows=list(self._all())
        if not rows:return None

        # Generic numeric condition: infer target column from words immediately before comparator.
        cm=re.search(r'(.{1,45}?)(زیر|کمتر\s+از|بیشتر\s+از|بالاتر\s+از|حداقل|حداکثر|تا)\s*(\d+(?:\.\d+)?)',qt)
        if cm:
            phrase=norm(cm.group(1)).split("_")
            opword=cm.group(2); target=float(cm.group(3))
            less=opword in ("زیر","کمتر از","حداکثر","تا")
            # score every numeric-capable field by overlap with query tokens
            headers=[]
            for _,_,r in rows[:100]:
                headers.extend(r.keys())
            headers=list(dict.fromkeys(headers))
            stop={"هواپیما","هواپیماها","با","دارای","که","چه","کدام","کدامند","از","و"}
            toks=[x for x in phrase if x and x not in stop]
            scored=[]
            for hd in headers:
                hn=norm(hd)
                score=sum(3 for t in toks if t==hn)+sum(1 for t in toks if len(t)>2 and t in hn)
                # known semantic aliases
                for concept,als in ALIASES.items():
                    if any(norm(a) in qn for a in als) and any(norm(a)==hn or norm(a) in hn for a in als):
                        score+=10
                if score: scored.append((score,hd))
            scored.sort(reverse=True)
            for _,field in scored:
                out=[]
                for src,rowno,r in rows:
                    v=number(r.get(field))
                    if v is None:continue
                    if (v<=target if less else v>=target):
                        out.append({"source":Path(src).name,"row_no":rowno,"field":field,"value":v,"data":r})
                        if len(out)>=limit:break
                if out:
                    return {"mode":"numeric","concept":field,"operator":"<=" if less else ">=",
                            "target":target,"field":field,"rows":out}

        # Entity/model lookup. Match distinctive tokens against all cell values.
        words=[x for x in re.findall(r'[A-Za-z0-9][A-Za-z0-9._+\-/]*',qt) if len(x)>=2]
        # include Persian tokens but remove question boilerplate
        pwords=[x for x in re.findall(r'[آ-ی]{3,}',qt) if x not in
                {"هواپیما","هواپیماهای","مشخصات","فنی","چیست","چقدر","کدام","کدامند","میزان","نوع","دارد","است"}]
        tokens=words+pwords
        if tokens:
            matches=[]
            for src,rowno,r in rows:
                blob=norm(" ".join(str(v) for v in r.values() if v not in (None,"")))
                score=sum(1 for t in tokens if norm(t) and norm(t) in blob)
                if score:
                    matches.append((score,src,rowno,r))
            if matches:
                matches.sort(key=lambda x:-x[0]); best=matches[0][0]
                chosen=[x for x in matches if x[0]==best][:min(limit,20)]
                return {"mode":"entity","rows":[{"source":Path(s).name,"row_no":rn,"data":r}
                                                for _,s,rn,r in chosen]}

        return None

    def format_fast(self,result,question=None):
        rows=result.get("rows",[])
        if result.get("mode")=="numeric":
            return self.format_answer(result)
        if result.get("mode")=="entity":
            blocks=[]
            for x in rows[:8]:
                r=x["data"]
                # Keep only useful, populated fields; never dump the whole database row.
                preferred=("manufacturer","model","family","aircraft_type","role","engine_count","engine_type",
                           "maximum_seating","typical_seating","mtow_kg","range_km","range_nm",
                           "cruise_mach","cruise_speed_kmh","endurance_hours","payload_kg",
                           "fuel_capacity","service_ceiling","source_title")
                vals=[]
                for key in preferred:
                    for k,v in r.items():
                        if norm(k)==norm(key) and v not in (None,""):
                            vals.append((k,v)); break
                if not vals:
                    vals=[(k,v) for k,v in r.items() if v not in (None,"")][:12]
                name=next((str(v) for k,v in r.items()
                           if norm(k) in ("name","model","aircraft","aircraft_name","title","نام","مدل")
                           and v not in (None,"")),f"ردیف {x['row_no']}")
                detail=" | ".join(f"{k}: {v}" for k,v in vals[:12])
                blocks.append(f"• {name}: {detail} [{x['source']}، ردیف {x['row_no']}]")
            return "بر اساس رکوردهای مرتبط در بانک محلی:\n\n"+"\n".join(blocks)
        return None

    def format_answer(self,result):
        rows=result["rows"]; fld=result.get("field") or result["concept"]
        if not rows:
            return f"در داده‌های ساخت‌یافته محلی، رکوردی مطابق شرط روی «{fld}» پیدا نشد."
        names=[]
        for x in rows:
            r=x["data"]
            name=next((str(r[k]) for k in r if norm(k) in ("name","aircraft","aircraft_name","model","type","نام","مدل") and r[k] not in (None,"")),None)
            if not name:
                name=next((str(v) for v in r.values() if v not in (None,"")),f"ردیف {x['row_no']}")
            names.append(f"• {name} — {fld}: {x['value']:g}  [{x['source']}، ردیف {x['row_no']}]")
        more="" if len(rows)<100 else "\n(نمایش به 100 نتیجه اول محدود شده است.)"
        return f"{len(rows)} رکورد مطابق شرط پیدا شد:\n\n"+"\n".join(names)+more

    def close(self):
        """Release the persistent SQLite handle (important on Windows)."""
        db=getattr(self,"db",None)
        if db is not None:
            try: db.commit()
            except Exception: pass
            try: db.close()
            except Exception: pass
            self.db=None
