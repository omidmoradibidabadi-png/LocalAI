from __future__ import annotations
import re, unicodedata

_TRANS=str.maketrans({
    'ي':'ی','ى':'ی','ئ':'ی','ك':'ک','ۀ':'ه','ة':'ه','ؤ':'و','إ':'ا','أ':'ا','ٱ':'ا',
    '٠':'0','١':'1','٢':'2','٣':'3','٤':'4','٥':'5','٦':'6','٧':'7','٨':'8','٩':'9',
    '۰':'0','۱':'1','۲':'2','۳':'3','۴':'4','۵':'5','۶':'6','۷':'7','۸':'8','۹':'9',
})
_ARABIC_MARKS=re.compile(r'[\u064b-\u065f\u0670\u06d6-\u06ed]')

def normalize_search_text(text:str)->str:
    s=unicodedata.normalize('NFKC',str(text or '')).translate(_TRANS)
    s=_ARABIC_MARKS.sub('',s).replace('\u200c',' ').replace('\u200d',' ').replace('\ufeff',' ')
    s=re.sub(r'[\t\r\n]+',' ',s); s=re.sub(r'\s+',' ',s)
    return s.strip()

def query_variants(text:str):
    original=str(text or '').strip(); norm=normalize_search_text(original)
    out=[]
    for x in (original,norm):
        if x and x not in out: out.append(x)
    return out
