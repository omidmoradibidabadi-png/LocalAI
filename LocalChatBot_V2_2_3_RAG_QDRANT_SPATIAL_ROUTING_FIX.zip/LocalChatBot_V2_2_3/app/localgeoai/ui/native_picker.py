from pathlib import Path
import json,sys,subprocess,os
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'data/.picker_result.json'
mode=sys.argv[1] if len(sys.argv)>1 else 'document'
is_folder=mode in ('folder','document_folder')
if is_folder:
    title='Select local data folder'; filt=''
    dialog="$owner=New-Object System.Windows.Forms.Form; $owner.ShowInTaskbar=$false; $owner.FormBorderStyle='FixedToolWindow'; $owner.StartPosition='CenterScreen'; $owner.Size=New-Object System.Drawing.Size(1,1); $owner.TopMost=$true; $owner.Opacity=0; $owner.Show(); $owner.Activate(); $owner.BringToFront(); $d=New-Object System.Windows.Forms.FolderBrowserDialog; $d.Description=$env:PICKER_TITLE; $d.ShowNewFolderButton=$false; $r=$d.ShowDialog($owner); $owner.Close(); $owner.Dispose(); if($r -eq [System.Windows.Forms.DialogResult]::OK){[Console]::Out.Write($d.SelectedPath)}"
elif mode=='spatial_file':
    title='Select local GIS file'
    filt='GIS files|*.shp;*.kmz;*.kml;*.geojson;*.json;*.gpkg|Shapefile|*.shp|KMZ/KML|*.kmz;*.kml|GeoJSON|*.geojson;*.json|GeoPackage|*.gpkg|All files|*.*'
    dialog="$d=New-Object System.Windows.Forms.OpenFileDialog; $d.Title=$env:PICKER_TITLE; $d.Filter=$env:PICKER_FILTER; $d.Multiselect=$false; $owner=New-Object System.Windows.Forms.Form; $owner.ShowInTaskbar=$false; $owner.FormBorderStyle='FixedToolWindow'; $owner.StartPosition='CenterScreen'; $owner.Size=New-Object System.Drawing.Size(1,1); $owner.TopMost=$true; $owner.Opacity=0; $owner.Show(); $owner.Activate(); $owner.BringToFront(); $r=$d.ShowDialog($owner); $owner.Close(); $owner.Dispose(); if($r -eq [System.Windows.Forms.DialogResult]::OK){[Console]::Out.Write($d.FileName)}"
else:
    title='Select local data file'
    filt='Local data|*.pdf;*.docx;*.doc;*.pptx;*.txt;*.md;*.csv;*.json;*.xlsx;*.xls;*.html;*.htm;*.rtf;*.eml;*.msg;*.tif;*.tiff;*.jp2;*.png;*.jpg;*.jpeg;*.geojson;*.shp;*.gpkg;*.kml;*.kmz|All files|*.*'
    dialog="$d=New-Object System.Windows.Forms.OpenFileDialog; $d.Title=$env:PICKER_TITLE; $d.Filter=$env:PICKER_FILTER; $d.Multiselect=$false; $owner=New-Object System.Windows.Forms.Form; $owner.ShowInTaskbar=$false; $owner.FormBorderStyle='FixedToolWindow'; $owner.StartPosition='CenterScreen'; $owner.Size=New-Object System.Drawing.Size(1,1); $owner.TopMost=$true; $owner.Opacity=0; $owner.Show(); $owner.Activate(); $owner.BringToFront(); $r=$d.ShowDialog($owner); $owner.Close(); $owner.Dispose(); if($r -eq [System.Windows.Forms.DialogResult]::OK){[Console]::Out.Write($d.FileName)}"
ps="Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing; "+dialog
env=dict(os.environ);env['PICKER_TITLE']=title;env['PICKER_FILTER']=filt
cmd=['powershell.exe','-NoProfile','-STA','-ExecutionPolicy','Bypass','-Command',ps]
r=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',errors='replace',env=env)
if r.returncode!=0:
    raise RuntimeError((r.stderr or r.stdout or 'Windows picker failed').strip())
OUT.parent.mkdir(parents=True,exist_ok=True)
OUT.write_text(json.dumps({'path':r.stdout.strip()},ensure_ascii=False),encoding='utf-8')
