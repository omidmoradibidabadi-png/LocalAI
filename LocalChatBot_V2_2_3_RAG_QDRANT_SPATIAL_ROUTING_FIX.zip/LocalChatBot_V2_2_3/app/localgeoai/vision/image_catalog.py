from pathlib import Path
from app.localgeoai.data_paths import DATA_ROOT
import sqlite3,json,hashlib
class ImageCatalog:
 def __init__(self,root):
  self.root=Path(root)
  self.db=DATA_ROOT/'image_catalog.sqlite';self.db.parent.mkdir(parents=True,exist_ok=True);self._init()
 def _run(self,sql,args=(),fetch=False):
  c=sqlite3.connect(self.db)
  try:
   cur=c.execute(sql,args);rows=cur.fetchall() if fetch else None;cur.close();c.commit();return rows
  finally:c.close()
 def _init(self):self._run('CREATE TABLE IF NOT EXISTS images(id TEXT PRIMARY KEY,path TEXT UNIQUE,format TEXT,lat REAL,lon REAL,capture_time TEXT,width INTEGER,height INTEGER,exif TEXT,ocr TEXT)')
 def close(self):return None
 def ingest(self,path):
  p=Path(path);lat=lon=None;ex={};w=h=None;cap='';ocr='';fmt=''
  try:
   from PIL import Image,ExifTags
   with Image.open(p) as im:
    fmt=str(im.format or '');w,h=im.size;raw=im.getexif();ex={ExifTags.TAGS.get(k,str(k)):str(v) for k,v in raw.items()};cap=ex.get('DateTimeOriginal') or ex.get('DateTime','')
    gps=raw.get(34853)
    if gps:
     def cv(v):return float(v[0])+float(v[1])/60+float(v[2])/3600
     lat=cv(gps[2]);lon=cv(gps[4]);lat=-lat if str(gps[1])=='S' else lat;lon=-lon if str(gps[3])=='W' else lon
    # OCR is intentionally handled by the central ingestion OCR engine.
    # Keeping it out of the catalog avoids a second OCR pass and language mismatch.
  except Exception as e:raise RuntimeError('Image codec/parser could not open file: '+str(e))
  i=hashlib.sha256(p.read_bytes()).hexdigest();self._run('INSERT OR REPLACE INTO images VALUES(?,?,?,?,?,?,?,?,?,?)',(i,str(p.resolve()),fmt,lat,lon,cap,w,h,json.dumps(ex,ensure_ascii=False),ocr))
  return {'id':i,'format':fmt,'lat':lat,'lon':lon,'width':w,'height':h,'ocr_chars':len(ocr)}

 def nearby(self,lat,lon,radius_km=15,limit=200):
  import math
  rows=self._run('SELECT id,path,lat,lon,capture_time,ocr FROM images WHERE lat IS NOT NULL AND lon IS NOT NULL',fetch=True)
  out=[]
  for r in rows:
   p1,p2=math.radians(lat),math.radians(r[2]);dp=math.radians(r[2]-lat);dl=math.radians(r[3]-lon)
   a=math.sin(dp/2)**2+math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2;d=2*6371.0088*math.asin(math.sqrt(a))
   if d<=radius_km:out.append({'id':r[0],'path':r[1],'lat':r[2],'lon':r[3],'capture_time':r[4],'ocr':(r[5] or '')[:300],'distance_km':round(d,3)})
  return sorted(out,key=lambda x:x['distance_km'])[:limit]
 def geojson(self):
  rows=self._run('SELECT id,path,lat,lon,capture_time,ocr FROM images WHERE lat IS NOT NULL AND lon IS NOT NULL',fetch=True)
  return {'type':'FeatureCollection','features':[{'type':'Feature','geometry':{'type':'Point','coordinates':[r[3],r[2]]},'properties':{'id':r[0],'path':r[1],'capture_time':r[4],'ocr':r[5][:300]}} for r in rows]}
