from __future__ import annotations
import asyncio, sys
from app.bootstrap import ApplicationBootstrapper
from app.config.settings import Settings
from app.core.logging import configure_logging

async def async_main() -> int:
    settings = Settings.load()
    configure_logging(settings)
    app = ApplicationBootstrapper(settings)
    try:
        await app.initialize()
        await app.run()
        return 0
    except KeyboardInterrupt:
        return 0
    except Exception:
        app.logger.exception("Fatal application error")
        return 1
    finally:
        await app.shutdown()

def main() -> None:
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
    raise SystemExit(asyncio.run(async_main()))

if __name__ == "__main__":
    main()
