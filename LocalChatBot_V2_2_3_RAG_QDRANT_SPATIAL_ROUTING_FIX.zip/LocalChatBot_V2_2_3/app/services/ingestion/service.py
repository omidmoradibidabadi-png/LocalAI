from pathlib import Path
from app.infrastructure.parsers.pdf import PdfParser

class IngestionService:
    def __init__(self, embedding, vector): self.embedding=embedding; self.vector=vector; self.parsers={".pdf":PdfParser()}
    async def ingest(self, path: Path) -> dict:
        parser=self.parsers.get(path.suffix.lower())
        if not parser: raise ValueError(f"Unsupported file type: {path.suffix}")
        chunks=parser.parse(path)
        if not chunks: return {"file":str(path),"chunks":0,"status":"no_text"}
        vectors=await self.embedding.embed([c.text for c in chunks])
        await self.vector.upsert_chunks(chunks,vectors)
        return {"file":str(path),"chunks":len(chunks),"status":"indexed"}
