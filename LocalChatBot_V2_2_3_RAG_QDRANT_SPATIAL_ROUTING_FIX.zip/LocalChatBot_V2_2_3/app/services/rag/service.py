from app.domain.models import Answer

class RagService:
    def __init__(self, llm, embedding, vector): self.llm=llm; self.embedding=embedding; self.vector=vector
    async def ask(self, question: str, limit: int=8) -> Answer:
        qv=(await self.embedding.embed([question]))[0]
        hits=await self.vector.search(qv,limit)
        context="\n\n".join(f"[S{i}] {h.source} page={h.page}\n{h.text}" for i,h in enumerate(hits,1))
        prompt=f'''You are the LocalGeoAI evidence assistant. Answer ONLY from the supplied local evidence. If evidence is insufficient, say so explicitly. Do not invent facts. Cite evidence inline using [S1], [S2], etc.\n\nQUESTION:\n{question}\n\nLOCAL EVIDENCE:\n{context}\n\nANSWER:'''
        text=await self.llm.generate(prompt,max_tokens=1200,temperature=0.1)
        return Answer(text,hits)
