import sys,tempfile,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from app.localgeoai.ingestion.email_parser import parse_eml
from app.localgeoai.ingestion.registry import classify,capabilities
from app.localgeoai.enterprise.hybrid_router import classify as route,rrf
from app.localgeoai.vision.model_lab import VisualModelLab
from app.localgeoai.vision.image_catalog import ImageCatalog

def main():
 with tempfile.TemporaryDirectory() as td:
  p=Path(td)/'x.eml';p.write_bytes(b'From: a@example.com\nTo: b@example.com\nSubject: Project X\nDate: Thu, 1 Jan 2026 10:00:00 +0000\nMessage-ID: <x@a>\nContent-Type: text/plain; charset=utf-8\n\nTechnical project body')
  m,b=parse_eml(p);assert m['subject']=='Project X' and 'Technical' in b and m['message_id']=='<x@a>'
  assert classify(p)=='email';assert route('ایمیل های سال 2026 درباره پروژه X') in ('elastic','hybrid')
  assert route('برد بیشتر از 5000')=='structured';assert route('روی نقشه در شعاع 50 کیلومتر')=='spatial'
  lab=VisualModelLab(td);x=lab.create_class('A320-family');assert x['id'] and lab.status()[0]['reference_count']==0
  cat=ImageCatalog(td);assert cat.geojson()['type']=='FeatureCollection';cat.close()
  z=rrf({'a':[{'id':'1'},{'id':'2'}],'b':[{'id':'2'}]});assert z[0]['id']=='2'
 print('V6 unit tests: PASS');print('Capabilities:',capabilities())
if __name__=='__main__':main()
