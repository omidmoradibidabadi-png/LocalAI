from pathlib import Path
import sys,tempfile,json,zipfile
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from app.localgeoai.ingestion.registry import classify,supported
from app.localgeoai.ingestion.universal_parser import parse
from app.localgeoai.ingestion.email_parser import parse_eml
from app.localgeoai.ingestion.archive_engine import extract

def main():
 assert classify('a.pdf')=='document';assert classify('a.shp')=='spatial';assert classify('a.tif')=='raster';assert classify('a.jp2')=='raster';assert classify('a.msg')=='email';assert classify('a.zip')=='archive';assert len(supported())>90
 with tempfile.TemporaryDirectory() as d:
  d=Path(d);(d/'a.txt').write_text('hello world',encoding='utf-8');assert parse(d/'a.txt')[0][1]=='hello world'
  (d/'a.json').write_text(json.dumps([{'x':1}]),encoding='utf-8');assert '"x": 1' in parse(d/'a.json')[0][1]
  em=d/'x.eml';em.write_text('Subject: Test\nFrom: a@b.com\nTo: c@d.com\nContent-Type: text/plain; charset=utf-8\n\nhello email',encoding='utf-8');m,b=parse_eml(em);assert m['subject']=='Test' and 'hello email' in b
  z=d/'x.zip';
  with zipfile.ZipFile(z,'w') as q:q.writestr('inside/readme.txt','ok')
  out=extract(z,d/'unz');assert len(out)==1 and out[0].read_text()=='ok'
 print('V6.1 universal tests: PASS');print('Supported extensions:',len(supported()))
if __name__=='__main__':main()
