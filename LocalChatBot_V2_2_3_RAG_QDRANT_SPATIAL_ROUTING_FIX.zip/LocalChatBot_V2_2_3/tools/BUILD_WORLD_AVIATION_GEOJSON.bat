@echo off
setlocal
cd /d "%~dp0.."
if exist "runtime\python\python.exe" (
  "runtime\python\python.exe" "tools\BUILD_WORLD_AVIATION_GEOJSON.py"
) else (
  python "tools\BUILD_WORLD_AVIATION_GEOJSON.py"
)
echo.
pause
