from pathlib import Path
import csv, json, sys

ROOT=Path(__file__).resolve().parents[1]
src=ROOT/"data"/"source_csv"
out=ROOT/"data"/"spatial"/"world_aviation_geojson"
out.mkdir(parents=True,exist_ok=True)

def fnum(v):
    try: return float(v) if str(v).strip() else None
    except: return None

def write_fc(path, features):
    with open(path,"w",encoding="utf-8") as f:
        json.dump({"type":"FeatureCollection","features":features},f,ensure_ascii=False,separators=(",",":"))

ap=src/"airports.csv"
rw=src/"runways.csv"
if not ap.exists() or not rw.exists():
    print("ERROR: Put airports.csv and runways.csv in:", src)
    sys.exit(2)

airports=[]
airport_lookup={}
with open(ap,encoding="utf-8-sig",newline="") as f:
    for r in csv.DictReader(f):
        lat=fnum(r.get("latitude_deg")); lon=fnum(r.get("longitude_deg"))
        if lat is None or lon is None: continue
        name=(r.get("name") or "").strip()
        kw=(r.get("keywords") or "").strip()
        text=(name+" "+kw).casefold()
        military=any(x in text for x in (
            "air force","airbase","air base","afb","raf ","naval air","army air",
            "military","air station","aeronaval","base aérienne","base aerea"
        ))
        p=dict(r)
        p["entity_kind"]="airport"
        p["military_hint"]=military
        p["military_hint_basis"]="name/keywords heuristic; not an authoritative military classification"
        ident=(r.get("ident") or "").strip()
        airport_lookup[ident]={"name":name,"military_hint":military}
        airports.append({"type":"Feature","geometry":{"type":"Point","coordinates":[lon,lat]},"properties":p})

runways=[]
with open(rw,encoding="utf-8-sig",newline="") as f:
    for r in csv.DictReader(f):
        a=(r.get("airport_ident") or "").strip()
        le=(fnum(r.get("le_longitude_deg")),fnum(r.get("le_latitude_deg")))
        he=(fnum(r.get("he_longitude_deg")),fnum(r.get("he_latitude_deg")))
        if None in le or None in he: continue
        p=dict(r)
        p["entity_kind"]="runway"
        if a in airport_lookup:
            p["airport_name"]=airport_lookup[a]["name"]
            p["military_hint"]=airport_lookup[a]["military_hint"]
        runways.append({"type":"Feature","geometry":{"type":"LineString","coordinates":[list(le),list(he)]},"properties":p})

write_fc(out/"world_airports.geojson",airports)
write_fc(out/"world_runways.geojson",runways)
print("OK")
print("Airports:",len(airports),out/"world_airports.geojson")
print("Runways with both threshold coordinates:",len(runways),out/"world_runways.geojson")
