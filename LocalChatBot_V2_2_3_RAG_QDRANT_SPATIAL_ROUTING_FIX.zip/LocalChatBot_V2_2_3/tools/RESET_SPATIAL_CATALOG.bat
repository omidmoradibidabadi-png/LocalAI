@echo off
cd /d "%~dp0.."
if exist "runtime\python\python.exe" (
  "runtime\python\python.exe" "tools\RESET_SPATIAL_CATALOG.py"
) else (
  python "tools\RESET_SPATIAL_CATALOG.py"
)
pause
