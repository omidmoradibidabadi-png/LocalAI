from pathlib import Path
import sqlite3
ROOT=Path(__file__).resolve().parents[1]
db=ROOT/"data/spatial/spatial_catalog.sqlite3"
if not db.exists():
    print("Spatial catalog does not exist; nothing to reset.")
else:
    con=sqlite3.connect(db)
    con.execute("DELETE FROM aliases")
    con.execute("DELETE FROM features")
    con.commit(); con.execute("VACUUM"); con.close()
    print("Spatial catalog reset successfully.")
