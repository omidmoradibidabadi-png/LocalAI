from __future__ import annotations
import importlib.util,json,sys,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0,str(ROOT))
CFG=ROOT/'config.json'
def out(tag,x,d=''):print(f'[{tag}] {x}'+(f' - {d}' if d else ''))
def probe(u,t=1.2):
 try:
  with urllib.request.urlopen(u,timeout=t) as r:return r.status<500
 except Exception:return False
def main():
 print('\nLocalChatBot V2.1.1 - Preflight\n'+'='*60);cfg=json.loads(CFG.read_text(encoding='utf-8'));missing=0
 out(' OK ','Python',sys.version.split()[0])
 mods={'fitz':'PDF','docx':'DOCX','openpyxl':'XLSX','pptx':'PPTX','extract_msg':'MSG','PIL':'Images/EXIF','pytesseract':'OCR bridge','numpy':'NumPy','pandas':'Pandas','pyarrow':'Parquet/Arrow','pyogrio':'OGR vector bridge','geopandas':'GIS vector','py7zr':'7Z archives','bs4':'HTML'}
 for m,label in mods.items():out(' OK ' if importlib.util.find_spec(m) else 'WARN',label,'ready' if importlib.util.find_spec(m) else 'optional dependency missing')
 for label,p in [('Qdrant',ROOT/'runtime/qdrant/qdrant.exe'),('llama-server',ROOT/'runtime/llama/llama-server.exe'),('Generation model',ROOT/cfg['models']['generation'])]:
  if p.is_file():out(' OK ',label,str(p))
  else:out('FAIL',label,str(p));missing+=1

 try:
  configured=cfg.get('models',{}).get('embedding')
  candidate=(ROOT/configured) if configured else (ROOT/'models'/'embedding')
  emb_dir=candidate if candidate.is_dir() else (ROOT/'models'/'embedding')
  models=sorted([x for x in emb_dir.glob('*.gguf') if x.is_file()], key=lambda x:x.name.lower()) if emb_dir.exists() else []
  if candidate.is_file() and candidate.suffix.lower()=='.gguf': models=[candidate]
  if not models: raise FileNotFoundError(f'No GGUF embedding model found in: {emb_dir}')
  if len(models)>1: raise RuntimeError('Multiple GGUF embedding models found. Keep exactly one GGUF in models\embedding: '+', '.join(x.name for x in models))
  ep=models[0].resolve(); print(f'[ OK ] Embedding model - {ep}')
 except Exception as e:
  print(f'[FAIL] Embedding model - {e}'); missing+=1
 es=ROOT/'runtime/elasticsearch/bin/elasticsearch.bat';out(' OK ' if es.is_file() else 'FAIL','Elasticsearch portable',str(es)); missing += 0 if es.is_file() else 1
 from app.localgeoai.data_paths import DATA_ROOT
 mp=DATA_ROOT/'maps/world/osm_world_z0_z6.pmtiles'; out(' OK ' if mp.is_file() else 'WARN','Offline world PMTiles',str(mp) if mp.is_file() else 'optional: copy osm_world_z0_z6.pmtiles here for offline basemap')
 for wf in [ROOT/'web/vendor/maplibre-gl.js',ROOT/'web/vendor/maplibre-gl.css',ROOT/'web/vendor/pmtiles.js']:
  out(' OK ' if wf.is_file() else 'WARN','Offline web map asset',str(wf) if wf.is_file() else 'optional for basemap; core chatbot will still start')
 print('\nLive services:')
 sv=cfg['services'];checks=[('Qdrant',f"http://{sv['qdrant']['host']}:{sv['qdrant']['port']}/readyz"),('Gemma',f"http://{sv['generation']['host']}:{sv['generation']['port']}/health"),('Embedding',f"http://{sv['embedding']['host']}:{sv['embedding']['port']}/health"),('Elasticsearch',cfg['enterprise_search']['elasticsearch_url'])]
 for a,u in checks:out(' OK ' if probe(u) else 'WARN',a,'online' if probe(u) else 'offline before startup')
 print('='*60);print('Preflight PASSED.' if not missing else f'Preflight FAILED: {missing} required files missing.');return 1 if missing else 0
if __name__=='__main__':raise SystemExit(main())
