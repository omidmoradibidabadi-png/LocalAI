import os, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from app.localgeoai.vision.raster_engine import RasterCatalog
from app.localgeoai.spatial.local_map_qa import answer_local_map

def main():
    assert (ROOT/'app'/'localgeoai').is_dir()
    with tempfile.TemporaryDirectory() as d:
        rc=RasterCatalog(Path(d)); rc.close()
    print('V6.2.2 project-root import bootstrap: PASS')
if __name__=='__main__': main()
