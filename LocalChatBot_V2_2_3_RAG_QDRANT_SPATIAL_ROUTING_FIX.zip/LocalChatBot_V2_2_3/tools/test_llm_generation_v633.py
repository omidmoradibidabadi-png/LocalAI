from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from app.localgeoai.main import CONFIG
from app.localgeoai.orchestrator.llm_diagnostics import GenerationDiagnosticClient

def main():
    c=GenerationDiagnosticClient(CONFIG)
    prompt='''سؤال: سه چالش اصلی را از متن زیر به فارسی خلاصه کن. فقط از متن استفاده کن و برای هر مورد [1] بنویس.\n[1] Challenges include coordination between organizations, readiness of forces, and communication between political and military levels.'''
    r=c.generate(prompt,220,purpose='v6.3.3-direct-self-test')
    print('request_id:',r.get('request_id'))
    print('diagnostics:',json.dumps(r.get('diagnostics'),ensure_ascii=False,indent=2))
    if not r.get('answer'):
        print('V6.3.3 DIRECT LLM TEST: FAILED')
        print('See logs/llm_generation_diagnostics.jsonl and logs/generation.err.log')
        raise SystemExit(2)
    print('\nANSWER:\n'+r['answer'])
    print('\nV6.3.3 DIRECT LLM TEST: PASS')
if __name__=='__main__':main()
