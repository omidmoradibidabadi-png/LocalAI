import tempfile,sys,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from app.localgeoai.spatial.store import SpatialCatalog
from app.localgeoai.spatial.aviation_local import answer_local_aviation

class Img:
 def nearby(self,*a,**k):return [{'id':'i','path':'local.jpg','lat':35.69,'lon':51.31,'capture_time':'','ocr':'','distance_km':1.0}]
class Ras:
 def covering(self,*a,**k):return [{'id':'r','path':'sat.tif','driver':'GTiff','bounds4326':[51.2,35.6,51.4,35.8]}]

# Isolated catalog DB is awkward because module DB is fixed; test behavior using an in-memory compatible fake.
class S:
 def resolve(self,q,kind=None):
  if any(x.lower() in q.lower() for x in ['test','tst','فرودگاه']):return [{'id':1,'dataset':'u','name':'Test Airport','kind':'airport','lon':51.3,'lat':35.7,'properties':{'icao_code':'TST1'}}]
  return []
 def nearby(self,*a,**k):return [{'id':2,'dataset':'u','name':'A320-LOCAL','kind':'aircraft','lon':51.31,'lat':35.7,'properties':{'type':'aircraft','airport':'TST1'},'distance_km':0.9}]
 def related(self,*a,**k):return []
r=answer_local_aviation('در فرودگاه Test چه هواپیماهایی در داده محلی دارم؟',S(),Img(),Ras(),None)
assert r and r['intent']=='local_aviation' and r['requires_map'] and r['local_evidence']['aircraft_count']==1
assert len(r['map']['features'])>=4
print('V6.1.4 local aviation regression: PASS')
