import sys,tempfile,sqlite3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from app.localgeoai.vision.raster_engine import RasterCatalog
from app.localgeoai.spatial.local_map_qa import answer_local_map
from app.localgeoai.spatial.aviation_local import answer_local_aviation

class S:
 def resolve(self,q,kind=None,limit=20):
  if str(q).casefold() in {'mehrabad','o iii','oiii','مهرآباد'}:
   return [{'id':1,'dataset':'user_airports','name':'Mehrabad International Airport','kind':'airport','lon':51.3134,'lat':35.6892,'properties':{'ident':'OIII','iata_code':'THR'},'source':'user/airports.shp'}]
  return []
 def nearby(self,*a,**k):return []
 def related(self,*a,**k):return []
class I:
 def nearby(self,*a,**k):return []
class R:
 def covering(self,*a,**k):return []

def main():
 with tempfile.TemporaryDirectory() as d:
  db=Path(d)/'data/raster_catalog.sqlite';db.parent.mkdir(parents=True)
  c=sqlite3.connect(db);c.execute('CREATE TABLE rasters(id TEXT PRIMARY KEY,path TEXT UNIQUE)');c.commit();c.close()
  rc=RasterCatalog(Path(d))
  check=sqlite3.connect(db)
  try:
   cols={x[1] for x in check.execute('PRAGMA table_info(rasters)').fetchall()}
  finally:
   check.close()
  assert {'driver','crs','bounds','metadata'}<=cols
  rc.close()
 s=S();m=answer_local_map('مهرآباد کجاست؟',s,lambda x:['Mehrabad']);assert m and m['requires_map'] and 'user_airports' in m['answer']
 a=answer_local_aviation('فرودگاه مهرآباد کجاست؟',s,I(),R(),None,lambda x:['Mehrabad']);assert a and a['local_evidence']['airport']['source']=='user/airports.shp'
 print('V6.2 local evidence regression: PASS')
if __name__=='__main__':main()
