from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from app.localgeoai.orchestrator.unified_engine import UnifiedEngine
from app.localgeoai.orchestrator.intent_router import IntentRouter
class Rag:
 def retrieve(self,q,limit=None):return [{'n':1,'source':'test.pptx','page':3,'score':.8,'text':'Starlink has a satellite constellation.'}]
 def ask(self,q):return ('پاسخ مستند [1]',self.retrieve(q))
class Spatial:pass
u=UnifiedEngine(Rag(),Spatial(),IntentRouter())
u.structured.fast_lookup=lambda q:{'mode':'entity','rows':[{'data':{'name':'wrong'},'source':'x','row_no':1}]}
r=u.ask('استارلینک چند ماهواره در مدار دارد؟')
assert r['intent']=='document',r
assert r['sources'],r
assert r['answer'],r
print('V6.1.3 query/RAG regression: PASS')
