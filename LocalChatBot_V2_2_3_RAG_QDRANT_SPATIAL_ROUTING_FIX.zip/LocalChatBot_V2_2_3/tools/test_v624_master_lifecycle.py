import gc, os, sqlite3, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from app.localgeoai.vision.raster_engine import RasterCatalog
from app.localgeoai.vision.image_catalog import ImageCatalog
from app.localgeoai.enterprise.canonical_store import CanonicalStore
from app.localgeoai.spatial.local_map_qa import answer_local_map
from app.localgeoai.spatial.aviation_local import answer_local_aviation

class S:
 def resolve(self,q,kind=None,limit=20):
  if str(q).casefold() in {'mehrabad','oiii','مهرآباد'}:
   return [{'id':1,'dataset':'user_airports','name':'Mehrabad International Airport','kind':'airport','lon':51.3134,'lat':35.6892,'properties':{'ident':'OIII','iata_code':'THR'},'source':'user/airports.shp'}]
  return []
 def nearby(self,*a,**k): return []
 def related(self,*a,**k): return []
class I:
 def nearby(self,*a,**k): return []
class R:
 def covering(self,*a,**k): return []

def release_probe(path):
 p=Path(path); q=p.with_suffix(p.suffix+'.release_probe')
 os.replace(p,q); os.replace(q,p)

def main():
 with tempfile.TemporaryDirectory() as d:
  root=Path(d)
  rc=RasterCatalog(root); ic=ImageCatalog(root); cs=CanonicalStore(root/'data')
  f=root/'sample.txt'; f.write_text('local evidence',encoding='utf-8')
  cs.mark(f,'document','ready',sha=cs.sha256(f),metadata={'source':'test'})
  assert cs.changed(f) is False
  db=root/'data'/'raster_catalog.sqlite'
  con=sqlite3.connect(db)
  try: cols={r[1] for r in con.execute('PRAGMA table_info(rasters)').fetchall()}
  finally: con.close()
  assert {'driver','crs','bounds','metadata'} <= cols
  rc.close(); ic.close(); cs.close(); del rc,ic,cs; gc.collect()
  release_probe(root/'data'/'raster_catalog.sqlite')
  release_probe(root/'data'/'image_catalog.sqlite')
  release_probe(root/'data'/'canonical.sqlite3')
 s=S(); m=answer_local_map('مهرآباد کجاست؟',s,lambda x:['Mehrabad'])
 assert m and m['requires_map'] and 'user_airports' in m['answer']
 a=answer_local_aviation('فرودگاه مهرآباد کجاست؟',s,I(),R(),None,lambda x:['Mehrabad'])
 assert a and a['local_evidence']['airport']['source']=='user/airports.shp'
 print('V6.2.4 master lifecycle + local evidence: PASS')
if __name__=='__main__': main()
