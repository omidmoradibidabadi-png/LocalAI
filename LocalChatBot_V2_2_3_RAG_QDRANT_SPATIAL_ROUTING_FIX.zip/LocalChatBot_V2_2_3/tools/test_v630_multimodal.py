from pathlib import Path
import sys,tempfile,json
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from app.localgeoai.enterprise.email_intelligence import EmailIntelligence,is_email_collection_question
from app.localgeoai.vision.model_lab import VisualModelLab
import app.localgeoai.spatial.store as spatial_store
from app.localgeoai.spatial.store import SpatialCatalog
from app.localgeoai.ingestion.email_parser import parse_email

class ES:
 def search(self,q,size=30,filters=None):return []
 def list_kind(self,kind,size=200):
  assert kind=='email'
  return [{'score':1,'source':{'path':'a.eml','subject':'Project A','from':'alice@example.com','to':'bob@example.com','date':'2026-01-01','body':'Meeting moved to Monday. Please review the report.'}},{'score':1,'source':{'path':'b.msg','subject':'Project A followup','from':'bob@example.com','to':'alice@example.com','date':'2026-01-02','body':'Report reviewed. Action: update map.'}}]
def chat(p,max_tokens=600):return 'خلاصه محلی آزمایشی بر اساس ایمیل‌ها.'

def main():
 assert is_email_collection_question('ایمیل‌هایی که وارد کردم را خلاصه کن')
 r=EmailIntelligence(ES(),chat).answer('ایمیل‌ها را خلاصه کن');assert r['email_count']==2 and r['intent']=='email_collection' and all(x['type']=='email-local' for x in r['sources'])
 with tempfile.TemporaryDirectory() as d:
  root=Path(d);em=root/'sample.eml';em.write_text('From: alice@example.com\nTo: bob@example.com\nSubject: Local Test\nDate: Fri, 18 Sep 2026 10:00:00 +0000\nContent-Type: text/plain; charset=utf-8\n\nLocal email body.',encoding='utf-8');meta,body=parse_email(em,root/'att');assert meta.get('subject')=='Local Test' and 'Local email body' in body
  spatial_store.DB=root/'spatial.sqlite3';sp=SpatialCatalog();csv=root/'airports.csv';csv.write_text('name,latitude_deg,longitude_deg,ident,type\nMehrabad International Airport,35.6892,51.3134,OIII,large_airport\n',encoding='utf-8');x=sp.ingest(csv,kind='auto');assert x['count']==1 and sp.resolve('OIII','airport');sp.close()
  lab=VisualModelLab(root);c=lab.create_class('A320');assert c['id'] and lab.status()[0]['status']=='collecting'
 print('V6.3 multimodal local intelligence: PASS')
if __name__=='__main__':main()
