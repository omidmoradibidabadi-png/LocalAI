from pathlib import Path
import sys,tempfile
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from app.localgeoai.enterprise.email_catalog import EmailCatalog
from app.localgeoai.orchestrator.answer_reliability import evidence_fallback,compact_evidence

def main():
 with tempfile.TemporaryDirectory() as d:
  r=Path(d); c=EmailCatalog(r); p=r/'x.eml';p.write_text('x')
  c.upsert('abc',p,{'subject':'Space Threats Briefing','from':'a@example.com','to':'b@example.com','date':'2026-08-17','attachments':[]},'Discussion of space threats and satellite risks.')
  assert c.count()==1 and c.search('space threats')[0]['subject']=='Space Threats Briefing'
  ev=[{'n':1,'score':.9,'text':'Challenges in Force Build-Up include force generation and headquarters organization.'},{'n':2,'score':.8,'text':'Coordination between political and military echelons creates difficulties.'}]
  x=compact_evidence(ev); a=evidence_fallback('Force Build-Up challenges',x)
  assert 'force generation' in a and '[1]' in a
 print('V6.3.1 email catalog + answer reliability: PASS')
if __name__=='__main__':main()
