from pathlib import Path
import sys,tempfile
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from app.localgeoai.enterprise.email_catalog import EmailCatalog
from app.localgeoai.enterprise.email_intelligence import EmailIntelligence,is_email_collection_question
from app.localgeoai.orchestrator.answer_reliability import evidence_fallback

def main():
 with tempfile.TemporaryDirectory() as d:
  r=Path(d);(r/'data/inbox').mkdir(parents=True)
  c=EmailCatalog(r)
  p1=r/'data/inbox/a.eml';p2=r/'data/inbox/b.eml';p1.write_text('x');p2.write_text('x')
  c.upsert('1',p1,{'subject':'Space Threats','from':'a@example.test','to':'x'},'satellite and space threat briefing')
  c.upsert('2',p2,{'subject':'Airport Ops','from':'b@example.test','to':'x'},'civil airport operations')
  assert c.count()==2
  class NoLLM:
   def __call__(self,*a,**k): raise RuntimeError('offline')
  e=EmailIntelligence(c,NoLLM())
  z=e.answer('تمام ایمیل ها را خلاصه کن',scope_path=str(p1),collection=True)
  assert z['email_count']==2 and len(z['sources'])==2
  one=e.answer('این ایمیل درباره چیست',scope_path=str(p1),collection=False)
  assert one['email_count']==1
  assert is_email_collection_question('تمام ایمیل ها را خلاصه کن')
  f=evidence_fallback('چالش های Force Build-Up چیست؟',[{'n':1,'text':'Challenges in Force Build-Up  Force generation requires readiness  Operational coordination is difficult'}])
  assert 'Force' in f or 'چالش' in f
 print('V6.3.2 grounded generation + scope state: PASS')
if __name__=='__main__':main()
