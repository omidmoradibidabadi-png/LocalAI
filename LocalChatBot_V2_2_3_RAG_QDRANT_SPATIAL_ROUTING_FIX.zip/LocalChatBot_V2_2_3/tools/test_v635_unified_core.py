from pathlib import Path
import json,re,sys
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'app/localgeoai/api/web_server.py').read_text(encoding='utf-8')
ui=(ROOT/'web/index.html').read_text(encoding='utf-8')
cfg=json.loads((ROOT/'config.json').read_text(encoding='utf-8'))
assert cfg['app']['version']=='6.3.5'
assert 'fa_codes=' not in s and '"ایران":"IR"' not in s
assert 'plan_spatial_question' in s and 'filter_property' in s
assert 'SELECTED_SCOPE_NO_EVIDENCE' in (ROOT/'app/localgeoai/orchestrator/unified_engine.py').read_text(encoding='utf-8')
assert 'بازسازی کاتالوگ ایمیل' not in ui
assert 'انتخاب فایل از مرورگر' not in ui and 'انتخاب کل پوشه از مرورگر' not in ui
assert '/api/source/open' in s and 'باز کردن منبع اصلی' in ui
assert 'TopMost=$true' in (ROOT/'app/localgeoai/ui/native_picker.py').read_text(encoding='utf-8')
assert 'detect_hardware' in (ROOT/'app/localgeoai/main.py').read_text(encoding='utf-8')
print('V6.3.5 unified core static contract: PASS')
