from pathlib import Path
import json,sys,tempfile
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
assert json.loads((ROOT/'config.json').read_text(encoding='utf-8'))['app']['version']=='6.3.6'
html=(ROOT/'web/index.html').read_text(encoding='utf-8')
for x in ['بانک داده','نقشه','منابع','datatab','scope_mode:selectedDocumentMode','انتخاب فایل مکانی','انتخاب پوشه مکانی','focusSource']:
 assert x in html,x
ue=(ROOT/'app/localgeoai/orchestrator/unified_engine.py').read_text(encoding='utf-8')
for x in ['FOLDER_CORPUS','SINGLE_FILE','GLOBAL_CORPUS','_folder_evidence','kind_filter']:
 assert x in ue,x
ws=(ROOT/'app/localgeoai/api/web_server.py').read_text(encoding='utf-8')
for x in ['result_set_id','execution_status','grounded execution','scope_mode']:
 assert x in ws,x
print('V6.3.6 grounded multisource + spatial static contract: PASS')
