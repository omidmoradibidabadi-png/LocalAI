from pathlib import Path
import ast, json
ROOT=Path(__file__).resolve().parents[1]
assert json.loads((ROOT/'config.json').read_text(encoding='utf-8'))['version']=='6.3.7'
main=(ROOT/'app/localgeoai/main.py').read_text(encoding='utf-8')
assert '{"input":candidate,"model":"embeddinggemma"}' in main
ue=(ROOT/'app/localgeoai/orchestrator/unified_engine.py').read_text(encoding='utf-8')
assert 'خلاصه.*(پوشه|فایل|داده|ایمیل' in ue
web=(ROOT/'app/localgeoai/api/web_server.py').read_text(encoding='utf-8')
assert "folder scope must NOT pre-empt spatial planning" in web
# Spatial planner must precede final unified.ask fallback
assert web.index('sp_plan=plan_spatial_question') < web.rindex('result=unified.ask')
for f in [ROOT/'app/localgeoai/main.py',ROOT/'app/localgeoai/orchestrator/unified_engine.py',ROOT/'app/localgeoai/api/web_server.py']:
    ast.parse(f.read_text(encoding='utf-8'))
print('V6.3.7 reliability + corpus + spatial routing: PASS')
