from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from app.localgeoai.orchestrator.unified_engine import _citation_integrity
a,u=_citation_integrity("claim [1] bad [9]",[{"n":1,"source":"a.pdf","text":"claim"}])
assert "[1]" in a and "[9]" not in a and u==[1]
cfg=json.loads((ROOT/"config.json").read_text(encoding="utf-8"))
assert cfg["app"]["version"]=="6.3.8"
sp=(ROOT/"app/localgeoai/spatial/store.py").read_text(encoding="utf-8")
assert "LIMIT 20000" not in sp
print("V6.3.8 evidence/citation/spatial static tests: PASS")
