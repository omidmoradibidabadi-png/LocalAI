from pathlib import Path
import sys,tempfile,json
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from app.localgeoai.orchestrator.unified_engine import _document_level_evidence,_citation_integrity,_negative_no_evidence
ev=[{'n':1,'source':'A.pdf','original_path':'A.pdf','page':'Page 2','text':'alpha','score':.9},{'n':2,'source':'A.pdf','original_path':'A.pdf','page':'Page 3','text':'beta','score':.8},{'n':3,'source':'B.pdf','original_path':'B.pdf','page':'Page 1','text':'gamma','score':.7}]
d=_document_level_evidence(ev);assert len(d)==2 and d[0]['n']==1 and d[0]['evidence_chunks']==2
assert _negative_no_evidence('در شواهد بازیابی‌شده اطلاعاتی یافت نشد.')
from app.localgeoai.spatial.query_planner import _alias_to_real
assert _alias_to_real('فرودگاه های قطر','قطر',['US','QA','TR'])=='QA'
from app.localgeoai.satellite_model_manager import SatelliteModelManager
with tempfile.TemporaryDirectory() as td:
 r=Path(td);(r/'models/satellite').mkdir(parents=True);(r/'models/satellite/test.onnx').write_bytes(b'x');(r/'config.json').write_text(json.dumps({'models':{}},ensure_ascii=False),encoding='utf-8');c={'models':{}};m=SatelliteModelManager(r,c);assert len(m.models())==1;m.select('test.onnx');assert m.active()=='test.onnx'
print('V6.4.0 core regression: PASS')
