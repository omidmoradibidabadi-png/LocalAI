from pathlib import Path
import tempfile
from app.localgeoai.model_paths import resolve_embedding_model
with tempfile.TemporaryDirectory() as td:
 r=Path(td); d=r/'models'/'embedding'; d.mkdir(parents=True)
 try: resolve_embedding_model(r,'models/embedding'); raise AssertionError('zero should fail')
 except FileNotFoundError: pass
 a=d/'new-embedding.gguf'; a.write_bytes(b'x')
 assert resolve_embedding_model(r,'models/embedding').name=='new-embedding.gguf'
 b=d/'other.gguf'; b.write_bytes(b'x')
 try: resolve_embedding_model(r,'models/embedding'); raise AssertionError('multiple should fail')
 except RuntimeError: pass
 print('V6.4.1 auto embedding resolver: PASS')
