from pathlib import Path
import sys,tempfile,json,subprocess
ROOT=Path(__file__).resolve().parents[1]
assert str(ROOT) not in sys.path or True
# model resolver import must work when root is explicit
sys.path.insert(0,str(ROOT))
from app.localgeoai.model_paths import resolve_embedding_model
with tempfile.TemporaryDirectory() as td:
 r=Path(td); d=r/'models'/'embedding'; d.mkdir(parents=True); (d/'brand-new-embedding.gguf').write_bytes(b'x')
 assert resolve_embedding_model(r,'models/embedding').name=='brand-new-embedding.gguf'
print('V6.4.2 embedding path fix: PASS')
