from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'app/localgeoai/spatial/query_planner.py').read_text(encoding='utf-8')
w=(ROOT/'app/localgeoai/api/web_server.py').read_text(encoding='utf-8')
p=(ROOT/'app/localgeoai/orchestrator/llm_query_planner.py').read_text(encoding='utf-8')
c=json.loads((ROOT/'config.json').read_text(encoding='utf-8'))
assert c['app']['version']=='6.4.3'
assert 'COUNTRY_ALIASES' not in s
assert 'plan_query(' in w and 'domain=query_plan.get' in w
assert 'GIS_ACTIONS' not in p and 'COUNTRY' not in p
assert 'geographic-sounding concept is NOT spatial' in p
print('V6.4.3 static LLM planner tests: PASS')
