from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
cfg=json.loads((ROOT/'config.json').read_text(encoding='utf-8'))
assert cfg['app']['version']=='6.4.4'
assert cfg['features']['local_data_only'] is True
web=(ROOT/'app/localgeoai/api/web_server.py').read_text(encoding='utf-8')
uni=(ROOT/'app/localgeoai/orchestrator/unified_engine.py').read_text(encoding='utf-8')
mm=(ROOT/'app/localgeoai/model_manager.py').read_text(encoding='utf-8')
hw=(ROOT/'app/localgeoai/runtime_hardware.py').read_text(encoding='utf-8')
assert 'general_chat(q)' not in web
assert '_relevance_gate' in uni and 'fail_closed' in uni
assert '/v1/models' in mm and "'verified':True" in mm
assert 'recommend_gpu_layers' in hw and 'model_size_mb' in hw
assert 'spatial.filter_property' in web and 'requires_map' in web
print('V6.4.4 local-only + relevance + verified hot-swap + adaptive CUDA: PASS')
