from pathlib import Path
import ast,json
r=Path(__file__).resolve().parents[1]
ast.parse((r/'app/localgeoai/main.py').read_text(encoding='utf-8'))
s=(r/'app/localgeoai/main.py').read_text(encoding='utf-8')
assert 'detect_hardware, write_snapshot' in s
assert '--threads' in s and '--batch-size' in s and '--ubatch-size' in s
c=json.loads((r/'config.json').read_text(encoding='utf-8'))
assert c['app']['version']=='6.4.5' and c['runtime']['gpu_profile']=='gpu_priority'
print('V6.4.5 GPU + hot-swap fix: PASS')
