import gc, sqlite3, tempfile, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from app.localgeoai.vision.raster_engine import RasterCatalog
from app.localgeoai.vision.image_catalog import ImageCatalog

def main():
    with tempfile.TemporaryDirectory() as d:
        root=Path(d)
        rc=RasterCatalog(root)
        ic=ImageCatalog(root)
        db=root/'data'/'raster_catalog.sqlite'
        c=sqlite3.connect(db)
        try:
            cols={r[1] for r in c.execute('PRAGMA table_info(rasters)').fetchall()}
        finally:
            c.close()
        assert {'driver','crs','bounds','metadata'} <= cols
        rc.close(); ic.close()
        del rc,ic
        gc.collect()
    print('V6.2.1 Windows SQLite lifecycle: PASS')
if __name__=='__main__': main()
