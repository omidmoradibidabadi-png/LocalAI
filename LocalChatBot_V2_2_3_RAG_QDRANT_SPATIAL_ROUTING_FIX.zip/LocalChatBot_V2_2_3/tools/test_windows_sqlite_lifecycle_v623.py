import gc, sqlite3, tempfile, sys, os
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from app.localgeoai.vision.raster_engine import RasterCatalog
from app.localgeoai.vision.image_catalog import ImageCatalog

def main():
    with tempfile.TemporaryDirectory() as d:
        root=Path(d)
        rc=RasterCatalog(root)
        ic=ImageCatalog(root)
        db=root/'data'/'raster_catalog.sqlite'
        # sqlite3.Connection's context manager commits/rolls back but DOES NOT close.
        # Always close explicitly so Windows can release the file handle.
        con=sqlite3.connect(db)
        try:
            cols={r[1] for r in con.execute('PRAGMA table_info(rasters)').fetchall()}
        finally:
            con.close()
        assert {'driver','crs','bounds','metadata'} <= cols
        rc.close(); ic.close()
        del rc,ic
        gc.collect()
        # Strong Windows-style release check: rename and restore the DB before temp cleanup.
        probe=db.with_suffix('.release_probe')
        os.replace(db, probe)
        os.replace(probe, db)
    print('V6.2.3 Windows SQLite file-release: PASS')
if __name__=='__main__': main()
