from pathlib import Path
import json, shutil, sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from app.localgeoai.data_paths import DATA_ROOT

def copytree_merge(src,dst):
    if not src.exists(): return 0
    n=0
    for p in src.rglob('*'):
        rel=p.relative_to(src); q=dst/rel
        if p.is_dir(): q.mkdir(parents=True,exist_ok=True)
        elif not q.exists(): q.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,q); n+=1
    return n

DATA_ROOT.mkdir(parents=True,exist_ok=True)
for d in ['qdrant','canonical_store','extracted','attachments','extracted_archives','email_catalog','structured','spatial','elasticsearch']:
    (DATA_ROOT/d).mkdir(parents=True,exist_ok=True)
# Configure portable ES, if the user has placed it in runtime.
yml=ROOT/'runtime/elasticsearch/config/elasticsearch.yml'
if yml.exists():
    txt=yml.read_text(encoding='utf-8',errors='ignore')
    marker='# LocalChatBot V1 persistent data'
    if marker not in txt:
        path=str((DATA_ROOT/'elasticsearch').resolve()).replace('\\','/')
        yml.write_text(txt.rstrip()+f'\n\n{marker}\npath.data: "{path}"\n',encoding='utf-8')
print('[OK] LocalChatBot persistent data root:',DATA_ROOT)
print('[OK] Existing indexes survive application-folder upgrades.')
