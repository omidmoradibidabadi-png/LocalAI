from pathlib import Path
import shutil
ROOT=Path(__file__).resolve().parents[1]

def first_named(search_roots,name,exclude=None):
    for base in search_roots:
        if not base.exists(): continue
        try:
            for p in base.rglob(name):
                if p.is_file() and (exclude is None or p.resolve()!=exclude.resolve()): return p
        except Exception: pass
    return None

def main():
    try:
        from app.localgeoai.data_paths import DATA_ROOT
    except Exception:
        DATA_ROOT=ROOT/'LocalChatBot_PersistentData'
    vendor=ROOT/'web/vendor'; vendor.mkdir(parents=True,exist_ok=True)
    roots=[ROOT/'offline_assets',ROOT.parent]
    for name in ('maplibre-gl.js','maplibre-gl.css','pmtiles.js'):
        dst=vendor/name
        if dst.is_file(): continue
        src=first_named(roots,name,dst)
        if src:
            shutil.copy2(src,dst); print(f'[RECOVER] {name} <- {src}')
        else: print(f'[WARN] Offline map library not found: {name}')
    dst=Path(DATA_ROOT)/'maps/world/osm_world_z0_z6.pmtiles'; dst.parent.mkdir(parents=True,exist_ok=True)
    if not dst.is_file():
        src=first_named([ROOT/'offline_assets',ROOT.parent.parent,ROOT.parent],'osm_world_z0_z6.pmtiles',dst)
        if src:
            shutil.copy2(src,dst); print(f'[RECOVER] PMTiles <- {src}')
        else: print(f'[WARN] Offline PMTiles not found; chatbot can still start without basemap.')
if __name__=='__main__': main()
