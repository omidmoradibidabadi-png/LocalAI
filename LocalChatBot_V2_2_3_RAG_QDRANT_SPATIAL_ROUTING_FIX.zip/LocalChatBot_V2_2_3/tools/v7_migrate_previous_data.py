from pathlib import Path
import shutil,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from app.localgeoai.data_paths import DATA_ROOT
src=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else None
if not src or not src.exists():
 print('Usage: python tools/v7_migrate_previous_data.py "E:\\...\\LocalGeoAI_V6_4_16..."');raise SystemExit(2)
old=src/'data'
if not old.exists(): print('[FAIL] Previous data folder not found:',old);raise SystemExit(3)
mapdirs={'qdrant':'qdrant','canonical_store':'canonical_store','extracted':'extracted','attachments':'attachments','extracted_archives':'extracted_archives','email_catalog':'email_catalog','structured':'structured','spatial':'spatial'}
count=0
for a,b in mapdirs.items():
 s=old/a; d=DATA_ROOT/b
 if not s.exists():continue
 for p in s.rglob('*'):
  q=d/p.relative_to(s)
  if p.is_dir():q.mkdir(parents=True,exist_ok=True)
  elif not q.exists():q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);count+=1
for fn in ['image_catalog.sqlite','raster_catalog.sqlite']:
 p=old/fn;q=DATA_ROOT/fn
 if p.exists() and not q.exists():shutil.copy2(p,q);count+=1
print('[OK] Migrated files:',count)
print('[OK] Destination:',DATA_ROOT)
