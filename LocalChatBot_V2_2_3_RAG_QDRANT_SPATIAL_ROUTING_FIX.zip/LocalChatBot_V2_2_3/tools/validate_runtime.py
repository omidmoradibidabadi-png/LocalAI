from __future__ import annotations
import importlib, json, shutil, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
checks=[
 ('PDF / PyMuPDF','fitz',True),('DOCX','docx',True),('XLSX','openpyxl',True),('PPTX','pptx',True),
 ('OpenDocument','odf',False),('EML','email',True),('MSG','extract_msg',False),('Images / EXIF','PIL',True),
 ('OCR bridge','pytesseract',False),('NumPy','numpy',True),('Pandas','pandas',True),('Parquet / Arrow','pyarrow',False),
 ('7Z','py7zr',False),('GIS geometry','shapely',False),('GIS CRS','pyproj',False),('GIS vector / OGR','pyogrio',False),
 ('GeoPandas','geopandas',False),('Raster / GeoTIFF','rasterio',False),('HDF5','h5py',False),('NetCDF','netCDF4',False),('XArray','xarray',False)]
report={'python':sys.version,'capabilities':{},'gdal_drivers':{}}
missing=[]
print('\nLocalGeoAI V6.1.2 runtime validation'); print('-'*72)
for label,mod,core in checks:
    try:
        m=importlib.import_module(mod); ver=getattr(m,'__version__','builtin/unknown'); ok=True; err=''
    except Exception as e:
        ok=False; ver=''; err=f'{type(e).__name__}: {e}'
    report['capabilities'][label]={'ready':ok,'module':mod,'version':str(ver),'core':core,'error':err}
    print(f'{label:25} : {"READY" if ok else "MISSING"}{("  "+str(ver)) if ok and ver else ""}')
    if core and not ok: missing.append(label)
tess=shutil.which('tesseract'); report['tesseract']=tess
print(f'{"Tesseract executable":25} : {"READY" if tess else "OPTIONAL / NOT ON PATH"}')
try:
    import rasterio
    with rasterio.Env() as env: drivers=set(env.drivers())
    for name in ('GTiff','COG','JP2OpenJPEG','ECW','HDF5','netCDF','NITF','VRT'):
        ok=name in drivers; report['gdal_drivers'][name]=ok
        print(f'GDAL driver {name:13} : {"READY" if ok else "UNAVAILABLE"}')
except Exception as e: report['gdal_error']=str(e)
out=ROOT/'logs'/'runtime_validation.json'; out.parent.mkdir(parents=True,exist_ok=True); out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print('-'*72); print('Report:',out)
print('CORE RUNTIME:', 'PASS' if not missing else 'INCOMPLETE -> '+', '.join(missing))
raise SystemExit(0 if not missing else 2)
